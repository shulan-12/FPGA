# -*- coding: utf-8 -*-
r"""
================================================================================
 第一步 / 电脑端 : 造含噪微弱光电信号 -> FIR 降噪 -> 实测信噪比提升
================================================================================
跑法 (用 py, 不要用 python: 这台机器的 python 是微软商店的占位程序):
    cd D:\deepseek\CODE\fpga_denoise\pc
    py step1_gen_and_filter.py            # 出图 + 出数据, 不弹窗口
    py step1_gen_and_filter.py --show     # 顺便弹窗口看

产出 (都在 pc\out\):
    step1_compare.png        原始 vs 滤波后 对比图 (两个噪声工况, 共 6 张子图)
    step1_signals.npz        原始数据(干净/含噪/滤波后/系数) —— 别人重跑得到同样的数
    fir_coeffs.csv           FIR 系数 —— 第3周交给 A 做定点化上 FPGA
    step1_report.txt         全部实测数字 —— 写报告直接抄

--------------------------------------------------------------------------------
 信号参数从哪来的 (不许自己编)
--------------------------------------------------------------------------------
来源: fpga_denoise/sim/pd_src.v —— FPGA 侧已有的含噪信号源
    fs      = 100 kHz        (上游 ad7606_if.v: CONV_RATE = 100_000)
    正弦    = 64 点/周期     -> f_sig = 100000/64 = 1562.5 Hz
    幅度    = 3000 LSB       (AMP)
    噪声    = 32bit LFSR 低8位, 均匀分布, 幅度 NOISE LSB
    种子    = 0xDEADBEEF
    1 LSB   = 152.58 uV      (AD7606, +/-5V 量程, 16bit 二进制补码)
电脑端用【同一套参数】, 这样"电脑端结果"和"FPGA 仿真结果"才能互相对照。

两个噪声工况:
    NOISE = 40    : 和 FPGA 侧 pd_src.v 的默认值一致 -> 用来【对账】(SNR≈39 dB)
    NOISE = 1200  : 噪声比信号还大 -> 真正"微弱信号"的场景 (SNR≈10 dB)
    为什么要第二个: SNR=39 dB 时噪声只有信号幅度的 0.8%, 画在图上跟干净信号
    长得一模一样, 看不出降噪效果, 也没法给评委看。

注意: 电脑端做不到和 RTL 逐位一致 —— RTL 里 LFSR 是【每个时钟都推进】的,
      和采样节拍间隔有关; 这里只复刻它的【统计特性】(同分布、同幅度、同种子)。
      所以两边比的不是同一条噪声波形, 而是同一口径下的统计量。

--------------------------------------------------------------------------------
 SNR 口径 (和 FPGA 侧文档一致, 先说清再算数)
--------------------------------------------------------------------------------
    s = 干净信号, x = 带噪信号, y = 滤波后信号
    P_sig = mean(s^2)              信号功率
    P_noi = mean(e^2),  e = x - s  噪声功率 (滤波后 e = y - s)
    SNR   = 10*log10(P_sig/P_noi) = 20*log10(RMS_sig/RMS_noi)   [dB]

  三点说明, 报数据时必须写清楚:
  1) 滤波后 e = y - s, 也就是【残余噪声 + 滤波器对信号的失真】都算误差。
     这是最严格的口径, 报这个数别人挑不出毛病。
  2) 算法是因果的 (硬件长什么样就怎么算): 不用 filtfilt, 因为它是非因果的,
     FPGA 上做不出来。因果 FIR 有 (N-1)/2 = d 个采样点的群延迟。
  3) ★ 对齐这件事极其容易写错, 而且【特定参数下错了也看不出来】:
       线性相位 FIR: 输出 y[n] 对应的是 d 个采样点之前的输入,
       所以必须拿 y[n+d] 去和 s[n] 比。数据有效的范围还有两个约束:
         - 起点: y[n+d] 要等到 n+d >= N-1 = 2d, 即 n >= d (系数全都参与运算了)
         - 终点: n+d <= len-1
       => 有效区间是 n ∈ [d, len-d), 对应的滤波输出要取 y[2d : len]
       本脚本第一版把区间写成了 s[d:len-d] 配 y[d:len-d], 整整错位 d 个点。
       之所以没暴露: 这个信号一个周期正好 64 个采样点, 而 d 也正好是 64,
       错位整整一个周期, 正弦看起来毫无异常。换个抽头数 (d=32) 就立刻崩了。
       —— 这类 bug 会一直藏到你换参数那天, 所以对齐必须按公式推导, 不能"看着对"。

--------------------------------------------------------------------------------
 参考来源
--------------------------------------------------------------------------------
 [1] scipy.signal.firwin 官方文档 —— 窗函数法设计线性相位 FIR
     https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.firwin.html
 [2] scipy.signal.lfilter 官方文档 —— 因果直接II型实现, 与硬件结构一致
     https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.lfilter.html
 [3] scipy.signal.welch 官方文档 —— 功率谱密度(PSD)估计
     https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.welch.html
 [4] numpy.random.default_rng 官方文档 —— 固定种子的可复现随机数
     https://numpy.org/doc/stable/reference/random/generator.html
 [5] Oppenheim & Schafer, Discrete-Time Signal Processing, 3rd ed.
     - 7.4 节 窗函数法: Hamming 窗过渡带宽度 ~ 3.3*fs/N
     - 5.7 节 线性相位 FIR 群延迟 = (N-1)/2
 [6] 白噪声过 FIR: 输出噪声功率 = 输入噪声功率 * sum(b^2)
     (滤波器等效噪声带宽的定义, 见 [5] 或任意随机信号教材)
================================================================================
"""

import sys
from pathlib import Path

import numpy as np
from scipy.signal import firwin, lfilter, welch

# ==============================================================================
# 参数区: 想扫不同工况就改这里
# ==============================================================================
# ---- 信号源 (必须和 pd_src.v 一致)
FS = 100_000          # 采样率 Hz
PERIOD = 64           # 正弦一个周期多少个采样点 -> f_sig = FS/PERIOD = 1562.5 Hz
AMP = 3000            # 信号幅度 LSB
SEED = 0xDEADBEEF     # 随机种子 (和 RTL 的 SEED 同值, 便于叙述)
N_SAMP = 20_000       # 造多少个采样点 (0.2 s)
LSB_UV = 152.58       # 1 LSB = 152.58 uV (AD7606 +/-5V 量程)

# ---- 噪声工况: (噪声幅度 LSB, 说明)
CASES = [
    (40, "基线工况 (与 FPGA 侧 pd_src 默认值一致)"),
    (1200, "低信噪比工况 (真正的微弱信号场景)"),
]
# 对账只拿噪声幅度等于这个值的工况去比
RTL_NOISE_AMP = 40

# ---- 候选滤波器 (抽头数, 截止频率Hz): 用数据挑方案, 不靠拍脑袋
#      抽头数取奇数 -> 群延迟 d=(N-1)/2 是整数, 才能精确对齐
#      只想试一个方案, 就把这行改成一行, 主方案会自动取表里实测平均提升最高的
CANDIDATES = [(65, 3000.0), (129, 3500.0), (129, 5000.0), (257, 3500.0)]

# ---- 选方案的规则: 提升差不到这个数 (dB) 就算"一样好", 然后挑最省资源的那个
#      理由: 见输出里 129 抽头和 257 抽头的平均提升只差 0.0x dB, 但乘法器差一倍。
#      FPGA 资源是硬约束 (铁律4), 不该为了 0.0x dB 多花一倍 DSP。
GAIN_TOL_DB = 0.10

# ---- 第2步文档里 FPGA 侧的基线实测值, 用来对账
#      容差给 8%: 那边只统计了 500 个点, 均匀噪声 RMS 的统计标准差就有 ~3%
RTL_CLEAN_RMS, RTL_NOISE_RMS, RTL_SNR_DB = 2123.3, 22.1, 39.66
RTL_TOL = 0.08

OUT = Path(__file__).resolve().parent / "out"


# ==============================================================================
# 1. 造信号  (复刻 pd_src.v)
# ==============================================================================
def make_clean(period: int, amp: int, n_samp: int) -> np.ndarray:
    """period 点正弦表 + 缩放, 与 pd_src.v 逐位一致。

    pd_src.v: clean_s = (sine_lut[idx] * AMP) >>> 10
    Verilog 的 >>> 是算术右移, 对负数是"向下取整", 所以用 floor_divide 而不是 round。
    """
    idx = np.arange(period)
    lut = np.round(1024.0 * np.sin(2.0 * np.pi * idx / period)).astype(np.int64)
    n = np.arange(n_samp)
    return np.floor_divide(lut[n % period] * amp, 1024).astype(np.int64)


def make_noise(noise_amp: int, n_samp: int, seed: int) -> np.ndarray:
    """均匀白噪声, 分布同 pd_src.v:
         noise_u ∈ [-128, 127]  (LFSR 低 8 位)
         noise   = floor(noise_u * NOISE / 128)
    """
    rng = np.random.default_rng(seed)
    u = rng.integers(-128, 128, size=n_samp).astype(np.int64)
    return np.floor_divide(u * noise_amp, 128)


# ==============================================================================
# 2. 滤波 + 算 SNR
# ==============================================================================
def snr_db(sig: np.ndarray, err: np.ndarray) -> float:
    """SNR = 10*log10(mean(sig^2) / mean(err^2))"""
    return 10.0 * np.log10(np.mean(sig ** 2) / np.mean(err ** 2))


def evaluate(clean: np.ndarray, noisy: np.ndarray, fs: int,
             numtaps: int, cutoff: float):
    """设计 FIR -> 因果滤波 -> 按公式对齐群延迟 -> 算 SNR_in / SNR_out / 理论预测。

    有效区间推导 (见文件头说明 3):
        y[n] 对应 d 个点之前的输入 -> 对齐后 y[i+d] 对应 s[i]
        又要 i+d >= N-1 = 2d (系数全参与) 且 i+d <= len-1
        => i ∈ [d, len-d),  滤波输出取 y[2d : len]

    返回 (b, y, snr_in, snr_out, snr_pred, group_delay)
      snr_pred: 白噪声理论预测, 输出噪声功率 = 输入噪声功率 * sum(b^2)  (参考[6])
    """
    b = firwin(numtaps, cutoff, fs=fs, window="hamming")   # 参考 [1]
    d = (numtaps - 1) // 2                                 # 群延迟, 参考 [5]
    assert len(noisy) > 4 * d, "数据太短, 对齐后没剩几个点"

    y = lfilter(b, [1.0], noisy.astype(np.float64))        # 因果滤波, 参考 [2]

    s_c = clean[d:len(noisy) - d].astype(np.float64)
    x_c = noisy[d:len(noisy) - d].astype(np.float64)
    y_c = y[2 * d:len(noisy)]                              # ★ 对齐后的滤波输出
    assert len(s_c) == len(x_c) == len(y_c)

    snr_in = snr_db(s_c, x_c - s_c)
    snr_out = snr_db(s_c, y_c - s_c)
    p_sig = np.mean(s_c ** 2)
    p_noi = np.mean((x_c - s_c) ** 2)
    snr_pred = 10.0 * np.log10(p_sig / (p_noi * np.sum(b ** 2)))
    return b, y, snr_in, snr_out, snr_pred, d


def align_filtered(y: np.ndarray, d: int) -> np.ndarray:
    """把滤波输出左移 d 个点, 变成"和输入同一时刻"的序列; 无效处填 NaN。

    画图用。注意下标 i 从 d 开始才有效 (y[i+d] 要等系数全参与)。
    """
    out = np.full(len(y), np.nan)
    out[d:len(y) - d] = y[2 * d:len(y)]
    return out


# ==============================================================================
# 3. 参数合法性检查 (别省: 参数写错时, 现象会很有迷惑性)
# ==============================================================================
def validate() -> None:
    assert N_SAMP > 20 * max(nt for nt, _ in CANDIDATES), \
        "采样点数太少, 对齐后没剩多少了"
    assert 0 < PERIOD <= FS / 2, "一个周期至少 2 个采样点"
    assert AMP > 0, "信号幅度必须是正数"
    assert 2 * AMP + max(nz for nz, _ in CASES) < 32767, \
        "会撑爆 16bit 有符号, 和 AD7606 对不上"
    for nz, label in CASES:
        assert nz > 0, f"噪声幅度必须是正数: {label}"
    for nt, fc in CANDIDATES:
        assert nt % 2 == 1, f"抽头数 {nt} 要取奇数, 否则群延迟不是整数、没法对齐"
        assert 0 < fc < FS / 2, f"截止频率 {fc} 必须落在 0 ~ fs/2 之间"


# ==============================================================================
# 主流程
# ==============================================================================
def main() -> None:
    try:                                        # Windows 控制台默认可能是 GBK
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    validate()
    OUT.mkdir(parents=True, exist_ok=True)
    f_sig = FS / PERIOD

    clean = make_clean(PERIOD, AMP, N_SAMP)
    rms_clean = float(np.sqrt(np.mean(clean.astype(np.float64) ** 2)))

    # 每个工况造一条噪声 (同种子 -> 可复现)
    data = []
    for nz, label in CASES:
        noise = make_noise(nz, N_SAMP, SEED)
        noisy = clean + noise
        rms_noise = float(np.sqrt(np.mean(noise.astype(np.float64) ** 2)))
        data.append(dict(noise_amp=nz, label=label, noisy=noisy,
                         rms_noise=rms_noise,
                         snr_in=snr_db(clean.astype(np.float64), noise.astype(np.float64))))

    L = []                                      # 报告内容, 同时写文件

    def say(line: str = "") -> None:
        print(line)
        L.append(line)

    say("=" * 78)
    say(" 第一步: 含噪微弱信号 + FIR 降噪, 实测信噪比")
    say("=" * 78)
    say(f"信号源 (复刻 pd_src.v): fs={FS} Hz, 正弦 {PERIOD} 点/周期 "
        f"-> f_sig={f_sig} Hz, AMP={AMP} LSB, seed=0x{SEED:08X}")
    say(f"信号 RMS = {rms_clean:.1f} LSB = {rms_clean * LSB_UV / 1000:.1f} mV "
        f"(AD7606 满量程 ±5 V = ±32768 LSB)")
    say(f"采样点数 = {N_SAMP} ({N_SAMP / FS * 1000:.0f} ms)")
    say("")
    for c in data:
        say(f"[{c['label']}] 噪声幅度 {c['noise_amp']} LSB -> "
            f"噪声 RMS {c['rms_noise']:.1f} LSB = {c['rms_noise'] * LSB_UV / 1000:.1f} mV, "
            f"SNR_in = {c['snr_in']:.2f} dB (全段统计)")

    # ---- 对账: 电脑端造的信号 vs FPGA 侧文档实测 ----
    c0 = next(c for c in data if c["noise_amp"] == RTL_NOISE_AMP)
    say("")
    say("-" * 78)
    say(" 对账 (第2步文档里 FPGA 侧 pd_src 的实测值 vs 本脚本基线工况)")
    say("-" * 78)
    for name, mine, theirs in (("干净信号 RMS (LSB)", rms_clean, RTL_CLEAN_RMS),
                               ("噪声     RMS (LSB)", c0["rms_noise"], RTL_NOISE_RMS),
                               ("SNR_in       (dB) ", c0["snr_in"], RTL_SNR_DB)):
        dev = abs(mine - theirs) / abs(theirs)
        flag = "OK  " if dev <= RTL_TOL else "注意"
        say(f"  {flag} {name}: 本脚本 {mine:8.2f} | FPGA侧 {theirs:8.2f} | "
            f"偏差 {dev * 100:5.2f}%")
    say("  (两边不是同一条噪声波形, 比的是同一口径下的统计量; 偏差<8% 即认为参数对得上)")

    # ---- 候选滤波器对比, 用数据挑方案 ----
    say("")
    say("-" * 78)
    say(" 候选滤波器对比 (同一段数据, 同一口径; 有效区间 n ∈ [d, len-d))")
    say("-" * 78)
    say(f"  {'抽头数':>5} {'fc':>6} {'通带边缘':>8} {'延迟ms':>7}   "
        f"{'基线:SNR_out/提升':>18}  {'低SNR:SNR_out/提升':>18}")
    best = None
    rows = []
    for nt, fc in CANDIDATES:
        row = []
        for c in data:
            b, y, si, so, sp, d = evaluate(clean, c["noisy"], FS, nt, fc)
            row.append((so, so - si))
        edge = fc - 1.65 * FS / nt            # 通带边缘估算 (参考[5] 7.4 节)
        note = "" if f_sig < edge else "  <- 信号落进过渡带, 被削了!"
        mean_gain = float(np.mean([g for _, g in row]))
        say(f"  {nt:>5} {fc:>6.0f} {edge:>8.0f} {d / FS * 1000:>7.3f}   "
            f"{row[0][0]:>8.2f}/{row[0][1]:>+7.2f}   "
            f"{row[1][0]:>8.2f}/{row[1][1]:>+7.2f}{note}")
        rows.append(dict(numtaps=nt, cutoff=fc, rows=row, mean_gain=mean_gain))

    # 选方案: 提升不错的候选里挑最省资源的 (抽头数最少; 一样多就挑延迟小的)
    top = max(r["mean_gain"] for r in rows)
    ok = [r for r in rows if r["mean_gain"] >= top - GAIN_TOL_DB]
    best = min(ok, key=lambda r: (r["numtaps"], r["cutoff"]))
    numtaps, cutoff = best["numtaps"], best["cutoff"]

    say(f"  提升最高的候选: {top:+.2f} dB (平均)")
    say(f"  选方案的规则: 平均提升在最优值 {GAIN_TOL_DB} dB 以内就算一样好, "
        f"然后在里面挑【抽头数最少】的 (FPGA 资源优先)")
    say(f"  => 主方案: 抽头数 {numtaps}, fc = {cutoff:.0f} Hz, "
        f"平均提升 {best['mean_gain']:+.2f} dB")
    say("")
    say("  这张表怎么读 (结论都是从上面的数字里读出来的, 不是估计):")
    say("    - 65 抽头那行基线工况是负提升: N=65 时过渡带宽 3.3*fs/N ≈ 5077 Hz,")
    say("      通带边缘才 462 Hz, 1562.5 Hz 的信号整个落进过渡带被削掉大半。")
    say("      注意它低信噪比工况反而是正提升 —— 噪声特别大时, 就算把信号一起削了,")
    say("      砍掉的噪声还是比损失的信号多。所以【两个工况都要看】, 只看一个会误判。")
    say("    - 同一阶数下 fc 低一点提升更大 (3500 比 5000 好约 1 dB), 因为砍掉的")
    say("      噪声带宽更宽; 但 fc 降下去通带边缘也降, 别把信号压进过渡带。")
    say("    - 阶数 129 -> 257 几乎没有提升 (差 0.0x dB): 因为 sum(b^2) 基本没变。")
    say("      阶数真正管的是【过渡带宽度】, 不是提升幅度 —— 阶数越高, 越能把信号")
    say("      和噪声切得干净, 也越抗信号频率漂移 (真实信号不会正好 1562.5 Hz)。")

    # ---- 主方案 ----
    say("")
    say("-" * 78)
    say(f" 主方案: Hamming 窗线性相位 FIR, 抽头数 {numtaps} (阶数 {numtaps - 1}), "
        f"fc = {cutoff:.0f} Hz")
    say("-" * 78)
    b = firwin(numtaps, cutoff, fs=FS, window="hamming")
    d = (numtaps - 1) // 2
    edge = cutoff - 1.65 * FS / numtaps
    say(f"  设计方法: scipy.signal.firwin(numtaps={numtaps}, cutoff={cutoff:.0f}, "
        f"fs={FS}, window='hamming')   [参考1]")
    say(f"  过渡带宽度估算: 3.3*fs/N = {3.3 * FS / numtaps:.0f} Hz (参考5 之 7.4 节),"
        f" 通带约到 {edge:.0f} Hz, 阻带约从 {cutoff + 1.65 * FS / numtaps:.0f} Hz 开始")
    in_band = f_sig < edge
    say(f"  信号频率 {f_sig} Hz 在通带内: {in_band}")
    assert in_band, "主方案把信号削进过渡带了, 这个设计不能用"
    say(f"  群延迟 (N-1)/2 = {d} 点 = {d / FS * 1000:.3f} ms  <- 实时处理的固有延迟")
    say(f"  系数最大绝对值 max|b| = {np.max(np.abs(b)):.6f} "
        f"(定点化检查: Q1.15 范围 ±1.0, "
        f"{'放得下' if np.max(np.abs(b)) < 1.0 else '要重新定标'})")
    # 对称性检查: 只有严格对称才能把 N 个乘法器省成 (N+1)/2 个, 所以要验而不是假设
    asym = float(np.max(np.abs(b - b[::-1])))
    say(f"  对称性检查: max|b[k]-b[N-1-k]| = {asym:.1e} "
        f"({'严格对称 OK' if asym < 1e-12 else '不对称! 省乘法器的前提不成立'})")
    # 定点化预检: 系数按 Q1.15 量化后的误差 (下一步会实测量化后的 SNR)
    b_q = np.round(b * 32768) / 32768
    say(f"  定点化预检 Q1.15: 单系数最大量化误差 {np.max(np.abs(b - b_q)):.2e}, "
        f"直流增益 {b.sum():.6f} -> {b_q.sum():.6f} (相对误差 "
        f"{abs(b_q.sum() - b.sum()) / abs(b.sum()) * 100:.4f}%)")
    say(f"  对称性: 线性相位 FIR, b[k] = b[N-1-k] -> FPGA 上可用 "
        f"{(numtaps + 1) // 2} 个乘法器实现 (不是 {numtaps} 个)")
    say("")
    say("  === FPGA 资源估算 (估算值, 第3-4周综合后确认, 现在先当可行性判断) ===")
    say(f"  乘法器: 利用对称性 {(numtaps + 1) // 2} 个; XC7A35T 有 90 个 DSP48E1")
    say(f"          -> {'全并行放得下' if (numtaps + 1) // 2 <= 90 else '放不下, 要么时分复用要么砍阶数'}")
    say(f"  时序:   采样率 {FS / 1000:.0f} kHz -> 每个样本 {1e6 / FS:.1f} µs; "
        f"50 MHz 时钟下就是 {int(50e6 / FS)} 拍/样本")
    say(f"          全并行只要 1 拍就出结果, 余量极大; 就算改成时分复用 1 个乘法器,")
    say(f"          {(numtaps + 1) // 2} 个乘累加也只要 {(numtaps + 1) // 2} 拍, 仍然够")
    say(f"  延迟:   群延迟 {d} 拍 = {d / FS * 1000:.3f} ms (实时显示的固有延迟, 必须写进报告)")
    say(f"  存储:   输入需要 {numtaps} 个 16bit 的移位寄存器 (约 "
        f"{numtaps * 16} bit, 折合 {int(np.ceil(numtaps * 16 / 64))} 个 LUTRAM/SRL16)")

    results = []
    for c in data:
        _, y, snr_in_m, snr_out, snr_pred, _ = evaluate(clean, c["noisy"], FS,
                                                        numtaps, cutoff)
        gain = snr_out - snr_in_m
        results.append(dict(c, y=y, snr_in=snr_in_m, snr_out=snr_out,
                            snr_pred=snr_pred, gain=gain))
        say("")
        say(f"  --- [{c['label']}] ---")
        say(f"  SNR_in  = {snr_in_m:7.2f} dB   (对齐后有效区间 n ∈ [d, len-d), 口径与 SNR_out 一致)")
        say(f"           (全段统计是 {c['snr_in']:.2f} dB, 差 {abs(c['snr_in'] - snr_in_m):.2f} dB,"
            f" 因为掐掉了首尾各 d 个点)")
        say(f"  SNR_out = {snr_out:7.2f} dB   (因果 FIR + 对齐群延迟后算)")
        say(f"  白噪声理论预测 SNR_out = {snr_pred:7.2f} dB "
            f"(= 输入噪声功率 x sum(b^2), 只看噪声, 不算信号失真)")
        say(f"  实测比预测低 {snr_pred - snr_out:.2f} dB —— 这部分是滤波器对信号本身的"
            f"失真 (通带下垂), 口径里算误差, 如实报")
        say(f"  >>> 实测提升 = {gain:+.2f} dB   (噪声功率降到 1/{10 ** (gain / 10):.2f})")

    # ---- 提升幅度受什么限制 (用严格口径说, 不用"估计") ----
    sum_b2 = float(np.sum(b ** 2))
    enbw = FS * sum_b2                        # 双边等效噪声带宽, 参考[6]
    say("")
    say("-" * 78)
    say(" 提升幅度受什么限制 (严格口径)")
    say("-" * 78)
    say(f"  白噪声过 FIR 后功率 = 输入功率 x sum(b^2) = 输入功率 x {sum_b2:.5f}  [参考6]")
    say(f"  等效噪声带宽 ENBW = fs x sum(b^2) = {enbw:.0f} Hz (双边)")
    say(f"  => 相当于把噪声带宽从 fs = {FS} Hz 压到 {enbw:.0f} Hz, "
        f"提升就是 10*log10(1/sum(b^2)) = {-10 * np.log10(sum_b2):.2f} dB")
    say(f"  一个理想砖墙低通 fc={cutoff:.0f} Hz 的噪声带宽是 2*fc = {2 * cutoff:.0f} Hz,")
    say(f"  对应 {10 * np.log10((FS / 2) / cutoff):.2f} dB —— 本设计的 sum(b^2) 对应 "
        f"{-10 * np.log10(sum_b2):.2f} dB, 跟它同量级, 说明设计是正常的。")
    say(f"  想再提升只能把 fc 往下压 (sum(b^2) 正比于 fc), 但 fc 压太低会开始削")
    say(f"  信号的谐波 (真实光电脉冲有谐波), 这是取舍, 不能只追求 dB 数字。")

    # ---- 存文件 ----
    save = dict(clean=clean, b=b, fs=FS, period=PERIOD, amp=AMP, seed=SEED,
                numtaps=numtaps, cutoff_hz=cutoff, group_delay=d)
    for r in results:
        tag = f"noise{r['noise_amp']}"
        save[f"noisy_{tag}"] = r["noisy"]
        save[f"filtered_{tag}"] = r["y"]
        save[f"snr_in_{tag}"] = r["snr_in"]
        save[f"snr_out_{tag}"] = r["snr_out"]
        save[f"gain_{tag}"] = r["gain"]
    np.savez(OUT / "step1_signals.npz", **save)

    np.savetxt(OUT / "fir_coeffs.csv",
               np.column_stack([np.arange(numtaps), b]),
               delimiter=",", header="tap,coeff", comments="", fmt=["%d", "%.12e"])
    (OUT / "step1_report.txt").write_text("\n".join(L) + "\n", encoding="utf-8")

    # ---- 画图 ----
    plot(clean, results, d, f_sig, numtaps, cutoff, OUT / "step1_compare.png")
    say("")
    say(f"已存: {OUT / 'step1_compare.png'}")
    say(f"      {OUT / 'step1_signals.npz'}  (原始数据, 可复现)")
    say(f"      {OUT / 'fir_coeffs.csv'}    (交给 A 定点化上 FPGA)")
    say(f"      {OUT / 'step1_report.txt'}  (以上全部数字)")

    if "--show" in sys.argv:
        import matplotlib.pyplot as plt
        plt.show()


def plot(clean, results, d, f_sig, numtaps, cutoff, path):
    """每个工况一行, 三列: 局部时域 / 误差 / 功率谱"""
    import matplotlib
    matplotlib.use("Agg")                   # 不弹窗, 直接存文件 (加 --show 才弹)
    import matplotlib.pyplot as plt

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    n = len(clean)
    t = np.arange(n) / FS * 1000.0          # ms
    zoom = int(5.0 * FS / 1000)             # 前 5 ms

    fig, ax = plt.subplots(len(results), 3, figsize=(16, 4.2 * len(results)),
                           squeeze=False)
    fig.suptitle(f"微弱光电信号降噪对比  |  fs={FS / 1000:.0f} kHz, f_sig={f_sig} Hz, "
                 f"FIR {numtaps} 抽头 (阶数 {numtaps - 1}), Hamming, "
                 f"fc={cutoff:.0f} Hz, 群延迟 {d / FS * 1000:.3f} ms",
                 fontsize=14)

    for i, r in enumerate(results):
        y_al = align_filtered(r["y"], d)    # 左移 d 点对齐; 无效处是 NaN, 不画

        # ① 局部时域
        a = ax[i][0]
        a.plot(t[:zoom], clean[:zoom], color="black", lw=1.6, label="干净信号 (理想)")
        a.plot(t[:zoom], r["noisy"][:zoom], color="0.65", lw=0.8,
               label="含噪信号 (ADC 看到的)")
        a.plot(t[:zoom], y_al[:zoom], color="crimson", lw=1.4, label="FIR 滤波后")
        a.set_title(f"{r['label']}\n① 局部 (前 5 ms, 约 8 个信号周期)   "
                    f"SNR {r['snr_in']:.2f} -> {r['snr_out']:.2f} dB "
                    f"({r['gain']:+.2f} dB)", fontsize=10)
        a.set_xlabel("时间 (ms)")
        a.set_ylabel("幅度 (LSB)")
        a.grid(alpha=0.3)
        a.legend(fontsize=8, loc="upper right")

        # ② 误差: 带噪与滤波后偏离干净信号多少 (同一段对齐区间, 口径一致)
        e0, e1 = d, n - d
        rms_x = float(np.sqrt(np.mean((r["noisy"][e0:e1] - clean[e0:e1]) ** 2)))
        rms_y = float(np.sqrt(np.mean((y_al[e0:e1] - clean[e0:e1]) ** 2)))
        a = ax[i][1]
        a.plot(t[e0:e1], (r["noisy"] - clean)[e0:e1], color="0.65", lw=0.8,
               label=f"含噪误差  RMS={rms_x:.1f} LSB")
        a.plot(t[e0:e1], y_al[e0:e1] - clean[e0:e1], color="crimson", lw=1.0,
               label=f"滤波后残余误差  RMS={rms_y:.1f} LSB")
        a.set_title(f"② 误差对比: 残余误差降到 1/{rms_x / rms_y:.2f}", fontsize=10)
        a.set_xlabel("时间 (ms)")
        a.set_ylabel("误差 (LSB)")
        a.grid(alpha=0.3)
        a.legend(fontsize=8, loc="upper right")

        # ③ PSD: 噪声铺满全带 vs 滤波后高频被砍掉 (参考3)
        a = ax[i][2]
        for sig, lab, col in ((r["noisy"], "含噪信号", "0.65"),
                              (r["y"], "FIR 滤波后", "crimson")):
            f, p = welch(sig.astype(np.float64), fs=FS, nperseg=2048)
            a.plot(f / 1000.0, 10 * np.log10(p), color=col, lw=1.0, label=lab)
        a.axvline(f_sig / 1000.0, color="black", ls="--", lw=1.0,
                  label=f"信号 {f_sig:.0f} Hz")
        a.axvline(cutoff / 1000.0, color="steelblue", ls=":", lw=1.2,
                  label=f"截止 {cutoff:.0f} Hz")
        a.set_title("③ 功率谱密度 (Welch): 截止频率以上的噪声被砍掉", fontsize=10)
        a.set_xlabel("频率 (kHz)")
        a.set_ylabel("PSD (dB/Hz)")
        a.set_xlim(0, 20)
        a.grid(alpha=0.3)
        a.legend(fontsize=8, loc="upper right")

    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(path, dpi=130)
    plt.close(fig)


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
r"""
================================================================================
 第5步 / 电脑端 : 文档自检 —— 核对工作汇总附录 B 的 129 个系数与生成文件一致
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc
    py step5_check_doc_coeffs.py

为什么要这个:
    工作汇总里手抄了 129 个系数给老师看。手抄 129 个数字靠眼睛核对是不可靠的
    (第一版就漏了 64~71 那一段)。所以用脚本把文档里的数字和生成文件逐个比对,
    文档里既然写了"已核对一致", 就必须真的核过。
================================================================================
"""

import re
import sys
from pathlib import Path

PC = Path(__file__).resolve().parent
PROJ = PC.parent
REF_FILE = PC / "out" / "fir_coeffs_q15.txt"
DOC_FILE = PROJ / "工作汇总_给指导老师_20261010.md"


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    for f in (REF_FILE, DOC_FILE):
        if not f.exists():
            print(f"缺少文件: {f}")
            raise SystemExit(1)

    ref = [int(x) for x in REF_FILE.read_text().split()]
    md = DOC_FILE.read_text(encoding="utf-8")

    # ★ 必须按标题 "# 附录 B" 切: 光搜 "附录 B" 会先命中目录里那一行, 切错位置
    if "# 附录 B" not in md:
        print("文档里找不到 '# 附录 B' 标题")
        raise SystemExit(1)
    after = md.split("# 附录 B", 1)[1]
    if "```" not in after:
        print("附录 B 里找不到代码块")
        raise SystemExit(1)
    block = after.split("```")[1]

    nums = []
    for line in block.splitlines():
        if ":" not in line:
            continue
        line = line.split("←")[0]          # 去掉行尾的中文注释(里面也有数字)
        nums += [int(x) for x in re.findall(r"-?\d+", line.split(":", 1)[1])]

    print("=" * 70)
    print(" 文档自检: 附录 B 的系数表 vs 生成文件 fir_coeffs_q15.txt")
    print("=" * 70)
    print(f"  生成文件里的系数个数 : {len(ref)}")
    print(f"  文档附录里提取到的   : {len(nums)}")

    if len(nums) != len(ref):
        print(f"  ★ FAIL: 数量对不上, 人工核对 (差 {len(nums) - len(ref)})")
        raise SystemExit(1)

    bad = [i for i, (a, b) in enumerate(zip(nums, ref)) if a != b]
    if bad:
        print(f"  ★ FAIL: {len(bad)} 个位置不一致: {bad[:20]}")
        for i in bad[:10]:
            print(f"    下标 {i:>3}: 文档 {nums[i]:>6}  实际 {ref[i]:>6}")
        raise SystemExit(1)

    print("  ★ PASS: 129/129 逐个数一致")
    print(f"  首/中/末: b[0]={ref[0]}  b[64]={ref[64]}  b[128]={ref[128]}")
    sym = max(abs(ref[i] - ref[len(ref) - 1 - i]) for i in range(len(ref)))
    print(f"  对称性 max|b[k]-b[N-1-k]| = {sym}  "
          f"({'严格对称' if sym == 0 else '★ 不对称'})")


if __name__ == "__main__":
    main()

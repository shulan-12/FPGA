# -*- coding: utf-8 -*-
r"""
================================================================================
 第2步 / 电脑端 : FIR 系数定点化(Q1.15) + 定点运算的逐位模拟 + 验证台数字预测
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc
    py step2_fixedpoint_and_coeffs.py

为什么要这个脚本:
  A 的验证台 tb_filter_harness.v 我不能直接猜到它会打印什么。
  所以在写 Verilog 之前, 先在 Python 里把【和 RTL 完全一样的定点运算】模拟一遍
  (整数、无浮点), 得到"应该打印出来的数字"。Verilog 跑出来如果和它对不上,
  就说明 RTL 写错了 —— 这比"跑出来看着差不多"可靠得多。

口径说明 (★ 这里和 A 的验证台对齐, 和我第1步的口径不同):
  验证台用【双实例法】:
      dout_noisy = filter(clean + noise)
      dout_clean = filter(clean)
      对线性滤波器: dout_noisy - dout_clean == filter(noise)
      SNR_out = 10*log10( sum(dout_clean^2) / sum((dout_noisy-dout_clean)^2) )
      gain    = SNR_out - SNR_in
  好处: 完全不用管群延迟对不对齐。8 点滑动平均的群延迟是 3.5 个采样点(非整数),
        "人工对齐"根本没法做, 这个方法从根上避开了。
  ⚠️ 前提: 滤波器必须是【线性】的。中值滤波是非线性的, 这个验证台对它无效。

参考来源:
  [1] scipy.signal.firwin / freqz 官方文档
  [2] Oppenheim & Schafer, Discrete-Time Signal Processing, 3rd ed., 7.4 / 5.7 节
  [3] Q1.15 定点: 最高位是符号位, 剩下 15 位是小数, 可表示 [-1, 1-2^-15]
================================================================================
"""

import sys
from pathlib import Path

import numpy as np
from scipy.signal import firwin, freqz, lfilter

sys.path.insert(0, str(Path(__file__).resolve().parent))
# 复用第1步的造信号函数 —— 不重复写一遍 (参数和 pd_src.v 对齐这件事只做一次)
from step1_gen_and_filter import FS, PERIOD, AMP, SEED, make_clean, make_noise  # noqa: E402

OUT = Path(__file__).resolve().parent / "out"

NUMTAPS = 129
CUTOFF_HZ = 3500.0
NOISE_AMP = 40            # 和验证台 SRC_NOISE 一致
N_SAMP = 4_400            # 够验证台的窗口 (SKIP+NSAMP=4300) 就行, 短一点跑得快
SKIP = 300                # 和验证台一致
NSAMP = 4_000             # 和验证台一致

# 把噪声带限到多少 Hz: OPT101 前端带宽 14kHz (TI 手册 §6.5), AN706 抗混叠 22kHz
# 取两者中更紧的那个: 14 kHz
REAL_NOISE_BW = 14_000.0

ACC_SHIFT = 15            # Q1.15 -> 整数(LBS) 要算术右移 15 位


# ==============================================================================
# 定点 FIR: 和 Verilog 逐位一致的整数运算
# ==============================================================================
def quantize_q15(b: np.ndarray) -> np.ndarray:
    """系数 -> Q1.15 整数。round-half-away-from-zero, 和 Verilog 的取整习惯一致。"""
    q = np.trunc(b * 32768.0 + np.where(b >= 0, 0.5, -0.5)).astype(np.int64)
    assert np.max(np.abs(q)) <= 32767, "系数超出 Q1.15 范围, 要重新定标"
    return q


def fir_fixed(din: np.ndarray, coef_q15: np.ndarray) -> np.ndarray:
    """逐位模拟 RTL 的定点 FIR (对称结构)。

    和 denoise_filter.v 的算法一一对应:
        延迟线 sr[0]=最新,  sr[k] = k 个采样点之前的输入
        acc = Σ_{k=0}^{(TAPS-3)/2} coef[k]*(sr[k] + sr[TAPS-1-k])  +  coef[mid]*sr[mid]
        dout = acc >>> 15   (算术右移 -> 对负数是向下取整, 和 Verilog 的 >>> 一致)
        最后饱和到 16bit 有符号
    纯整数运算, 没有浮点, 所以 Verilog 必须给出完全一样的结果。
    """
    n = len(din)
    taps = len(coef_q15)
    assert taps % 2 == 1, "对称结构要求抽头数是奇数"
    mid = (taps - 1) // 2

    sr = np.zeros(taps, dtype=np.int64)      # 延迟线
    out = np.zeros(n, dtype=np.int64)
    for i in range(n):
        sr[1:] = sr[:-1]                     # 移位
        sr[0] = int(din[i])                  # 新样本进 sr[0]
        acc = 0
        for k in range(mid):                 # 对称: 一次算两个抽头
            acc += int(coef_q15[k]) * (int(sr[k]) + int(sr[taps - 1 - k]))
        acc += int(coef_q15[mid]) * int(sr[mid])
        v = acc >> ACC_SHIFT                 # Python 的 >> 对负数是算术右移, 同 Verilog >>>
        out[i] = min(max(v, -32768), 32767)  # 饱和, 防溢出翻转符号
    return out


# ==============================================================================
# SNR / 增益 (和验证台完全一样的口径)
# ==============================================================================
def harness_gain(clean, code, filt) -> dict:
    """复刻 tb_filter_harness.v 的统计方式。"""
    dout_noisy = filt(code)
    dout_clean = filt(clean)
    d = dout_noisy - dout_clean

    # 验证台的窗口: 第 SKIP+1 ~ SKIP+NSAMP 个样本
    sl = slice(SKIP, SKIP + NSAMP)
    c = clean[sl].astype(np.float64)
    nz = (code - clean)[sl].astype(np.float64)
    os_ = dout_clean[sl].astype(np.float64)
    on_ = d[sl].astype(np.float64)

    snr_in = 10 * np.log10(np.sum(c ** 2) / np.sum(nz ** 2))
    snr_out = 10 * np.log10(np.sum(os_ ** 2) / np.sum(on_ ** 2))
    return dict(in_sig_rms=float(np.sqrt(np.mean(c ** 2))),
                in_noi_rms=float(np.sqrt(np.mean(nz ** 2))),
                snr_in=float(snr_in),
                out_sig_rms=float(np.sqrt(np.mean(os_ ** 2))),
                out_noi_rms=float(np.sqrt(np.mean(on_ ** 2))),
                snr_out=float(snr_out),
                gain=float(snr_out - snr_in))


def ma8(x):
    """8 点滑动平均 >=> 验证台里的占位基线, 用来核对我的复刻是不是对的。"""
    kern = np.ones(8) / 8.0
    return np.floor(lfilter(kern, [1.0], x.astype(np.float64))).astype(np.int64)


def bandlimit(x: np.ndarray, bw: float, fs: int) -> np.ndarray:
    """把白噪声用 FFT 理想带限到 0~bw (模拟 OPT101 前端只有 14kHz 带宽)。

    注意: 带限之后样本的边缘分布不再是均匀分布(变成大量正弦叠加), 但
    【功率谱】才是决定滤波器增益的东西, 所以对增益计算是合适的。
    """
    X = np.fft.rfft(x.astype(np.float64))
    f = np.fft.rfftfreq(len(x), 1.0 / fs)
    X[f > bw] = 0.0
    y = np.fft.irfft(X, n=len(x))
    # 归一化到和原来相同的功率, 这样 SNR_in 不变, 只改噪声的带宽
    return y * (np.std(x) / np.std(y))


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    OUT.mkdir(parents=True, exist_ok=True)
    L = []

    def say(s: str = "") -> None:
        print(s)
        L.append(s)

    # ---- 1. 系数 + 定点化 ----
    b = firwin(NUMTAPS, CUTOFF_HZ, fs=FS, window="hamming")
    coef_q15 = quantize_q15(b)
    b_q = coef_q15 / 32768.0

    say("=" * 78)
    say(" 第2步: FIR 系数定点化 (Q1.15) + 定点运算逐位模拟")
    say("=" * 78)
    say(f"滤波器: firwin(numtaps={NUMTAPS}, cutoff={CUTOFF_HZ:.0f}, fs={FS}, "
        f"window='hamming')")
    say(f"对称性: max|b[k]-b[N-1-k]| = {np.max(np.abs(b - b[::-1])):.1e}  "
    f"(用对称结构 {NUMTAPS} 抽头只需 {(NUMTAPS + 1) // 2} 次乘法)")
    say(f"定点化: 单系数最大误差 {np.max(np.abs(b - b_q)):.2e}, "
        f"直流增益 {b.sum():.6f} -> {b_q.sum():.6f}")
    err_dc = abs(b_q.sum() - b.sum()) / abs(b.sum()) * 100
    say(f"        直流增益相对误差 {err_dc:.4f}%  "
        f"({'可忽略' if err_dc < 0.1 else '过大, 要检查'})")

    # ---- 2. 滤波器频率特性检查 ----
    w, H = freqz(b, worN=1 << 16, fs=FS)
    f_sig = FS / PERIOD
    H_sig = np.abs(H[np.argmin(np.abs(w - f_sig))])
    H_max = float(np.max(np.abs(H)))
    say("")
    say(f"频率特性: |H({f_sig:.1f} Hz)| = {H_sig:.6f} "
        f"({20 * np.log10(H_sig):+.3f} dB, 信号在通带内的衰减)")
    say(f"          max|H| = {H_max:.6f}  "
        f"({'<=1, 不会溢出' if H_max <= 1.0 else '>1, 满量程输入时有溢出风险 -> 需要饱和'})")
    sum_b2 = float(np.sum(b_q ** 2))
    say(f"          sum(b^2) = {sum_b2:.6f} -> 白噪声功率降到 1/{1 / sum_b2:.2f} "
        f"= {-10 * np.log10(sum_b2):.2f} dB")

    # ---- 2b. 完整频响指标 (报告写"滤波器性能"不能只有增益, 要有硬指标) ----
    H_db = 20 * np.log10(np.abs(H) + 1e-300)
    below = np.nonzero(H_db <= -3.0)[0]
    f_3db = float(w[below[0]]) if len(below) else float("nan")
    band = w <= (CUTOFF_HZ - 1.65 * FS / NUMTAPS)
    ripple = float(np.max(np.abs(np.abs(H[band]) - 1.0)))
    say(f"         实际 -3dB 点 = {f_3db:.0f} Hz "
        f"(设计 fc={CUTOFF_HZ:.0f} Hz 是 -6dB 点, 所以 -3dB 点更高, 正常)")
    say(f"         通带纹波 (0~{w[band][-1]:.0f} Hz 内) = {ripple * 100:.4f}% "
        f"({20 * np.log10(1 + ripple):+.4f} / {20 * np.log10(1 - ripple):+.4f} dB)")
    for fq in (6250.0, 12500.0, 22000.0, 50000.0):
        idx = int(np.argmin(np.abs(w - fq)))
        say(f"         |H({fq / 1000:>5.1f} kHz)| = "
            f"{20 * np.log10(np.abs(H[idx]) + 1e-300):>7.1f} dB")
    say(f"         系数绝对值和 sum|b| = {np.sum(np.abs(b)):.4f} "
        f"(>1 说明通带轻微过冲, 这就是溢出保护必须加的原因)")
    worst = float(np.sum(np.abs(coef_q15))) * 2 * 32768
    say(f"         累加器最坏情况 = sum|coef_q15| * 2 * 32768 = {worst:.3e} "
        f"({np.ceil(np.log2(worst)):.0f} bit, 取 40 bit 有余量)")

    # ---- 3. 造信号 ----
    clean = make_clean(PERIOD, AMP, N_SAMP)
    noise = make_noise(NOISE_AMP, N_SAMP, SEED)
    code = clean + noise
    noise_bl = bandlimit(noise, REAL_NOISE_BW, FS)
    code_bl = clean + np.round(noise_bl).astype(np.int64)

    # ---- 4. 先验证我的复刻对不对: 8 点滑动平均应该给出 A 的 8.66 dB ----
    say("")
    say("-" * 78)
    say(" 自检: 用同样的口径复刻 A 的占位基线 (8 点滑动平均)")
    say("-" * 78)
    m = harness_gain(clean, code, ma8)
    say(f"  输入信号RMS {m['in_sig_rms']:7.1f} LSB | 输入噪声RMS {m['in_noi_rms']:6.1f} LSB "
        f"| 输入SNR {m['snr_in']:6.2f} dB")
    say(f"  输出信号RMS {m['out_sig_rms']:7.1f} LSB | 输出噪声RMS {m['out_noi_rms']:6.1f} LSB "
        f"| 输出SNR {m['snr_out']:6.2f} dB")
    say(f"  降噪增益 = {m['gain']:+.2f} dB      "
        f"(A 的 README 报 8.66 dB; 我自己跑 ModelSim 也是 8.66 dB)")
    say(f"  -> 我的复刻差 {abs(m['gain'] - 8.66):.2f} dB。差异来自噪声序列不同"
        f"(RTL 的 LFSR 每个时钟都推进, 和这里不是同一条), 属正常。")

    # ---- 5. 预测我的 FIR 在验证台上会打印什么 ----
    say("")
    say("-" * 78)
    say(" 预测: 129 抽头 FIR 填进 denoise_filter.v 后, 验证台应该打印什么")
    say("-" * 78)
    say(f"  {'实现方式':<22} {'输入SNR':>9} {'输出SNR':>9} {'降噪增益':>9}")
    preds = {}
    for name, fn, noise_desc in (
        ("浮点(理想)", lambda x: np.round(lfilter(b, [1.0], x.astype(np.float64))).astype(np.int64),
         "全带宽白噪声"),
        ("Q1.15 定点(要写的)", lambda x: fir_fixed(x, coef_q15), "全带宽白噪声"),
    ):
        r = harness_gain(clean, code, fn)
        preds[name] = r
        say(f"  {name:<22} {r['snr_in']:>9.2f} {r['snr_out']:>9.2f} {r['gain']:>+9.2f}")
    say("")
    say("  定点化损失: "
        f"{preds['Q1.15 定点(要写的)']['gain'] - preds['浮点(理想)']['gain']:+.3f} dB "
        f"(定点比浮点差多少)")
    say("  ★ 这个数就是 Verilog 跑出来必须对上的目标值 (允许 ±0.2 dB 的噪声序列差异)")

    # ---- 6. 现实校正: 噪声带宽只有 14 kHz ----
    say("")
    say("-" * 78)
    say(f" 现实校正: 真实前端噪声只到 {REAL_NOISE_BW / 1000:.0f} kHz, 不是 50 kHz")
    say("-" * 78)
    say(f"  依据: OPT101 内部跨阻放大器带宽 14 kHz (TI 手册 SBBS006 §6.5),")
    say(f"        AN706 模块模拟抗混叠滤波器 -3dB 在 22 kHz (AN706 手册 Part3)")
    say(f"        两者取更紧的 -> 14 kHz")
    say(f"  验证台里的噪声是【全带宽 0~50 kHz】白噪声, 所以它算出来的增益会偏高。")
    say("")
    say(f"  {'实现方式':<22} {'全带宽增益':>11} {'14kHz带宽增益':>14} {'差':>8}")
    for name, fn in (("8 点滑动平均(基线)", ma8),
                     ("129抽头 FIR(Q1.15)", lambda x: fir_fixed(x, coef_q15))):
        r_full = harness_gain(clean, code, fn)
        r_bl = harness_gain(clean, code_bl, fn)
        say(f"  {name:<22} {r_full['gain']:>+10.2f} {r_bl['gain']:>+13.2f} "
            f"{r_bl['gain'] - r_full['gain']:>+7.2f}")
    say("")
    say("  => 报告里该写哪个数: 两个都要写, 并说明口径。")
    say("     验证台数字(全带宽)用来证明【FPGA 实现和电脑端一致】;")
    say("     14kHz 数字才是【对真实板卡效果】的合理预期。")

    # ---- 7. 验证台的测量精度 (★ 这个数必须有, 否则比较方案时会把散差当结论) ----
    say("")
    say("-" * 78)
    say(" 验证台的测量精度: 换不同噪声种子, 同一个滤波器能测出多大散差")
    say("-" * 78)
    say("  为什么必须知道: A 的验证台是单次测量。滤波器把噪声带宽压窄之后,")
    say("  窗口内【独立样本数】只剩 NSAMP * sum(b^2) 个, 功率估计的散差就上来了。")
    say("  不知道这个数, 就没法判断两次测量的差异是【真的变好了】还是【运气】。")
    say("")
    NSEED = 300
    b_f = firwin(NUMTAPS, CUTOFF_HZ, fs=FS, window="hamming")
    ma_k = np.ones(8) / 8.0

    def gain_one(clean, code, kern):
        fc = lfilter(kern, [1.0], clean.astype(np.float64))
        fo = lfilter(kern, [1.0], code.astype(np.float64))
        sl = slice(SKIP, SKIP + NSAMP)
        si = 10 * np.log10(np.sum(clean[sl] ** 2) / np.sum((code - clean)[sl] ** 2))
        so = 10 * np.log10(np.sum(fc[sl] ** 2) / np.sum((fo - fc)[sl] ** 2))
        return so - si

    say(f"  {'滤波器':<20} {'平均增益':>9} {'单次散差(1σ)':>13} {'最小':>8} {'最大':>8}")
    for name, kern, sb2 in (("8 点滑动平均(基线)", ma_k, float(np.sum(ma_k ** 2))),
                            (f"{NUMTAPS}抽头 FIR", b_f, float(np.sum(b_f ** 2)))):
        gs = []
        for s in range(NSEED):
            nz = make_noise(NOISE_AMP, N_SAMP, SEED + s)
            gs.append(gain_one(clean, clean + nz, kern))
        gs = np.array(gs)
        m_ind = NSAMP * sb2
        say(f"  {name:<20} {gs.mean():>+8.2f}  {gs.std(ddof=1):>12.2f} "
            f"{gs.min():>+8.2f} {gs.max():>+8.2f}")
        say(f"  {'':<20} 窗口内独立样本数约 {m_ind:.0f} 个 "
            f"(= NSAMP x sum(b^2) = {NSAMP} x {sb2:.4f})")
    say("")
    say("  => 结论: 单次测量的散差在 ±0.3 dB 量级。所以")
    say("     · 两个方案差 3 dB 以上(比如 FIR vs 滑动平均): 单次测量就够, 结论可信")
    say("     · 两个方案只差 0.1~0.2 dB(比如 129 抽头 vs 257 抽头): 单次测量分不出来,")
    say("       必须换多个种子跑多次取平均, 否则测出来的差异就是噪声")
    say(f"     要分辨 0.1 dB 的差异, 按 1σ={0.3:.1f} dB 算需要约 "
        f"{int(np.ceil((0.3 / 0.1) ** 2))} 次独立试验取平均 (标准误 = σ/sqrt(N))")
    say("")
    say("  (本节的增益用浮点滤波算, 因为要跑 300 次; 定点化只差 0.009 dB, 见第5节)")

    # ---- 8. 输出 Verilog 系数块 ----
    lines = []
    per = 8
    for i in range(0, NUMTAPS, per):
        chunk = coef_q15[i:i + per]
        # ★ 两个 ModelSim 会报 vlog-13057 "Expecting numeric digits" 的写法坑:
        #   1) 'sd 和数字之间不能有空格 (别为了对齐加空格)
        #   2) 负数必须写成 -16'sd5, 不能写 16'sd-5
        body = " ".join(
            f"coef[{i + j:>3}] = {'-' if v < 0 else ''}16'sd{abs(int(v))};"
            for j, v in enumerate(chunk))
        lines.append("        " + body)
    snippet = "\n".join(lines)
    (OUT / "fir_coeffs_q15.vh").write_text(snippet + "\n", encoding="utf-8")
    (OUT / "fir_coeffs_q15.txt").write_text(
        "\n".join(str(int(v)) for v in coef_q15) + "\n", encoding="utf-8")

    say("")
    say(f"已输出: {OUT / 'fir_coeffs_q15.vh'}  (可直接粘进 denoise_filter.v 的 initial 块)")
    say(f"        {OUT / 'fir_coeffs_q15.txt'} (纯数字, 便于核对)")
    (OUT / "step2_report.txt").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

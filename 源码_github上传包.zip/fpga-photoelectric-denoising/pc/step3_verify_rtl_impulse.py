# -*- coding: utf-8 -*-
r"""
================================================================================
 第3步 / 电脑端 : 逐位验证 RTL 定点实现 == Python 定点模型
================================================================================
跑法 (先跑仿真, 再跑本脚本):
    cd D:\deepseek\CODE\fpga_denoise\sim
    vlog -work work_flt pd_src.v ..\rtl\denoise_filter.v tb_impulse_check.v
    vsim -c -work work_flt -do "run -all; quit -f" tb_impulse_check

    cd ..\pc
    py step3_verify_rtl_impulse.py

为什么要做这一步:
    验证台的 SNR 是【统计量】。RTL 的噪声序列和 Python 不是同一条,
    噪声带宽被滤波器压窄之后独立样本变少, 单次测量的散差就有 ±0.26 dB。
    所以 "RTL 跑出 11.57, Python 预测 11.85" 这 0.28 dB 到底是
    【正常散差】还是【实现有 bug】, 靠 SNR 是分辨不出来的。

    冲激响应是【确定性的】, 逐位比对可以给出确定的答案:
      对得上  -> RTL 实现和 Python 模型在数学上等价, 那 0.28 dB 就是散差
      对不上  -> 立刻逐位暴露是哪一级出的问题

结论会写进报告: "FPGA 定点实现与电脑端参考模型逐位一致" —— 这是很强的证据。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

PC = Path(__file__).resolve().parent
sys.path.insert(0, str(PC))
from step2_fixedpoint_and_coeffs import NUMTAPS, CUTOFF_HZ, fir_fixed, quantize_q15  # noqa: E402
from step1_gen_and_filter import FS  # noqa: E402
from scipy.signal import firwin  # noqa: E402

SIM_OUT = PC.parent / "sim" / "impulse_out.txt"
IMP_IDX, IMP_AMP, NSAMP = 200, 32767, 360


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    if not SIM_OUT.exists():
        print(f"找不到 {SIM_OUT}")
        print("请先跑仿真: vsim -c -work work_flt -do \"run -all; quit -f\" tb_impulse_check")
        raise SystemExit(1)

    rtl = np.array([int(x) for x in SIM_OUT.read_text().split()], dtype=np.int64)

    coef_q15 = quantize_q15(firwin(NUMTAPS, CUTOFF_HZ, fs=FS, window="hamming"))
    inp = np.zeros(NSAMP, dtype=np.int64)
    inp[IMP_IDX] = IMP_AMP
    py = fir_fixed(inp, coef_q15)

    print("=" * 78)
    print(" 逐位验证: RTL 定点实现 vs Python 定点模型 (冲激响应)")
    print("=" * 78)
    print(f"  RTL 输出样本数 : {len(rtl)}")
    print(f"  Python 样本数  : {len(py)}")

    if len(rtl) != len(py):
        print("  FAIL: 样本数不一致")
        raise SystemExit(1)

    diff = np.abs(rtl - py)
    bad = np.nonzero(diff)[0]
    print(f"  逐位不同的样本数 : {len(bad)} / {len(py)}")
    print(f"  最大绝对差       : {int(diff.max())} LSB")

    if len(bad) == 0:
        print("")
        print("  ★ PASS: RTL 实现和 Python 定点模型【逐位完全一致】")
        print("    => FPGA 上的滤波运算在数学上和参考模型等价,")
        print("       验证台的 0.28 dB 差异属于噪声序列不同造成的统计散差, 不是 bug。")
    else:
        print("")
        print("  ★ FAIL: 存在逐位差异, 这是实现 bug, 必须查!")
        print(f"  最早出错的 10 个位置: {bad[:10].tolist()}")
        for j in bad[:10]:
            print(f"    样本 {j:>4}: RTL={rtl[j]:>8}  Python={py[j]:>8}  差 {rtl[j] - py[j]:>6}")
        raise SystemExit(1)

    # 顺带把冲激响应和系数对一下, 让人能肉眼看出抽头顺序对不对
    resp = rtl[IMP_IDX:IMP_IDX + NUMTAPS]
    expect_resp = py[IMP_IDX:IMP_IDX + NUMTAPS]
    print("")
    print("  冲激响应 (= 系数 x 32767 >> 15) 与系数的对应关系:")
    print(f"  {'抽头':>5} {'coef(Q1.15)':>12} {'预期输出':>10} {'RTL输出':>10}")
    for j in (0, 1, 32, 63, 64, 65, 96, 127, 128):
        print(f"  {j:>5} {coef_q15[j]:>12} {expect_resp[j]:>10} {resp[j]:>10}")
    peak = int(np.argmax(np.abs(resp)))
    print(f"  峰值出现在第 {peak} 个抽头 (中心抽头应该是 {NUMTAPS // 2}) "
          f"-> {'对称结构正确' if peak == NUMTAPS // 2 else '★ 抽头顺序有问题!'}")


if __name__ == "__main__":
    main()

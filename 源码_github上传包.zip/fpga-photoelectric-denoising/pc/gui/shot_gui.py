# -*- coding: utf-8 -*-
r"""启动界面(回放真实抓包) -> 等数据填满 -> 截窗口图。

用法:
    py shot_gui.py

产物: out\报告用_真实硬件界面.png

注意:
  · 回放用【整帧循环】(data_sources.FileSource 已按 135 字节截断), 绕回时不会切出半个帧
  · 等 5 秒再截: 样本率要 3~5 秒才收敛到 12500 (启动阶段会显示略低)
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = sys.executable
SHOT = HERE / "out" / "报告用_真实硬件界面.png"
BIN = HERE.parent.parent / "tools" / "cap_145049.bin"


def main() -> None:
    SHOT.parent.mkdir(exist_ok=True)
    cmd = [PY, str(HERE / "dashboard.py"),
           "--source", "file", "--file", str(BIN),
           "--fsig", "0", "--autostart", "--window", "80"]
    print("启动:", " ".join(cmd))
    proc = subprocess.Popen(cmd, cwd=str(HERE))
    time.sleep(5.0)          # 等回放稳定循环几轮, 样本率才收敛到 12500

    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    user32.SetProcessDPIAware()

    hwnd = user32.FindWindowW(None, "微弱光电信号降噪 · 上位机")
    if not hwnd:
        print("找不到窗口, 退出")
        proc.terminate()
        raise SystemExit(1)

    user32.ShowWindow(hwnd, 9)      # SW_RESTORE (最小化时坐标为负)
    time.sleep(0.4)
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.4)

    r = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    print(f"窗口位置 ({r.left},{r.top}) 尺寸 {w}x{h}")
    if w < 200 or h < 200:
        print("窗口尺寸异常, 退出")
        proc.terminate()
        raise SystemExit(1)

    hdc = user32.GetWindowDC(hwnd)
    mdc = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    gdi32.SelectObject(mdc, bmp)
    user32.PrintWindow(hwnd, mdc, 2)     # PW_RENDERFULLCONTENT

    from PIL import Image

    class BMI(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                    ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                    ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                    ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                    ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                    ("biClrImportant", wintypes.DWORD)]

    bi = BMI()
    bi.biSize = ctypes.sizeof(BMI)
    bi.biWidth, bi.biHeight = w, -h
    bi.biPlanes, bi.biBitCount = 1, 32
    bi.biCompression = 0
    buf = ctypes.create_string_buffer(w * h * 4)
    gdi32.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bi), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    img.save(SHOT)
    print("已保存:", SHOT)

    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(mdc)
    user32.ReleaseDC(hwnd, hdc)

    proc.terminate()
    try:
        proc.wait(3)
    except Exception:
        proc.kill()


if __name__ == "__main__":
    main()

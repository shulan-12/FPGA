# -*- coding: utf-8 -*-
r"""
================================================================================
 上位机 / 界面布局自测: 用【控件几何】而不是截图来判断布局对不对
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py selftest_gui_layout.py

为什么要这样测:
    截图受 DPI 缩放、窗口管理器、最小化状态影响, 很不稳定 (本项目实测: 同一个程序
    有时截到 688x448, 有时被最小化到 158x26)。
    直接问 tkinter "每个控件实际占了多少像素" 才是可复现的判据。

检查项:
    1  窗口能创建, 几何尺寸生效
    2  状态栏可见且有高度 (★ 这是最容易踩的: 先 pack 会 expand 的画布,
       后 pack 底部的状态栏, 状态栏会被挤出可视区)
    3  画布高度 = 窗口高 - 控制栏 - 状态栏, 没有被挤掉
    4  figure 里两张子图 (时域 + 频谱) 都存在
    5  figure 的像素尺寸不超过画布控件的尺寸 (否则会被裁掉, 表现为"只看到上面那张图")
================================================================================
"""

import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))

WANT_W, WANT_H = 1180, 720       # dashboard.py 里的默认窗口尺寸
FIG_W_IN, FIG_H_IN = 6.6, 3.6    # dashboard.py 里的 figsize

results = []


def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {detail}" if detail else ""))


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    import matplotlib
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

    print("=" * 78)
    print(" 上位机界面布局自测 (按 dashboard.py 的布局方式搭建)")
    print("=" * 78)

    root = tk.Tk()
    root.title("layout test")
    root.geometry(f"{WANT_W}x{WANT_H}")

    # 控制栏
    bar = ttk.Frame(root, padding=6)
    bar.pack(side=tk.TOP, fill=tk.X)
    ttk.Label(bar, text="数据源:").pack(side=tk.LEFT)
    ttk.Button(bar, text="开始/停止").pack(side=tk.LEFT)

    # ★ 与 dashboard.py 一致的顺序: 状态栏先 pack 在底部, 再 pack 会 expand 的画布
    status = ttk.Label(root, text="状态栏测试文字", anchor="w", padding=6,
                       relief=tk.SUNKEN, font=("Consolas", 9))
    status.pack(side=tk.BOTTOM, fill=tk.X)

    fig, ax = plt.subplots(2, 1, figsize=(FIG_W_IN, FIG_H_IN), height_ratios=[2, 1])
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    root.update_idletasks()
    root.update()

    rw, rh = root.winfo_width(), root.winfo_height()
    bw, bh = bar.winfo_width(), bar.winfo_height()
    sw, sh = status.winfo_width(), status.winfo_height()
    cw, ch = canvas.get_tk_widget().winfo_width(), canvas.get_tk_widget().winfo_height()
    fig_px = (fig.get_size_inches() * fig.dpi)
    nax = len(fig.axes)

    print(f"  窗口 {rw}x{rh} | 控制栏 {bw}x{bh} | 画布 {cw}x{ch} | 状态栏 {sw}x{sh}")
    print(f"  figure 像素 {fig_px[0]:.0f}x{fig_px[1]:.0f} | 子图数量 {nax}")
    print("")

    check("1 窗口尺寸生效 (>= 请求值)", rw >= WANT_W - 4 and rh >= WANT_H - 4,
          f"请求 {WANT_W}x{WANT_H}, 实际 {rw}x{rh}")

    check("2 ★状态栏可见且有高度", sh > 10 and sw > 100,
          f"状态栏 {sw}x{sh} (高度 0 就说明被画布挤掉了)")

    used = bh + ch + sh
    check("3 画布高度正常 (没被挤掉)", ch > 150 and used <= rh + 4,
          f"控制栏+画布+状态栏 = {used} <= 窗口高 {rh}")

    check("4 figure 里有两张子图", nax == 2, f"子图数 {nax}")

    check("5 figure 放得进画布 (否则会被裁掉)", fig_px[0] <= cw + 4 and fig_px[1] <= ch + 4,
          f"figure {fig_px[0]:.0f}x{fig_px[1]:.0f} vs 画布 {cw}x{ch}")

    for a in ax:
        a.clear()
    root.destroy()
    plt.close(fig)

    npass = sum(1 for _, ok, _ in results if ok)
    print("")
    print("=" * 78)
    print(f" 结果: {npass}/{len(results)} 通过")
    if npass != len(results):
        for nm, ok, d in results:
            if not ok:
                print(f"   - {nm}   {d}")
        raise SystemExit(1)
    print(" === 界面布局全部通过 ===")
    print("=" * 78)


if __name__ == "__main__":
    main()

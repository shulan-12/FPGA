# -*- coding: utf-8 -*-
r"""
================================================================================
 上位机 / 串口帧协议: 编解码 + 解析状态机 + 成对帧状态机 + 丢帧统计
================================================================================
协议 (A 定稿, 2026-10-07 起生效 —— 带 2 字节 SEQ):

    偏移 0    : 0xAA                 同步头 1
    偏移 1    : 0x55                 同步头 2
    偏移 2    : 帧类型               0x01=原始信号  0x02=滤波后  0x03=调试
    偏移 3    : 数据长度 N (字节)    本帧有效数据字节数
    偏移 4    : SEQ_L                采集轮次序号, 小端
    偏移 5    : SEQ_H
    偏移 6    : N 字节数据           小端序, int16 有符号 (低字节先发)
    偏移 6+N  : 累加和               从"帧类型"到"数据"末字节, 取低 8 位
                                     即 TYPE + LEN + SEQ_L + SEQ_H + Σdata

    一帧 = 6(帧头) + N + 1(校验和) 字节; N=128 时 = 135 字节

成对规则 (A 定稿): 0x01 后必定紧跟 0x02, 两帧对应同一个 SEQ、同一段采集数据且已对齐。

--------------------------------------------------------------------------------
 校验和口径 (已用 A 的真实 dump 反推确认, 不是猜的)
--------------------------------------------------------------------------------
    拿 tools/adc_stream_dump.bin (4 帧真实 FPGA 输出) 逐个试了四种口径:
        H1 TYPE+LEN+SEQ_L+SEQ_H+Σdata  -> 4/4 帧全对   ★ 采用
        H2 TYPE+SEQ_L+SEQ_H+Σdata       -> 0/4
        H3 TYPE+LEN+Σdata               -> 0/4
        H4 TYPE+Σdata                   -> 0/4
    所以【长度字节和 SEQ 都必须计入】。漏任何一个, 每帧都会被判坏帧,
    现象是"一帧都收不到"且没有任何语法错误提示 —— 极难排查。

--------------------------------------------------------------------------------
 为什么成对逻辑要单独成一个状态机 (最危险的一类错误)
--------------------------------------------------------------------------------
    如果 0x02 丢了一帧, 而我们仍然把下一个 0x02 配给它, 就会拿【A 段的原始】
    去配【B 段的滤波后】—— 画出来的"降噪对比图"是假的, 而且看起来完全正常。
    现在有了 SEQ, 这类错配可以被【直接发现】(同一对的两个 SEQ 必须相等)。

--------------------------------------------------------------------------------
 丢帧检查能力 (有了 SEQ 之后的真实边界)
--------------------------------------------------------------------------------
    能精确计数 : 丢 0x02 / 丢 0x01 / 错配 / 【整对丢失】<- SEQ 跳号, 精确数出丢了几对
    只能估算   : 运行中累计丢帧率的趋势 (样本率兜底仍保留作为交叉验证)
================================================================================
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

SYNC1 = 0xAA
SYNC2 = 0x55
TYPE_RAW = 0x01
TYPE_FILT = 0x02
TYPE_DEBUG = 0x03

VALID_TYPES = (TYPE_RAW, TYPE_FILT, TYPE_DEBUG)

MAX_DATA_LEN = 1024          # 单帧最多 512 个 int16, 防跑飞
HEADER_LEN = 6               # AA 55 TYPE LEN SEQ_L SEQ_H
FRAME_OVERHEAD = 7           # 帧头 6 + 校验和 1

# 状态
(S_SYNC1, S_SYNC2, S_TYPE, S_LEN,
 S_SEQ_LO, S_SEQ_HI, S_DATA, S_CKSUM) = range(8)


def checksum(ftype: int, data: bytes, seq: int = 0) -> int:
    """累加和 = 从【帧类型】到【数据末字节】的累加和, 取低 8 位。

    ★ 中间夹着的【长度字节】和【SEQ 两个字节】都必须计入:
        TYPE + LEN + SEQ_L + SEQ_H + Σdata
      这条已用 tools/adc_stream_dump.bin 的真实帧逐帧反推确认 (4/4 帧只在这个
      口径下校验通过)。漏任何一项 -> 每帧都被判坏帧, 且没有任何报错提示。
    """
    return ((ftype + len(data) + (seq & 0xFF) + ((seq >> 8) & 0xFF)
             + sum(data)) & 0xFF)


def build_frame(ftype: int, samples, seq: int = 0) -> bytes:
    """按新协议打包一帧: AA 55 TYPE LEN SEQ_L SEQ_H <data> CKSUM。"""
    data = struct.pack("<%dh" % len(samples), *samples)
    return (bytes([SYNC1, SYNC2, ftype, len(data),
                   seq & 0xFF, (seq >> 8) & 0xFF])
            + data + bytes([checksum(ftype, data, seq)]))


def parse_samples(data: bytes):
    """把帧里的数据段解成 int16 列表 (小端序, 有符号)。"""
    return list(struct.unpack("<%dh" % (len(data) // 2), data))


def frame_bytes(npoints: int) -> int:
    """N 个 int16 组成的一帧占多少字节 (帧头 6 + 数据 + 校验和 1)。"""
    return FRAME_OVERHEAD + 2 * npoints


@dataclass
class ParseStats:
    """解析统计。所有异常都必须计数, 不能静默丢弃。"""
    bytes_in: int = 0
    frames_ok: int = 0
    garbage_bytes: int = 0        # 同步头之前扫掉的垃圾字节
    sync_errors: int = 0          # 0xAA 后面不是 0x55
    bad_type: int = 0             # 帧类型非法
    bad_len: int = 0              # 数据长度非法
    checksum_errors: int = 0      # 校验和错 -> 有帧被破坏
    debug_frames: int = 0

    @property
    def total_problems(self) -> int:
        return (self.sync_errors + self.bad_type + self.bad_len
                + self.checksum_errors)

    def summary(self) -> str:
        return (f"收 {self.bytes_in} B / 好帧 {self.frames_ok} / "
                f"校验错 {self.checksum_errors} / 失步 {self.sync_errors} / "
                f"坏类型 {self.bad_type} / 坏长度 {self.bad_len}")


class FrameParser:
    """逐字节解析状态机。喂多少字节都行, 不要求整帧。

    on_frame(ftype, seq, data) —— 三个参数, seq 是帧头里的采集轮次号。
    """

    def __init__(self, on_frame=None, max_len: int = MAX_DATA_LEN):
        self.st = S_SYNC1
        self.ftype = 0
        self.nlen = 0
        self.seq = 0
        self.buf = bytearray()
        self.ck = 0
        self.max_len = max_len
        self.on_frame = on_frame
        self.stats = ParseStats()

    # -- 遇到非法内容时重新找同步头; 当前字节本身可能是新的 0xAA, 不能丢 --
    def _resync(self, b: int) -> None:
        self.st = S_SYNC2 if b == SYNC1 else S_SYNC1

    def feed(self, data: bytes) -> None:
        self.stats.bytes_in += len(data)
        for b in data:
            self._byte(b)

    def _byte(self, b: int) -> None:
        st = self.st
        if st == S_SYNC1:
            if b == SYNC1:
                self.st = S_SYNC2
            else:
                self.stats.garbage_bytes += 1

        elif st == S_SYNC2:
            if b == SYNC2:
                self.st = S_TYPE
            else:
                # 0xAA 后面不是 0x55 -> 误同步。注意这一字节也可能是 0xAA,
                # 所以要用 _resync 而不是无脑退回 S_SYNC1
                self.stats.sync_errors += 1
                self._resync(b)

        elif st == S_TYPE:
            if b in VALID_TYPES:
                self.ftype = b
                self.ck = b
                self.st = S_LEN
            else:
                self.stats.bad_type += 1
                self._resync(b)

        elif st == S_LEN:
            # 数据帧长度必须是正偶数 (int16 个数×2); 调试帧不限
            loom = (b == 0) or (b > self.max_len) or \
                   (self.ftype in (TYPE_RAW, TYPE_FILT) and (b % 2 != 0))
            if loom:
                self.stats.bad_len += 1
                self._resync(b)
            else:
                self.nlen = b
                self.buf.clear()
                self.ck = (self.ck + b) & 0xFF
                self.st = S_SEQ_LO

        elif st == S_SEQ_LO:
            self.seq = b
            self.ck = (self.ck + b) & 0xFF      # ★ 校验和必须含 SEQ_L
            self.st = S_SEQ_HI

        elif st == S_SEQ_HI:
            self.seq |= (b << 8)
            self.ck = (self.ck + b) & 0xFF      # ★ 校验和必须含 SEQ_H
            self.st = S_DATA

        elif st == S_DATA:
            self.buf.append(b)
            self.ck = (self.ck + b) & 0xFF
            if len(self.buf) == self.nlen:
                self.st = S_CKSUM

        else:  # S_CKSUM
            if b == self.ck:
                self.stats.frames_ok += 1
                if self.ftype == TYPE_DEBUG:
                    self.stats.debug_frames += 1
                if self.on_frame is not None:
                    self.on_frame(self.ftype, self.seq, bytes(self.buf))
            else:
                # 校验错 -> 这一帧不可信, 丢掉并重新同步
                self.stats.checksum_errors += 1
            self.st = S_SYNC1


@dataclass
class PairStats:
    """成对帧统计。"""
    pairs_ok: int = 0
    pairing_errors: int = 0       # 0x01 后面不是 0x02 (0x02 丢了一帧)
    orphan_filt: int = 0          # 没等到 0x01 就先来了 0x02
    length_mismatch: int = 0      # 同一对里两帧长度不等
    seq_mismatch: int = 0         # ★ 同一对的两个 SEQ 不相等 -> 错配!
    debug_interrupt: int = 0      # 成对之间插了调试帧 (协议说不会, 出现即异常)
    seq_gaps: int = 0             # 跨对 SEQ 不连续的次数
    pairs_lost: int = 0           # ★ 由 SEQ 跳号精确数出的丢失对数
    seq_duplicate: int = 0        # SEQ 重复 (同一对来了两次?)

    @property
    def total_problems(self) -> int:
        return (self.pairing_errors + self.orphan_filt + self.length_mismatch
                + self.seq_mismatch + self.debug_interrupt + self.seq_gaps
                + self.seq_duplicate)

    def summary(self) -> str:
        return (f"成功配对 {self.pairs_ok} / 配对错 {self.pairing_errors} / "
                f"孤儿 {self.orphan_filt} / SEQ错配 {self.seq_mismatch} / "
                f"SEQ跳号丢失 {self.pairs_lost} 对")


class PairAssembler:
    """成对帧状态机: 严格 0x01 -> 0x02, 且两帧 SEQ 必须相同。

    ★ 安全性质 1: 绝不把不同段的原始和滤波后配成一对。
      做法是"来了新的 0x01 就把旧的未配对 raw 丢掉", 这样即使丢了 0x02,
      也只会丢掉一段数据 (计数上报), 不会画出错误的对比图。
    ★ 安全性质 2: 有了 SEQ 之后, 错配可以被【直接检出】而不是只能靠推断
      (同一对的两个 SEQ 必须相等)。
    ★ 附加能力: 跨对 SEQ 必须连续递增, 跳号就是精确的丢帧数。
    """

    def __init__(self, on_pair=None):
        self.pending = None          # 暂存的 (seq, 0x01 数据)
        self.last_seq = None         # 上一对成功配对的 SEQ
        self.on_pair = on_pair
        self.stats = PairStats()

    def feed(self, ftype: int, seq: int, data: bytes) -> None:
        if ftype == TYPE_RAW:
            if self.pending is not None:
                # 上一个 0x01 还没等到 0x02, 现在又来了 0x01 => 中间那个 0x02 丢了
                self.stats.pairing_errors += 1
            self.pending = (seq, data)

        elif ftype == TYPE_FILT:
            if self.pending is None:
                self.stats.orphan_filt += 1
                return
            rseq, rdata = self.pending
            if rseq != seq:
                # ★ 同一对的两个 SEQ 不等 -> 这就是"错配", 必须丢弃
                self.stats.seq_mismatch += 1
                self.pending = None
                return
            if len(rdata) != len(data):
                self.stats.length_mismatch += 1
                self.pending = None
                return
            self.pending = None

            # ---- 跨对 SEQ 连续性 -> 精确丢帧计数 ----
            if self.last_seq is not None:
                gap = (seq - self.last_seq) & 0xFFFF
                if gap == 0:
                    self.stats.seq_duplicate += 1
                elif gap > 1:
                    self.stats.seq_gaps += 1
                    self.stats.pairs_lost += (gap - 1) & 0xFFFF
            self.last_seq = seq
            self.stats.pairs_ok += 1
            if self.on_pair is not None:
                self.on_pair(rdata, data, seq)

        else:  # 调试帧
            if self.pending is not None:
                self.stats.debug_interrupt += 1

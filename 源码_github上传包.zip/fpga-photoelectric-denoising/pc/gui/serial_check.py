# -*- coding: utf-8 -*-
r"""
================================================================================
 串口自检: 接上板子后 30 秒内判断"921600 到底行不行"
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py serial_check.py                       # 自动列出串口
    py serial_check.py COM10                 # 测 COM10, 默认 10 秒
    py serial_check.py COM10 20              # 测 20 秒

它报四件事 (顺序就是排查顺序):
  1) 能不能打开口 / 波特率设不设得进去
  2) 实测字节率 vs 理论上限 92160 B/s (差太多 -> 波特率或驱动有问题)
  3) 这些字节能不能解析成帧 (校验错/失步 = 数据本身坏了)
  4) 成对、SEQ 是否连续 (协议层对不对)

判据:
  · 字节率 ≈ 53494 B/s (58% 占用) 且 校验错=0  -> 链路健康
  · 字节率明显偏低但校验错=0                  -> 板子在丢帧, 不是波特率问题
  · 字节率对但校验错很多                      -> 波特率/线材/共地 问题
  · 一个字节都收不到                          -> 口选错 / 波特率差太多 / 没发数据

为什么不用"回环发固定图案": 那需要板子那边配合改固件。
这里直接用【真实数据流】判断, 板子不需要任何改动。
================================================================================
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from data_sources import BYTE_RATE, FS_OUT_CONFIRMED, list_ports  # noqa: E402
from frame_proto import FrameParser, PairAssembler  # noqa: E402


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    try:
        import serial
    except ImportError:
        print("没装 pyserial: py -m pip install pyserial")
        raise SystemExit(1)

    args = sys.argv[1:]
    if not args:
        print("=" * 74)
        print(" 可用串口")
        print("=" * 74)
        ports = list_ports()
        if not ports:
            print("  一个都没有。检查: USB 线插好没有 / CP210x 驱动装了没有")
            print("  驱动在 fpga_denoise\\drivers\\ 目录下")
            raise SystemExit(1)
        for dev, desc in ports:
            print(f"  {dev:<10} {desc}")
        print("")
        print("  用法: py serial_check.py COM10 [秒数]")
        return

    port = args[0]
    secs = float(args[1]) if len(args) > 1 else 10.0
    baud = 921600

    print("=" * 74)
    print(f" 串口自检: {port} @ {baud} 8N1, 采 {secs:.0f} 秒")
    print("=" * 74)

    try:
        sp = serial.Serial(port=port, baudrate=baud, bytesize=8, parity="N",
                          stopbits=1, timeout=0.05)
    except Exception as e:
        print(f"  ✗ 打不开: {e}")
        raise SystemExit(1)
    print(f"  口已打开, 实际波特率设置 = {sp.baudrate}")

    stats = {"ok": 0, "ck": 0, "sync": 0, "pairs": 0, "first": None, "last": None}

    def on_pair(r, f, seq):
        stats["pairs"] += 1
        stats["last"] = seq
        if stats["first"] is None:
            stats["first"] = seq

    asm = PairAssembler(on_pair=on_pair)
    fp = FrameParser(on_frame=asm.feed)

    t0 = time.perf_counter()
    total = 0
    last_rep = t0
    while time.perf_counter() - t0 < secs:
        n = sp.in_waiting
        if n:
            buf = sp.read(min(n, 65536))
            total += len(buf)
            fp.feed(buf)
        else:
            time.sleep(0.005)
        now = time.perf_counter()
        if now - last_rep >= 1.0:
            last_rep = now
            el = now - t0
            print(f"  [{el:4.1f}s] {total:>8} B ({total / el:>7.0f} B/s) | "
                  f"好帧 {fp.stats.frames_ok:>5} | 校验错 {fp.stats.checksum_errors:>4} | "
                  f"配对 {stats['pairs']:>5}")
    sp.close()

    el = time.perf_counter() - t0
    ps, qs = fp.stats, asm.stats
    print("")
    print("-" * 74)
    print(" 结果")
    print("-" * 74)
    print(f"  收到字节   : {total} = {total / el:.0f} B/s "
          f"(理论上限 {BYTE_RATE:.0f} B/s, 数据流应有约 53494 B/s = 58%)")
    print(f"  好帧       : {ps.frames_ok}   校验错 {ps.checksum_errors}   "
          f"失步 {ps.sync_errors}   垃圾 {ps.garbage_bytes}")
    print(f"  配成       : {stats['pairs']} 对   "
          f"配对错 {qs.pairing_errors}   孤儿 {qs.orphan_filt}   "
          f"SEQ跳号丢 {qs.pairs_lost} 对")
    if stats["pairs"]:
        print(f"  SEQ        : {stats['first']} .. {stats['last']}")
        rate = stats["pairs"] * 64 / el
        print(f"  实测样本率 : {rate:.0f} S/s (期望 {FS_OUT_CONFIRMED:.0f})")
    print("")
    print("  判定:")
    if total == 0:
        print("    ✗ 一个字节都没收到 -> 口选错 / 波特率不匹配 / 板子没在发")
    elif ps.checksum_errors > ps.frames_ok * 0.02:
        print("    ✗ 校验错太多 -> 波特率/线材/共地 问题, 先降到 460800 试")
    elif total / el < 30000:
        print("    ⚠ 字节率偏低但校验通过 -> 板子在丢帧, 不是波特率问题")
    else:
        print("    ✓ 链路健康: 字节率正常、校验全过")


if __name__ == "__main__":
    main()

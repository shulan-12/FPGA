# -*- coding: utf-8 -*-
r"""
================================================================================
 上位机 / 数据源: 假数据源(模拟 FPGA) + 真实串口源
================================================================================
两个数据源对界面是【同一个接口】: read(max_bytes) -> bytes
所以"先用假数据打通, 硬件到了直接换源"是真的换一行配置, 不用改界面逻辑。

【假数据源】为什么不能只发随机数:
    要验证的是"上位机能不能正确解析真实帧流", 所以假数据必须和 FPGA 发出的一样:
      · 同样的信号与噪声参数 (复刻 sim/pd_src.v)
      · 同样的定点 FIR 运算 (Q1.15 整数, 和 rtl/denoise_filter.v 逐位等价)
      · 同样的抽点 ÷8 -> 12.5 kSPS
      · 同样的 64 个采样点群延迟对齐
      · 同样的成对帧结构 (0x01 原始 + 0x02 滤波后, 各 64 点 = 133 字节)
      · 同样的字节节奏 (921600 波特 -> 92160 字节/秒)
    并且可以【注入故障】(丢帧 / 丢字节 / 破坏校验和), 用来验证丢帧检查真的抓得住。

【真实串口源】pyserial 是可选的。
    今天这一步(假数据打通)【不需要装任何东西】—— tkinter 是标准库, matplotlib 已有。
    等硬件到了, 一条命令装 pyserial 即可: py -m pip install pyserial
================================================================================
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from gui.frame_proto import (TYPE_FILT, TYPE_RAW, build_frame,  # noqa: E402
                             frame_bytes)

# ---- 和板卡侧一致的参数 ----
FS_HW = 100_000            # 硬件 ADC 采样率 Hz (AD7606)
FRAME_POINTS = 64          # 每帧 64 个采样点 -> 帧长 135 字节 (含 2 字节 SEQ)
NUMTAPS = 129
GROUP_DELAY = 64           # (129-1)/2, 群延迟(采样点)
BAUD = 921600
BYTE_RATE = BAUD / 10.0    # 8N1: 92160 字节/秒 —— 这是【上限】, 不是数据产生速率

# ★★ 显示采样率 —— 经【调制周期标尺】复核后定为 12.5 kSPS (设计值)
#
#   2026-10-31 更正: 此前 A 报 12.68 kSPS、我据此算调制为 1014.4 Hz。
#   用两个【互不依赖采样率】的量一交叉, 结论是 12.5 kSPS:
#     ① 调制周期 = 12.4995 个采样点   (FFT 峰 + 两段相位差, 单位是采样点, 与 fs 无关)
#     ② 调制频率 = 999.996 Hz          (mod_gen.v 的 DDS: 85899*50e6/2^32, 与 fs 无关)
#     => fs = 999.996 * 12.4995 = 12499.5 Hz
#     若 fs=12500, 反推调制 999.96 Hz, 与 DDS 差 -0.004%  ✓
#     若 fs=12680, 反推调制 985.76 Hz, 要 50 MHz 晶振偏 -1.42% ✗ 不可能
#
#   另一条佐证: 50e6/100e3 = 500 是【整数】, ADC 的 CONV 分频不需要取整,
#   所以 100 kSPS 是精确的 -> 8 倍抽点 = 12.5 kSPS 精确。
#   复核脚本: pc/gui/check_sample_rate.py
#
#   ★ 影响面: 这个数只影响"横轴刻度"和"频率读数"。所有以 LSB 为单位的结论
#     (SNR、保留率、谐波百分比、频段占比) 都是比值, 不受影响。
#     若以后实测值再变, 改这里一处 + 命令行 --fsout。
FS_OUT_CONFIRMED = 12_500.0

# ADC 侧抽点比是【整数 8】。ADC 实际转换速率 = 12500*8 = 100 kHz (设计值, 分频精确)。
DECIM = 8
FS_ADC = FS_OUT_CONFIRMED * DECIM


def bytes_per_point(frame_points: int = FRAME_POINTS) -> float:
    """每个时间点(原始+滤波后各一个值)要占多少字节。

    一对帧 = 2 x 单帧字节数, 覆盖 frame_points 个点。
    新协议单帧 = 6(帧头含SEQ) + 2*frame_points + 1(校验和)
    frame_points=64 时: 2*135/64 = 4.21875 字节/点
    """
    return 2.0 * frame_bytes(frame_points) / frame_points


def data_rate(fs_out: float, frame_points: int = FRAME_POINTS) -> float:
    """数据【产生】速率 (字节/秒) —— 由采样率决定, 不是由波特率决定。

    ★ 这两个概念必须分清:
        FPGA 每秒产生多少个时间点, 是被 ADC 采样率限死的 (实测 12.68 kSPS)
        -> 每秒要发 12680 * 4.21875 = 53494 字节
        而串口 921600 波特只能发 92160 字节/秒
        => 占用 58.0%, 剩下的 42% 是串口空闲时间, 不是"可以多发数据"
      把二者搞混, 假数据源就会以 1.77 倍的速度灌数据 (这正是第一版的 bug)。
    """
    return fs_out * bytes_per_point(frame_points)

TYPE_PAIR = {"raw": TYPE_RAW, "filt": TYPE_FILT}
TRUTH_SKIP = 512           # 统计真值时跳过开头的启动瞬态 (显示点数)


def q15_coeffs() -> np.ndarray:
    """取 129 抽头 FIR 的 Q1.15 整数系数 (和 rtl/denoise_filter.v 里的表一致)。"""
    txt = Path(__file__).resolve().parent.parent / "out" / "fir_coeffs_q15.txt"
    if txt.exists():
        return np.array([int(x) for x in txt.read_text().split()], dtype=np.int64)
    # 兜底: 用同样的方法现算 (结果相同, 只是慢一点)
    from scipy.signal import firwin
    b = firwin(NUMTAPS, 3500.0, fs=FS_HW, window="hamming")
    return np.trunc(b * 32768.0 + np.where(b >= 0, 0.5, -0.5)).astype(np.int64)


class Source:
    """数据源接口。"""

    name = "source"

    def read(self, max_bytes: int) -> bytes:
        raise NotImplementedError

    def close(self) -> None:
        pass


class FakeFpgaSource(Source):
    """模拟 FPGA 的帧流。按真实字节率出数据, 保证界面的实时行为也被验证到。"""

    name = "假数据 (模拟 FPGA)"

    def __init__(self,
                 f_sig: float = 1562.5,
                 amp: int = 3000,
                 noise_amp: int = 40,
                 seed: int = 0xDEADBEEF,
                 frame_points: int = FRAME_POINTS,
                 fs_out: float = FS_OUT_CONFIRMED,
                 baud: int = BAUD,
                 block_pairs: int = 16,
                 drop_frame_prob: float = 0.0,
                 drop_pair_prob: float = 0.0,
                 corrupt_prob: float = 0.0,
                 drop_byte_prob: float = 0.0,
                 realtime: bool = True):
        self.period = int(round(FS_HW / f_sig))
        self.amp = amp
        self.noise_amp = noise_amp
        self.frame_points = frame_points
        self.baud = baud
        self.block_pairs = block_pairs
        self.realtime = realtime
        # ★ 显示采样率用【实测确认值】(12.68 kSPS), 不是 100k/8。
        #   抽点比保持【整数 8】, 反过来推 ADC 实际速率 = fs_out*8 ≈ 101.44 kHz。
        #   (用非整数抽点去凑 12.68k 会引入采样抖动, 把 SNR 压低 4~5 dB, 已实测)
        self.fs_out = float(fs_out)
        self.decim = DECIM
        self.fs_adc = self.fs_out * self.decim

        # 故障注入概率 (默认全 0 = 干净流)
        self.drop_frame_prob = drop_frame_prob
        self.drop_pair_prob = drop_pair_prob
        self.corrupt_prob = corrupt_prob
        self.drop_byte_prob = drop_byte_prob

        self.rng = np.random.default_rng(seed)
        self.coef = q15_coeffs()
        self.seq_next = 1          # 采集轮次号, 初始 1 (与 A 的真实 dump 一致)

        # ★ 带宽自检: 数据产生速率不能超过串口线速率。
        #   这条检查就是当初能在代码里抓住"115200 带不动"的那种检查。
        self.rate = data_rate(self.fs_out, frame_points)
        self.line_rate = baud / 10.0
        if self.rate > self.line_rate:
            raise ValueError(
                f"带宽不够: 数据需要 {self.rate:.0f} B/s, 而 {baud} 波特只能发 "
                f"{self.line_rate:.0f} B/s (占用 {self.rate / self.line_rate * 100:.0f}%)。"
                f" 请降低抽点倍率或提高波特率。")

        # 正弦用【解析式】直接算, 不用固定点数查表:
        #   固定表会把信号频率和采样率绑死 (表长 64 -> 频率只能是 fs_adc/64);
        #   真实板卡的调制频率来自信号发生器, 与采样率无关, 所以用解析式更贴近实际。
        self.f_sig = float(f_sig)

        self.hist = np.zeros(NUMTAPS - 1, dtype=np.int64)   # 滤波器历史 (跨块保持)
        self.n_in = 0                                        # 已生成的输入样本数
        self.buf = bytearray()                               # 待发送字节
        self.sent = 0
        self.t0 = time.perf_counter()

        # 真值累计 (给开发期自校验用: 界面估计的 SNR vs 这里的真值)
        # n_out: 已产出的【显示样本总数】(用来推进"跳过启动瞬态"的计数,
        #        不能拿 n 代替 —— 块小于 TRUTH_SKIP 时 n 会永远是 0, 真值就永远算不出来)
        self.truth = dict(sig=0.0, noi_raw=0.0, noi_filt=0.0, n=0, n_out=0)
        self.counters = dict(pairs_gen=0, frames_dropped=0, pairs_dropped=0,
                             bytes_dropped=0, bytes_corrupted=0)

    # ---------------- 信号生成 ----------------
    def _sine(self, idx: np.ndarray) -> np.ndarray:
        """按解析式生成正弦 (频率和采样率解耦, 与真实调制信号一致)。"""
        return np.round(self.amp * np.sin(2.0 * np.pi * self.f_sig
                                          * idx.astype(np.float64) / self.fs_adc)
                        ).astype(np.int64)

    def _noise(self, n: int) -> np.ndarray:
        u = self.rng.integers(-128, 128, size=n).astype(np.int64)
        return np.floor_divide(u * self.noise_amp, 128)

    def _gen_block(self, n_pairs: int | None = None) -> None:
        """生成 n_pairs 对帧 (默认 block_pairs), 追加到待发缓冲区。

        允许只生成"差的那几对", 这样按采集节拍推进时不会超前整整一块
        (否则样本率口径会显示一个恒定的负缺口)。
        """
        npairs = self.block_pairs if n_pairs is None else max(1, int(n_pairs))
        n_out = npairs * self.frame_points
        n_in = n_out * self.decim            # ★ 整数抽点 (8), 不引入采样抖动

        idx = np.arange(self.n_in, self.n_in + n_in, dtype=np.int64)
        clean = self._sine(idx)
        noise = self._noise(n_in)
        code = clean + noise

        # 整数 FIR: 与 rtl/denoise_filter.v 逐位等价 (累加完再算术右移 15 位 + 饱和)
        x = np.concatenate([self.hist, code])
        conv = np.convolve(x, self.coef)                     # int64 精确卷积
        y = np.clip(conv >> 15, -32768, 32767)
        self.hist = x[-(NUMTAPS - 1):].copy()

        # 对齐: y[m] 对应 u[m-64], 所以与 raw 同位的滤波值是 y[j + 64 + len(hist)]
        H = NUMTAPS - 1
        j = np.arange(n_out, dtype=np.int64) * self.decim     # 整数抽点
        raw_disp = code[j]
        filt_disp = y[j + GROUP_DELAY + H]

        # ---- 真值 (给开发期校验界面估计值用) ----
        # ★ 必须用【双实例法】算噪声: FIR(clean+noise) − FIR(clean) ≡ FIR(noise)。
        #   第一版偷懒用"滤波后 − 理想正弦"当噪声, 结果把滤波器 0.087% 的通带增益误差
        #   (一个确定性失真, 不是噪声) 也算进去了, 真值被压低约 1.3 dB, 看起来像估计器有偏。
        #   双实例法和板卡侧验证台用的是同一套方法, 口径一致才能对比。
        sel = j + GROUP_DELAY + H
        if not hasattr(self, "hist_clean"):
            self.hist_clean = np.zeros(H, dtype=np.int64)
        xc = np.concatenate([self.hist_clean, clean])
        yc = np.clip(np.convolve(xc, self.coef) >> 15, -32768, 32767)
        self.hist_clean = xc[-(NUMTAPS - 1):].copy()

        # ★ 跳过启动瞬态时, 推进计数用【已产出的总点数 n_out】, 不能用 n。
        #   否则: 如果一次只生成 1 对 (=64 点) < TRUTH_SKIP(512),
        #   start 永远等于 512, 切片永远为空, n 永远加不上去 -> 真值永远算不出来,
        #   界面就会一直显示"样本不足"。这个 bug 在按节拍小步生成时才暴露。
        seen = int(self.truth["n_out"])
        start = max(0, TRUTH_SKIP - seen)
        if start < n_out:
            sig = clean[j].astype(np.float64)[start:]
            noise_out = (y[sel] - yc[sel]).astype(np.float64)[start:]
            self.truth["sig"] += float(np.sum(sig ** 2))
            self.truth["noi_raw"] += float(np.sum((raw_disp[start:] - sig) ** 2))
            self.truth["noi_filt"] += float(np.sum(noise_out ** 2))
            self.truth["n"] += len(sig)
        self.truth["n_out"] = seen + n_out

        self.n_in += n_in

        # 留一份本块的原始数组, 供诊断脚本逐项对账用 (不参与发送)
        self.last_block = dict(sig=clean[j].astype(np.float64),
                               raw=raw_disp.astype(np.float64),
                               filt=filt_disp.astype(np.float64))

        # 打包成帧: 每帧 64 点, 成对 (0x01 原始 -> 0x02 滤波后)
        # ★ 新协议: 同一轮的两帧【共用同一个 SEQ】, 跨轮 SEQ 递增
        for i in range(npairs):
            a = i * self.frame_points
            b = a + self.frame_points
            seq = (self.seq_next + i) & 0xFFFF
            pair = (build_frame(TYPE_RAW, raw_disp[a:b].tolist(), seq)
                    + build_frame(TYPE_FILT, filt_disp[a:b].tolist(), seq))
            self._inject(pair)
            self.counters["pairs_gen"] += 1
        self.seq_next = (self.seq_next + npairs) & 0xFFFF

    def _inject(self, pair_wo_faults: bytes) -> None:
        """把一个"一对帧"(2 x 135 = 270 字节)注入故障后放进发送缓冲。"""
        # 丢整对: 上位机【看不见】任何异常帧, 只能从样本率下降发现 (最难查的情况)
        if self.drop_pair_prob and self.rng.random() < self.drop_pair_prob:
            self.counters["pairs_dropped"] += 1
            return
        data = bytearray(pair_wo_faults)

        # 丢单帧: 一对 = 2 x FL, 前半是 0x01 原始帧, 后半是 0x02 滤波帧
        FL = frame_bytes(self.frame_points)
        if self.drop_frame_prob and self.rng.random() < self.drop_frame_prob:
            which = self.rng.integers(0, 2)
            del data[which * FL:(which + 1) * FL]
            self.counters["frames_dropped"] += 1

        # 破坏一个字节 -> 校验和应该抓住
        if self.corrupt_prob and self.rng.random() < self.corrupt_prob and len(data) > 5:
            k = int(self.rng.integers(4, len(data)))     # 避开同步头
            data[k] ^= 0x01
            self.counters["bytes_corrupted"] += 1

        # 丢一个字节 -> 应该失步并重新同步
        if self.drop_byte_prob and self.rng.random() < self.drop_byte_prob and len(data) > 5:
            k = int(self.rng.integers(4, len(data)))
            del data[k]
            self.counters["bytes_dropped"] += 1

        self.buf += data

    # ---------------- 对外接口 ----------------
    def read(self, max_bytes: int) -> bytes:
        if self.realtime:
            # ★ 按【采集轮次】节拍产生数据: 真实板卡每秒固定产出
            #   fs_out / frame_points = 12500/64 = 195.3 对, 丢帧不会让它"多发"。
            #   (第一版按"字节欠账"推进 —— 注入故障后会多生成数据把字节数补齐,
            #    于是"样本率口径看不出丢帧"、却和 SEQ 精确计数矛盾。真实板卡不会这样。)
            target = int((time.perf_counter() - self.t0)
                         * (self.fs_out / self.frame_points))
            guard = 0
            while self.counters["pairs_gen"] < target and guard < 64:
                need = min(self.block_pairs, target - self.counters["pairs_gen"])
                self._gen_block(need)      # 只补差的那几对, 不超前
                guard += 1
            # 防意外堆积 (例如界面卡住很久)
            if len(self.buf) > 256 * 1024:
                del self.buf[:len(self.buf) - 256 * 1024]
        else:
            while len(self.buf) < max_bytes and len(self.buf) < 512 * 1024:
                self._gen_block()

        out = bytes(self.buf[:max_bytes])
        del self.buf[:max_bytes]
        self.sent += len(out)
        return out

    def true_snr(self):
        """(原始, 滤波后) 的【真实】信噪比, 用于开发期校验界面估计值。"""
        if self.truth["n"] == 0:
            return None
        n = self.truth["n"]
        s = self.truth["sig"] / n
        if self.truth["noi_raw"] <= 0 or self.truth["noi_filt"] <= 0:
            return None
        return (10 * np.log10(s / (self.truth["noi_raw"] / n)),
                10 * np.log10(s / (self.truth["noi_filt"] / n)))


class SerialSource(Source):
    """真实串口源。pyserial 可选: 没装时给出清晰提示而不是崩掉。"""

    def __init__(self, port: str, baud: int = BAUD):
        try:
            import serial   # 延迟导入, 保证假数据模式不需要 pyserial
        except ImportError as e:
            raise RuntimeError(
                "没有安装 pyserial。接真实串口前请执行: py -m pip install pyserial\n"
                "(假数据模式不需要它)") from e
        self.name = f"串口 {port} @ {baud}"
        self.port = serial.Serial(port=port, baudrate=baud, bytesize=8,
                                  parity="N", stopbits=1, timeout=0)

    def read(self, max_bytes: int) -> bytes:
        n = min(self.port.in_waiting, max_bytes)
        return self.port.read(n) if n > 0 else b""

    def close(self) -> None:
        try:
            self.port.close()
        except Exception:
            pass


def list_ports():
    """可用串口列表 (没装 pyserial 就返回空)。"""
    try:
        import serial.tools.list_ports as lp
        return [(p.device, p.description) for p in lp.comports()]
    except Exception:
        return []


class FileSource(Source):
    """回放一个真实抓包 .bin —— 这份数据是【真实硬件采到的】, 不是仿真。

    用途: 板子不在手边时, 让界面跑真实数据出图/演示。
    会按真实速率 (fs_out * bytes_per_point) 喂字节, 所以界面上的
    样本率、帧率、刷新节奏都和接真机时一致。
    """

    def __init__(self, path, fs_out: float = FS_OUT_CONFIRMED, loop: bool = True,
                 frame_points: int = FRAME_POINTS):
        p = Path(path)
        data = p.read_bytes()
        # 从第一个同步头开始, 跳过起始的半帧
        k = data.find(b"\xAA\x55")
        data = data[k:] if k > 0 else data
        # ★ 截到整帧边界: 循环回放时若在帧中间绕回, 会产生一个截断帧
        #   (表现为"校验错 1"), 报告图上很难看。按 135 字节整帧截断后,
        #   绕回点一定在帧边界上, 不会切出半个帧。
        nfr = len(data) // 135
        self.data = data[:nfr * 135] if nfr else data
        self.name = f"真实抓包回放: {p.name}"
        self.fs_out = float(fs_out)
        self.loop = loop
        self.rate = data_rate(self.fs_out, frame_points)
        self.i = 0
        self.sent = 0
        self.t0 = time.perf_counter()
        # 循环回放时数据会从头开始, SEQ 会跳回去 —— 那是回放造成的, 不是真丢帧。
        # 所以绕回时通知外部重置 SEQ 计数, 否则界面会显示"丢了 6 万对"。
        self.on_wrap = None

    def read(self, max_bytes: int) -> bytes:
        target = int((time.perf_counter() - self.t0) * self.rate)
        want = target - self.sent
        if want <= 0:
            return b""
        n = min(want, max_bytes, len(self.data) - self.i)
        if n <= 0:
            if self.loop and self.data:
                self.i = 0
                if self.on_wrap is not None:
                    self.on_wrap()
                n = min(want, max_bytes, len(self.data))
            else:
                return b""
        chunk = self.data[self.i:self.i + n]
        self.i += n
        self.sent += n
        return chunk

    def close(self) -> None:
        pass

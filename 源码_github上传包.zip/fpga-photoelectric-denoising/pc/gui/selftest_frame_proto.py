# -*- coding: utf-8 -*-
r"""
================================================================================
 上位机 / 协议层自测: 解析状态机 + 成对帧状态机 + SEQ 丢帧计数
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py selftest_frame_proto.py

为什么先测这个:
    界面画错图一眼能看出来, 但【配对配错】看不出来 —— 拿 A 段的原始去配 B 段的
    滤波后, 画出来的"降噪对比图"看着完全正常, 结论却是假的。
    所以配对逻辑必须在接硬件之前用构造的坏帧流测透。

测试项:
    1  正常收发: 打包 -> 解析 -> 数值逐位相同 (含 ±32767 / -32768 边界)
    2  数据里含完整假帧头: 不许误同步, 且能恢复
    3  逐字节喂 vs 整块喂: 结果必须一样 (流式的基本要求)
    4  前面有垃圾字节: 能重新同步, 不产生坏帧
    5  字节被破坏: 校验和必须抓住
    6  数据帧长度非法(奇数/0/超长): 必须拒绝
    7  ★丢掉 0x02: 必须报配对错, 且【绝不产生错配的一对】
    8  丢掉 0x01: 那个 0x02 必须被当成孤儿丢弃
    9  ★同一对两帧 SEQ 不等: 必须判为 SEQ 错配并丢弃
   10  ★SEQ 跳号: 必须精确数出丢了几对 (不再是估算)
   11  帧尾被截断: 不许产出半截数据
   12  调试帧不参与配对
   13  ★★★ 真实 FPGA dump 回归: 解 A 留下的 adc_stream_dump.bin
================================================================================
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from frame_proto import (SYNC1, SYNC2, TYPE_DEBUG, TYPE_FILT, TYPE_RAW,  # noqa: E402
                         FrameParser, PairAssembler, build_frame,
                         frame_bytes, parse_samples)

DUMP = HERE.parent.parent / "tools" / "adc_stream_dump.bin"
results = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {detail}" if detail else ""))


def collect(stream: bytes):
    """喂一段字节流, 返回 (配好的对列表, 解析统计, 配对统计)。"""
    pairs = []
    fa = PairAssembler(on_pair=lambda r, f, s: pairs.append((parse_samples(r),
                                                            parse_samples(f), s)))
    fp = FrameParser(on_frame=fa.feed)
    fp.feed(stream)
    return pairs, fp.stats, fa.stats


def seg(n: int, v: int):
    """造一段内容可辨认的数据: 每个值都是 v, 便于检查有没有错配。"""
    return [v] * n


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    print("=" * 78)
    print(" 协议层自测 (新协议: 帧头 AA 55 TYPE LEN SEQ_L SEQ_H, 校验和含 LEN 与 SEQ)")
    print("=" * 78)

    # ---- 1 正常收发 + 数值边界 ----
    vals = [-32768, -1, 0, 1, 1562, 32767] + list(range(-30, 30))
    st = build_frame(TYPE_RAW, vals, seq=7)
    got = []
    fp = FrameParser(on_frame=lambda t, s, d: got.append((t, s, parse_samples(d))))
    fp.feed(st)
    check("1 正常收发/数值逐位一致 (含 SEQ)",
          len(got) == 1 and got[0][0] == TYPE_RAW and got[0][1] == 7
          and got[0][2] == vals,
          f"帧长 {len(st)} B (期望 {frame_bytes(len(vals))}), "
          f"seq={got[0][1] if got else None}")

    # ---- 2 数据里含 0xAA 0x55, 不许误同步 ----
    trap = [0x55AA, -32767, 0x55AA, -32767, 1, 2, 3, 4]
    real_frame = build_frame(TYPE_RAW, trap, seq=1)
    # ★ 假帧必须【长度自洽】: 6(帧头) + 6(数据) + 1(校验和) = 13 字节,
    #   只是校验和故意写错。长度不自洽的话解析器会被它带偏、吃掉真帧的第一个字节,
    #   那就测不出"误同步后能否恢复"了 (第一版这里写少了 2 字节, 测出的是假故障)。
    fake_frame = (bytes([SYNC1, SYNC2, TYPE_RAW, 6, 0, 0])
                  + bytes([1, 0, 2, 0, 3, 0]) + bytes([0x00]))
    pairs, st_, pt = collect(fake_frame + real_frame
                             + build_frame(TYPE_FILT, seg(8, 7), seq=1))
    check("2 载荷含完整假帧头: 不误同步且能恢复",
          st_.checksum_errors >= 1 and len(pairs) == 1 and pairs[0][0] == trap,
          f"校验错 {st_.checksum_errors}, 成对 {len(pairs)}")

    # ---- 3 逐字节喂 = 整块喂 ----
    stream = (build_frame(TYPE_RAW, seg(8, 111), seq=1)
              + build_frame(TYPE_FILT, seg(8, 222), seq=1)
              + build_frame(TYPE_RAW, seg(8, 333), seq=2)
              + build_frame(TYPE_FILT, seg(8, 444), seq=2))
    pairs_a, _, _ = collect(stream)
    pairs_b = []
    fa = PairAssembler(on_pair=lambda r, f, s: pairs_b.append((parse_samples(r),
                                                              parse_samples(f), s)))
    fp = FrameParser(on_frame=fa.feed)
    for i in range(len(stream)):
        fp.feed(stream[i:i + 1])
    check("3 逐字节喂 == 整块喂", pairs_a == pairs_b and len(pairs_a) == 2,
          f"{len(pairs_a)} 对 vs {len(pairs_b)} 对")

    # ---- 4 前面有垃圾 ----
    pairs, st_, pt = collect(bytes([0x11, 0x22, 0xAA, 0x33, 0x44]) + stream)
    check("4 前置垃圾字节可重新同步",
          len(pairs) == 2 and st_.checksum_errors == 0,
          f"垃圾 {st_.garbage_bytes} B, 失步 {st_.sync_errors}")

    # ---- 5 字节被破坏 -> 校验和抓住 ----
    bad = bytearray(stream)
    bad[20] ^= 0x01
    pairs, st_, pt = collect(bytes(bad))
    check("5 坏字节被校验和抓住",
          st_.checksum_errors >= 1 and len(pairs) < 2,
          f"校验错 {st_.checksum_errors}, 配成 {len(pairs)} 对")

    # ---- 6 长度非法 ----
    bad6 = (bytes([SYNC1, SYNC2, TYPE_RAW, 7]) + bytes(9)
            + bytes([SYNC1, SYNC2, TYPE_RAW, 0])
            + bytes([SYNC1, SYNC2, TYPE_RAW, 0xFF]))
    pairs, st_, pt = collect(bad6)
    check("6 非法长度被拒绝 (奇数/0/超长)",
          st_.bad_len == 3 and len(pairs) == 0,
          f"坏长度 {st_.bad_len} (应为 3)")

    # ---- 7 ★ 丢掉 0x02: 必须报错, 且绝不错配 ----
    NSEG = 8
    FLEN = frame_bytes(NSEG)
    p1 = (build_frame(TYPE_RAW, seg(NSEG, 101), seq=1)
          + build_frame(TYPE_FILT, seg(NSEG, 201), seq=1))
    p2 = (build_frame(TYPE_RAW, seg(NSEG, 102), seq=2)
          + build_frame(TYPE_FILT, seg(NSEG, 202), seq=2))
    p3 = (build_frame(TYPE_RAW, seg(NSEG, 103), seq=3)
          + build_frame(TYPE_FILT, seg(NSEG, 203), seq=3))
    pairs, st_, pt = collect(p1 + p2[:FLEN] + p3)
    mispaired = [(r, f) for r, f, s in pairs
                 if not (len(set(r)) == 1 and len(set(f)) == 1
                         and r[0] - 100 == f[0] - 200)]
    check("7 ★丢掉 0x02: 报配对错且不错配",
          pt.pairing_errors == 1 and len(mispaired) == 0 and len(pairs) == 2,
          f"配对错 {pt.pairing_errors}, 成对 {len(pairs)}, 错配 {len(mispaired)}")

    # ---- 8 丢掉 0x01: 那个 0x02 成孤儿 ----
    pairs, st_, pt = collect(p1[FLEN:] + p2 + p3)
    check("8 丢掉 0x01: 孤儿帧被丢弃",
          pt.orphan_filt == 1 and len(pairs) == 2,
          f"孤儿 {pt.orphan_filt}, 成对 {len(pairs)}")

    # ---- 9 ★ 同一对两帧 SEQ 不等 ----
    bad9 = (build_frame(TYPE_RAW, seg(NSEG, 111), seq=5)
            + build_frame(TYPE_FILT, seg(NSEG, 222), seq=6))
    pairs, st_, pt = collect(bad9)
    check("9 ★同一对 SEQ 不等: 判为错配并丢弃",
          pt.seq_mismatch == 1 and len(pairs) == 0,
          f"SEQ错配 {pt.seq_mismatch}, 成对 {len(pairs)} (应为 0)")

    # ---- 10 ★ SEQ 跳号: 精确数出丢了几对 ----
    # 发 seq 1,2,3, 然后直接跳到 seq 8 -> 中间 4,5,6,7 共 4 对丢了
    s10 = b""
    for sq in (1, 2, 3, 8):
        s10 += (build_frame(TYPE_RAW, seg(NSEG, 100 + sq), seq=sq)
                + build_frame(TYPE_FILT, seg(NSEG, 200 + sq), seq=sq))
    pairs, st_, pt = collect(s10)
    check("10 ★SEQ 跳号: 精确数出丢失对数",
          len(pairs) == 4 and pt.pairs_lost == 4 and st_.checksum_errors == 0,
          f"成对 {len(pairs)}, 精确丢失 {pt.pairs_lost} 对 (应 4), "
          f"跳号 {pt.seq_gaps} 次")

    # ---- 11 帧尾截断 ----
    pairs, st_, pt = collect(stream + p1[:FLEN - 3])
    check("11 帧尾截断不产出半截数据",
          len(pairs) == 2, f"成对 {len(pairs)}")

    # ---- 12 调试帧 ----
    s12 = (build_frame(TYPE_RAW, seg(NSEG, 505), seq=1)
           + build_frame(TYPE_DEBUG, b"hi", seq=1)
           + build_frame(TYPE_FILT, seg(NSEG, 605), seq=1))
    pairs, st_, pt = collect(s12)
    check("12 调试帧不参与配对且不打断成对",
          len(pairs) == 1 and pt.debug_interrupt == 1,
          f"成对 {len(pairs)}, 打断 {pt.debug_interrupt}")

    # ---- 13 ★★★ 真实 FPGA dump 回归 ----
    # 这份 dump 是 A 在 ModelSim 里跑真实链路 (ad7606_model -> ad7606_if -> FIR ->
    # 双缓冲 -> 串口) 存下来的 540 字节, 不是手搓的, 比自造帧更能反映真实情况。
    # 已知内容: 输入是恒定 1000 的直流, 所以
    #   raw 帧 64 个样本全 = 1000
    #   flt 帧 64 个样本全 = 999   <- 这就是滤波器直流增益 0.999908 的体现
    #                                  (1000 x 0.999908 = 999.9 -> 定点右移截断 = 999)
    #   两对帧的 seq 分别是 1 和 2
    if not DUMP.exists():
        check("13 真实 dump 回归", False, f"找不到 {DUMP}")
    else:
        raw_bytes = DUMP.read_bytes()
        pairs, st_, pt = collect(raw_bytes)
        seqs = [s for _, _, s in pairs]
        raw_ok = all(len(r) == 64 and set(r) == {1000} for r, f, _ in pairs)
        flt_ok = all(len(f) == 64 and set(f) == {999} for r, f, _ in pairs)
        check("13 ★真实 FPGA dump 回归 (540B = 4 帧 = 2 对)",
              st_.frames_ok == 4 and st_.checksum_errors == 0
              and st_.garbage_bytes == 0 and len(pairs) == 2
              and seqs == [1, 2] and raw_ok and flt_ok and pt.pairs_lost == 0,
              f"好帧 {st_.frames_ok}/4, 校验错 {st_.checksum_errors}, "
              f"垃圾 {st_.garbage_bytes}, 成对 {len(pairs)}, seq={seqs}, "
              f"raw全1000={raw_ok}, flt全999={flt_ok}")

    # ---- 汇总 ----
    npass = sum(1 for _, ok, _ in results if ok)
    print("")
    print("=" * 78)
    print(f" 结果: {npass}/{len(results)} 通过")
    if npass != len(results):
        print(" 失败项:")
        for nm, ok, d in results:
            if not ok:
                print(f"   - {nm}   {d}")
        print("=" * 78)
        raise SystemExit(1)
    print(" === 协议层全部通过 ===")
    print("=" * 78)


if __name__ == "__main__":
    main()

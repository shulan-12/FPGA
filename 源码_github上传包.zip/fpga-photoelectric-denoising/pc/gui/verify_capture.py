# -*- coding: utf-8 -*-
r"""
================================================================================
 离线抓包分析: 用上位机自己的解析器验证真实硬件数据
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py verify_capture.py ..\..\tools\cap_135142.bin
    py verify_capture.py ..\..\tools\cap_*.bin          (一次分析多份)

它回答四个问题:
  1) 帧结构对不对        好帧数 / 校验错 / 垃圾字节
  2) 成对与 SEQ 对不对    配对数 / SEQ 跳号 / 重复 / 错配
  3) 数据对不对          RAW 均值 / RAW 交流rms / FILT 交流rms / 噪声压低多少 dB
  4) 有没有"重复帧"bug   连续两帧字节完全相同 = 上一版固件那个握手 bug 的特征

★ 口径说明 (报数字前必须写清):
    rms 一律是【去掉直流后的交流 rms】:
        ac_rms = sqrt(mean((x - mean(x))^2))
    否则一个 15000 LSB 的直流会把 rms 算成 15000, 噪声完全看不见。
    "噪声压低" = 20*log10(FILT_ac_rms / RAW_ac_rms), 负数表示变小。
    ★ 这【不是】信噪比: 纯直流数据里没有信号, 只有噪声, 所以它衡量的是
      "噪声被压低了多少", 不能当 SNR 写进报告。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data_sources import FS_OUT_CONFIRMED  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402

FRAME_POINTS = 64
LSB_UV = 152.58          # 1 LSB = 152.58 µV (AD706/AD7606 ±5V 量程)


def analyse(path: Path) -> dict:
    raw_all, filt_all = [], []
    pairs = []

    def on_pair(r, f, seq):
        pairs.append(seq)
        raw_all.extend(parse_samples(r))
        filt_all.extend(parse_samples(f))

    asm = PairAssembler(on_pair=on_pair)
    fp = FrameParser(on_frame=asm.feed)
    data = path.read_bytes()
    fp.feed(data)

    raw = np.array(raw_all, dtype=np.float64)
    filt = np.array(filt_all, dtype=np.float64)

    # ---- 重复帧检测: 连续两帧字节完全相同 ----
    nframe = len(data) // 135
    dup = 0
    for i in range(1, nframe):
        if data[i * 135:(i + 1) * 135] == data[(i - 1) * 135:i * 135]:
            dup += 1

    # ---- SEQ 连续性 ----
    gaps, lost, mono = 0, 0, True
    for i in range(1, len(pairs)):
        d = (pairs[i] - pairs[i - 1]) & 0xFFFF
        if d != 1:
            gaps += 1
            if d > 1:
                lost += d - 1
            mono = False

    def ac(x):
        return np.sqrt(np.mean((x - x.mean()) ** 2)) if len(x) else float("nan")

    ra, fa = ac(raw), ac(filt)
    return dict(
        path=path.name, bytes=len(data), nframe=nframe,
        frames_ok=fp.stats.frames_ok, ck_err=fp.stats.checksum_errors,
        garbage=fp.stats.garbage_bytes, sync_err=fp.stats.sync_errors,
        pairs=len(pairs), pair_err=asm.stats.pairing_errors,
        orphan=asm.stats.orphan_filt, seq_mismatch=asm.stats.seq_mismatch,
        pair_lost_seq=asm.stats.pairs_lost, seq_gaps=gaps, lost_calc=lost,
        seq_mono=mono, dup_frames=dup,
        raw_mean=float(raw.mean()) if len(raw) else float("nan"),
        raw_ac=ra, filt_ac=fa,
        filt_mean=float(filt.mean()) if len(filt) else float("nan"),
        noise_db=20 * np.log10(fa / ra) if ra > 0 else float("nan"),
    )


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    args = sys.argv[1:]
    if not args:
        print("用法: py verify_capture.py <cap_*.bin> [更多文件...]")
        raise SystemExit(1)

    print("=" * 96)
    print(" 离线抓包分析 (用上位机自己的 FrameParser / PairAssembler)")
    print("=" * 96)

    rows = []
    for a in args:
        p = Path(a)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        if not p.exists():
            print(f"  跳过 (不存在): {a}")
            continue
        r = analyse(p)
        rows.append(r)

        print("")
        print(f"### {r['path']}   {r['bytes']} 字节 = {r['nframe']} 帧")
        print("-" * 96)
        print(f"  帧结构   : 好帧 {r['frames_ok']:>5} | 校验错 {r['ck_err']:>4} | "
              f"垃圾字节 {r['garbage']:>4} | 失步 {r['sync_err']:>3}")
        print(f"  成对/SEQ : 配成 {r['pairs']:>5} 对 | 配对错 {r['pair_err']} | "
              f"孤儿 {r['orphan']} | SEQ错配 {r['seq_mismatch']} | "
              f"SEQ跳号丢 {r['pair_lost_seq']} 对 | SEQ 单调递增 {r['seq_mono']}")
        print(f"  重复帧   : {r['dup_frames']} (上一版固件握手 bug 的特征是约 43%)")
        print(f"  RAW      : 均值 {r['raw_mean']:>10.2f} LSB = {r['raw_mean'] * LSB_UV / 1000:>8.2f} mV"
              f" | 交流 rms {r['raw_ac']:>7.3f} LSB")
        print(f"  FILT     : 均值 {r['filt_mean']:>10.2f} LSB"
              f" | 交流 rms {r['filt_ac']:>7.3f} LSB")
        print(f"  噪声压低 : {r['noise_db']:+.2f} dB  (20log10(FILT/RAW), "
              f"负数=变小; ★这不是 SNR)")
        print(f"  直流增益 : FILT均值/RAW均值 = "
              f"{r['filt_mean'] / r['raw_mean'] if r['raw_mean'] else float('nan'):.6f} "
              f"(滤波器设计值 0.999908)")

    if len(rows) >= 2:
        print("")
        print("=" * 96)
        print(" 汇总对比 (与 A 的报告对照)")
        print("=" * 96)
        print(f"  {'文件':<18}{'好帧':>7}{'校验错':>7}{'配对':>7}{'重复帧':>7}"
              f"{'RAW ac':>9}{'FILT ac':>9}{'噪声压低':>10}")
        for r in rows:
            print(f"  {r['path']:<18}{r['frames_ok']:>7}{r['ck_err']:>7}{r['pairs']:>7}"
                  f"{r['dup_frames']:>7}{r['raw_ac']:>9.2f}{r['filt_ac']:>9.2f}"
                  f"{r['noise_db']:>+9.2f}dB")


if __name__ == "__main__":
    main()

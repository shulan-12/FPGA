# -*- coding: utf-8 -*-
r"""
================================================================================
 诊断: 信噪比估计器的误差到底从哪来 (逐项对账, 不猜)
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py diag_snr.py

背景:
    界面上"滤波后 SNR"估计值比仿真真值高 2 dB。可能的原因有好几个:
      (a) 估计器本身有偏 (频谱法挖掉信号频点时把噪声也挖掉了 / 泄漏)
      (b) 真值算错了 (把滤波器启动瞬态算进噪声里)
      (c) 对齐差一个采样点
    猜是没有用的 —— 这里把每一项功率单独测出来对账。

关键: 直接用数据源生成的数组做统计, 绕过帧协议和界面, 避免引入额外变量。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from dashboard import snr_tone  # noqa: E402
from data_sources import FS_HW, FS_OUT_CONFIRMED, FakeFpgaSource  # noqa: E402

FS_OUT = FS_OUT_CONFIRMED      # ★ 用实测确认的 12.68 kSPS, 不用 100k/8 = 12.5k
F_SIG = 1562.5


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    src = FakeFpgaSource(f_sig=F_SIG, noise_amp=40, realtime=False, block_pairs=64)
    sig_all, raw_all, filt_all = [], [], []
    for k in range(24):
        src._gen_block()
        b = src.last_block
        sig_all.append(b["sig"])
        raw_all.append(b["raw"])
        filt_all.append(b["filt"])
    sig = np.concatenate(sig_all)
    raw = np.concatenate(raw_all)
    filt = np.concatenate(filt_all)
    n = len(sig)
    print("=" * 78)
    print(" 信噪比估计器诊断")
    print("=" * 78)
    print(f"  总点数 {n} ({n / FS_OUT:.2f} 秒 @ {FS_OUT:.0f} S/s)")

    # ---------- 1. 启动瞬态的影响 ----------
    print("")
    print("-" * 78)
    print(" 1. 滤波器启动瞬态对'真值'的影响 (每段单独统计, 看第一段是不是异常)")
    print("-" * 78)
    print(f"  {'段号':>4} {'噪声RMS(滤波)':>14} {'该段SNR(dB)':>12}")
    seg = 4096
    for k in range(min(5, n // seg)):
        s = slice(k * seg, (k + 1) * seg)
        e = filt[s] - sig[s]
        snr = 10 * np.log10(np.mean(sig[s] ** 2) / np.mean(e ** 2))
        print(f"  {k:>4} {np.sqrt(np.mean(e ** 2)):>14.1f} {snr:>12.2f}")
    print("  (若第 0 段明显差 -> 真值被启动瞬态污染, 统计时必须跳过开头)")

    # ---------- 2. 跳过瞬态后的真值 ----------
    skip = 512
    s2 = slice(skip, n)
    p_sig_true = float(np.mean(sig[s2] ** 2))
    p_noi_raw_true = float(np.mean((raw[s2] - sig[s2]) ** 2))
    p_noi_filt_true = float(np.mean((filt[s2] - sig[s2]) ** 2))
    snr_raw_true = 10 * np.log10(p_sig_true / p_noi_raw_true)
    snr_filt_true = 10 * np.log10(p_sig_true / p_noi_filt_true)
    print("")
    print("-" * 78)
    print(f" 2. 真值 (跳过开头 {skip} 点)")
    print("-" * 78)
    print(f"  信号功率   : {p_sig_true:12.1f}")
    print(f"  噪声功率 原始 : {p_noi_raw_true:12.1f}  -> SNR {snr_raw_true:6.2f} dB")
    print(f"  噪声功率 滤波 : {p_noi_filt_true:12.1f}  -> SNR {snr_filt_true:6.2f} dB")
    print(f"  提升 -> {snr_filt_true - snr_raw_true:+.2f} dB")

    # ---------- 3. 估计器在同一段数据上的表现 ----------
    print("")
    print("-" * 78)
    print(" 3. 估计器 (频谱法) 在同一段数据上的读数")
    print("-" * 78)
    print(f"  {'窗口':>6} {'原始估计':>10} {'原始真值':>10} {'滤波估计':>10} {'滤波真值':>10}")
    for nperseg in (2048, 4096, 8192):
        r = raw[-nperseg:]
        f = filt[-nperseg:]
        s = sig[-nperseg:]
        e_r = np.mean((raw[-nperseg:] - s) ** 2)
        e_f = np.mean((filt[-nperseg:] - s) ** 2)
        t_r = 10 * np.log10(np.mean(s ** 2) / e_r)
        t_f = 10 * np.log10(np.mean(s ** 2) / e_f)
        print(f"  {nperseg:>6} {snr_tone(r, FS_OUT, F_SIG):>10.2f} {t_r:>10.2f} "
              f"{snr_tone(f, FS_OUT, F_SIG):>10.2f} {t_f:>10.2f}")

    # ---------- 4. 拆开看估计器的两个量 ----------
    print("")
    print("-" * 78)
    print(" 4. 估计器内部: 它算出来的噪声功率 vs 真实噪声功率 (逐参数拆开)")
    print("-" * 78)
    for name, x, ss in (("原始", raw, sig), ("滤波", filt, sig)):
        seg_ = x[-8192:]
        s8 = ss[-8192:]
        p_true_seg = float(np.mean((seg_ - s8) ** 2))
        print(f"  [{name}] 真实噪声功率(时间域残差) = {p_true_seg:.1f}")
        for sl in (2048, 4096, 8192):
            out = snr_tone(seg_, FS_OUT, F_SIG, seg_len=sl, return_parts=True)
            if out is None:
                continue
            snr, d = out
            print(f"      seg_len={sl:>5} nseg={d['nseg']:>2} frac={d['frac']:.4f} "
                  f"k0={d['k0']:>5} | p_tot={d['p_tot']:>10.1f} "
                  f"p_noise={d['p_noise']:>8.1f} | 与真实比 {d['p_noise'] / p_true_seg:6.3f}"
                  f" | SNR={snr:6.2f}")

    # ---------- 6. 用"双实例法"直接量滤波后噪声 (不依赖任何频谱假设) ----------
    print("")
    print("-" * 78)
    print(" 6. 双实例法直接量: 滤波后噪声功率到底是多少")
    print("-" * 78)
    print("  原理: 滤波器是线性的, 所以  FIR(clean+noise) − FIR(clean) ≡ FIR(noise)")
    print("        两个实例分别跑一遍再相减, 就是【滤波后的纯噪声】, 不需要任何频谱假设。")
    from scipy.signal import lfilter  # noqa: F401  (仅为说明方法来源)
    coef = src.coef.astype(np.float64)

    def fir_int(v):
        """用和 RTL 相同的整数定点方式滤波。"""
        c = np.convolve(v.astype(np.int64), src.coef)
        return np.clip(c >> 15, -32768, 32767).astype(np.float64)

    # 取一段做 (和上面同长)
    n_in = 200_000
    src2 = FakeFpgaSource(f_sig=F_SIG, noise_amp=40, realtime=False)
    idx = np.arange(n_in, dtype=np.int64)
    cl = src2._sine(idx)
    nz = src2._noise(n_in)
    cd = cl + nz
    f_code = fir_int(cd)
    f_clean = fir_int(cl)
    d = 8
    jj = np.arange(20000, dtype=np.int64) * d
    # conv 直接对输入做, 所以 f_code[m] 就是"输入下标 m 处的滤波输出"; 对齐取 m = jj+64
    sel = jj + 64
    fnoise = f_code[sel] - f_clean[sel]
    dist = f_clean[sel] - cl[jj]
    resid = f_code[sel] - cl[jj]
    p_in = float(np.mean(nz ** 2))
    print(f"  输入噪声功率            = {p_in:8.2f}")
    print(f"  滤波后噪声功率 (实测)   = {np.mean(fnoise ** 2):8.2f}   "
          f"(= 输入 x sum(b^2), 理论 {p_in * 0.063901:.2f})")
    print(f"  信号失真功率 (确定性)   = {np.mean(dist ** 2):8.2f}")
    print(f"  两者之和                = {np.mean(fnoise ** 2) + np.mean(dist ** 2):8.2f}")
    print(f"  时间域残差总功率(实测)  = {np.mean(resid ** 2):8.2f}   <- 应与上一行接近")
    print("")
    truth_noise = float(np.mean(fnoise ** 2))
    print(f"  => 滤波后【纯噪声】功率 = {truth_noise:.2f}, 真噪声 SNR = "
          f"{10 * np.log10(np.mean(cl[jj] ** 2) / truth_noise):.2f} dB")
    print("     各 seg_len 下估计器的噪声读数 vs 这个真值:")
    for sl in (2048, 4096, 8192):
        out = snr_tone(f_code[sel], FS_OUT, F_SIG, seg_len=sl,
                       return_parts=True)
        if out:
            print(f"       seg_len={sl:>5}: p_noise={out[1]['p_noise']:7.2f} "
                  f"(比值 {out[1]['p_noise'] / truth_noise:.3f})")
    print("")
    print("-" * 78)
    print(" 5. 时间域残差 (滤波后 − 干净信号) 的能量分布")
    print("-" * 78)
    print("  理论校验: 滤波后噪声功率 = 输入噪声功率 x sum(b^2) = "
          f"{p_noi_raw_true:.1f} x 0.063901 = {p_noi_raw_true * 0.063901:.1f}")
    print("  (若这一行和估计器的 p_noise 接近, 说明【估计器是对的】, 是真值多算了东西)")
    print("")
    r_all = filt[512:] - sig[512:]
    for sl in (8192,):
        seg_ = r_all[-sl:]
        n_ = len(seg_)
        w = np.hanning(n_)
        # ★ 必须乘窗: denom 里含 Σw², 谱也要用加窗后的谱。
        #   (第一版漏了 w *, 谱功率被放大 1/0.375 = 2.67 倍, 得出"谱功率 > 总功率"的荒谬结果)
        X = np.fft.rfft(w * (seg_ - seg_.mean()))
        p = np.abs(X) ** 2
        m = len(p)
        wt = np.full(m, 2.0); wt[0] = 1.0; wt[-1] = 1.0
        denom = n_ * float(np.sum(w ** 2))
        k0 = int(round(F_SIG * n_ / FS_OUT))
        near = np.zeros(m, dtype=bool); near[max(0, k0 - 8):k0 + 9] = True
        p_far = float(np.sum(p[~near] * wt[~near]) / denom)
        p_near = float(np.sum(p[near] * wt[near]) / denom)
        print(f"  用 seg_len={n_}:")
        print(f"    残差总功率(时间域)          = {np.mean(seg_ ** 2):8.2f}")
        print(f"    残差谱功率 信号频点附近(±8) = {p_near:8.2f}   <- 确定性误差(信号失真)")
        print(f"    残差谱功率 其余频点         = {p_far:8.2f}   <- 真正的噪声")
        print(f"    => 真值 {np.mean(seg_ ** 2):.1f} 里混进了 {p_near:.1f} 的【确定性误差】,")
        print(f"       所以真值口径偏严; 估计器只量噪声, 所以读数偏高一点。")
    print("")
    print("  (比值明显偏离 1.0 -> 估计器的噪声测量有偏, 就是误差来源)")


if __name__ == "__main__":
    main()

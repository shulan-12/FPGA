# -*- coding: utf-8 -*-
r"""
================================================================================
 离线精确信噪比: 只减掉那一个正弦, 不做频带挖除
================================================================================
用途:
    · 报告里的最终 SNR 数字 (跑在抓包文件上, 不在实时界面里)
    · 界面里那个 snr_tone 是"快但粗"的版本, 用来看趋势

为什么不能只靠界面那个频谱挖除法:
    频谱挖除是把信号频率附近 ±8 个频点整段挖掉再积分剩下的能量。
    如果真实噪声在信号频率附近本来就有干扰 (实测抓包里确实有: 一串 12.4 Hz 的
    谐波正好落在 1004 Hz 附近), 那这些【真实噪声】会被一起挖掉 ->
    噪声被低估 -> SNR 虚高。实测虚高 6~12 dB, 而且加长采集也消不掉 (系统性偏差)。

这里的做法:
    1) 周期图找峰 + 抛物线插值, 得到频率初值
    2) 对该频率做一维最小化 (目标是残差功率最小), 精修到 ppm 级
       ★ 必须精修: 51 dB 信噪比下, 频率差 0.09 Hz 就能让残差从 539 涨到 3571
    3) 在最佳频率上用最小二乘拟合 cos/sin 两项
    4) 噪声功率 = mean((x - 拟合)^2)   <- 直接算残差, 不做大数相减
    5) 信号功率 = mean(拟合^2)

    这样只挖掉【那一个正弦】的 2 个自由度, 附近的噪声原样保留。
    代价: 拟合会吃掉与基函数相关的极少量噪声 (2/N), 对 N=16384 约 +0.0005 dB。
================================================================================
"""

from __future__ import annotations

import numpy as np


def _resid_power(x: np.ndarray, idx: np.ndarray, fs: float, f: float):
    """在频率 f 上做 cos/sin 最小二乘, 返回 (残差功率, 系数)。"""
    ph = 2.0 * np.pi * f * idx / fs
    A = np.column_stack([np.cos(ph), np.sin(ph)])
    c, *_ = np.linalg.lstsq(A, x, rcond=None)
    r = x - A @ c
    return float(np.mean(r ** 2)), c


def snr_fit(x: np.ndarray, fs: float, f_sig: float, freq_tol: float = 0.05,
            iters: int = 12, f_hint: float | None = None,
            return_parts: bool = False):
    """精确估计单音信噪比 (dB)。返回 (snr, dict) 或 snr。

    x       : 时域序列 (会自动去均值)
    fs      : 采样率 Hz
    f_sig   : 大致调制频率 Hz (只需给到 5% 以内, 会自己精修)
    f_hint  : 若给出, 跳过频率精修直接用这个频率 (省时间)。
              实时界面里频率几秒才变一次, 精修一次缓存起来即可:
              含精修 38.5 ms/次, 只做拟合约 1.5 ms/次。
    """
    x = np.asarray(x, dtype=np.float64)
    n = len(x)
    if n < 512:
        return None
    x = x - x.mean()
    idx = np.arange(n)

    if f_hint is not None:
        f = float(f_hint)
    else:
        # ---- 1) 周期图初值 ----
        win = np.hanning(n)
        S = np.abs(np.fft.rfft(win * x)) ** 2
        k0e = int(round(f_sig * n / fs))
        if not (2 <= k0e < len(S) - 2):
            return None
        span = max(4, int(round(freq_tol * k0e)))
        lo, hi = max(1, k0e - span), min(len(S) - 2, k0e + span)
        kp = lo + int(np.argmax(S[lo:hi + 1]))
        y0 = np.log(S[kp - 1] + 1e-300)
        y1 = np.log(S[kp] + 1e-300)
        y2 = np.log(S[kp + 1] + 1e-300)
        den = y0 - 2.0 * y1 + y2
        delta = 0.5 * (y0 - y2) / den if abs(den) > 1e-15 else 0.0
        f = (kp + float(np.clip(delta, -0.5, 0.5))) * fs / n

        # ---- 2) 一维最小化精修频率 (目标: 残差功率最小) ----
        h = 0.5 * fs / n
        best_f, best_p = f, _resid_power(x, idx, fs, f)[0]
        for _ in range(iters):
            rm = _resid_power(x, idx, fs, f - h)[0]
            r0 = _resid_power(x, idx, fs, f)[0]
            rp = _resid_power(x, idx, fs, f + h)[0]
            den = rm - 2.0 * r0 + rp
            if abs(den) < 1e-30:
                break
            step = float(np.clip(0.5 * (rm - rp) / den * h, -h, h))
            f = f + step
            p = _resid_power(x, idx, fs, f)[0]
            if p < best_p:
                best_f, best_p = f, p
            h = h * (0.5 if abs(step) < 0.5 * h else 1.0)
            if h < 1e-6 * fs / n:
                break
        f = best_f

    # ---- 3) 最终拟合 (只减掉一个正弦, 2 个自由度) ----
    pn, c = _resid_power(x, idx, fs, f)
    ph = 2.0 * np.pi * f * idx / fs
    A = np.column_stack([np.cos(ph), np.sin(ph)])
    ps = float(np.mean((A @ c) ** 2))
    if ps <= 0.0 or pn <= 0.0:
        return None
    snr = 10.0 * np.log10(ps / pn)
    if return_parts:
        return snr, dict(p_sig=ps, p_noise=pn, p_tot=ps + pn, f_est=f, n=n)
    return snr

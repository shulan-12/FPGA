# -*- coding: utf-8 -*-
r"""
================================================================================
 SNR 预算: 用【真实抓包噪声】验证估计器, 并回答"需要抓多长"
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py snr_budget.py ..\..\tools\cap_135142.bin ..\..\tools\cap_135336.bin

为什么这样做 (而不是继续用仿真噪声):
    A 的抓包里是【真实硬件噪声】(OPT101 + 前置放大 + AD7606 + 电源),
    不是我在电脑上造的白噪声。等 1 kHz 调制通了, 我要在这个噪声上算 SNR。
    所以在调制到货之前, 把真实噪声取出来、人为加一个【已知幅度】的 1 kHz 正弦,
    真值就完全已知 —— 这样验出来的精度才代表届时的实际情况。

★ 关键做法: 真值必须和估计值【用同一段数据】。
    第一版拿"整段 3 秒的噪声功率"当真值, 而估计器只取最后 16384 点 ——
    结果滤波后"误差 +12.64 dB", 其实是两段数据的噪声差 18 倍, 跟估计器无关。
    暗场那份抓包末尾有一段突发干扰 (分段 rms 0.36 / 1.04 / 0.62, 整段 1.36),
    噪声根本不平稳。所以现在按【同一窗口】分别算真值和估计值, 再统计误差。

口径:
    信号功率 P_sig = 注入正弦的功率 (真值已知)
    噪声功率 P_noi = 同一窗口内实测噪声的方差
    SNR = 10*log10(P_sig / P_noi), 与 dashboard.py 的 snr_tone 口径一致
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dashboard import snr_tone  # noqa: E402
from data_sources import FS_OUT_CONFIRMED, q15_coeffs  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402
from scipy.signal import welch  # noqa: E402

FS = FS_OUT_CONFIRMED
F_MOD = 1000.0          # 计划中的调制频率
MOD_PP = 65.0           # 调制峰峰值 33~98 LSB -> 65 LSB (A 2026-10-28 预估)
COEF = q15_coeffs()

# 大 max_seg: 让估计器用满传入的窗口, 这样和真值严格同段
BIG_SEG = 4096


def load(path: Path):
    raw, filt = [], []

    def onp(r, f, s):
        raw.extend(parse_samples(r))
        filt.extend(parse_samples(f))

    asm = PairAssembler(on_pair=onp)
    FrameParser(on_frame=asm.feed).feed(path.read_bytes())
    return np.array(raw, float), np.array(filt, float)


def db(a, b):
    return 10.0 * np.log10(a / b) if a > 0 and b > 0 else float("nan")


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    args = sys.argv[1:] or [str(HERE.parent.parent / "tools" / "cap_135142.bin")]
    amp = MOD_PP / 2.0
    print("=" * 94)
    print(" SNR 预算: 真实抓包噪声 + 注入已知 1 kHz 正弦 (真值与估计值同窗口)")
    print("=" * 94)
    print(f"  注入调制 f={F_MOD:.0f} Hz, 峰峰 {MOD_PP:.0f} LSB -> 幅度 {amp:.1f} LSB, "
          f"rms {amp / np.sqrt(2):.2f} LSB")
    print(f"  采样率 {FS:.0f} Hz, 系数 {len(COEF)} 抽头, sum(b^2)={np.sum((COEF / 32768.0) ** 2):.5f}")
    print("")

    for a in args:
        p = Path(a)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        if not p.exists():
            print(f"  跳过: {p}")
            continue
        raw, filt = load(p)
        n = min(len(raw), len(filt))
        raw, filt = raw[:n], filt[:n]
        noise = raw - raw.mean()
        fnoise = filt - filt.mean()
        dur = n / FS

        print("=" * 94)
        print(f" {p.name}: {n} 点 = {dur:.3f} 秒 | RAW 噪声 rms {noise.std():.3f} LSB"
              f" | FILT 噪声 rms {fnoise.std():.3f} LSB")
        print("=" * 94)

        # ---------- Q1 噪声频谱 ----------
        f, P = welch(noise, fs=FS, nperseg=min(1024, n // 2))
        df = f[1] - f[0]
        tot = float(np.sum(P) * df)
        print("  Q1 真实的 RAW 噪声能量分布 (决定低通还有多少可砍):")
        parts = []
        for lo, hi in [(0, 500), (500, 1000), (1000, 2000), (2000, 3500),
                       (3500, 4500), (4500, 6300)]:
            m = (f >= lo) & (f < hi)
            parts.append((lo, hi, float(np.sum(P[m]) * df) / tot * 100))
        print("     " + " | ".join(f"{lo}-{hi}Hz {pct:.1f}%" for lo, hi, pct in parts))
        sumb2 = float(np.sum((COEF / 32768.0) ** 2))
        print(f"     白噪声理论压低 {-10 * np.log10(sumb2):.2f} dB; "
              f"实测只压低 {20 * np.log10(fnoise.std() / noise.std()):+.2f} dB"
              f"  -> 真实噪声高频能量占比高, 低通能砍的没有白噪声那么多")

        # ---------- Q2 同一窗口内: 真值 vs 估计 ----------
        t = np.arange(n) / FS
        tone = amp * np.sin(2 * np.pi * F_MOD * t)
        print("")
        print("  Q2 逐窗口误差 (每个窗口内分别算真值和估计值, 消除不平稳的影响):")
        print(f"     {'长度':>7}{'窗口':>6}   {'RAW 真值':>9}{'RAW 估计':>9}{'误差':>8}"
              f"   {'FILT 真值':>10}{'FILT 估计':>10}{'误差':>8}")
        for L in (0.5, 1.0, 2.0, 3.0):
            nw = int(dur // L)
            if nw < 1:
                continue
            m = int(L * FS)
            er, ef = [], []
            tr_r, tr_f, es_r, es_f = [], [], [], []
            for k in range(nw):
                sl = slice(k * m, (k + 1) * m)
                tw = tone[sl]
                nw_raw = noise[sl]
                nw_flt = fnoise[sl]
                ps = float(np.mean(tw ** 2))
                t_r = db(ps, float(np.mean(nw_raw ** 2)))
                t_f = db(ps, float(np.mean(nw_flt ** 2)))
                e_r = snr_tone(nw_raw + tw, FS, F_MOD, max_seg=BIG_SEG)
                e_f = snr_tone(nw_flt + tw, FS, F_MOD, max_seg=BIG_SEG)
                if e_r is not None and np.isfinite(t_r):
                    er.append(e_r - t_r)
                    tr_r.append(t_r)
                    es_r.append(e_r)
                if e_f is not None and np.isfinite(t_f):
                    ef.append(e_f - t_f)
                    tr_f.append(t_f)
                    es_f.append(e_f)
            if er and ef:
                print(f"     {L:>6.1f}s {nw:>6}   {np.mean(tr_r):>9.2f}{np.mean(es_r):>9.2f}"
                      f"{np.mean(er):>+8.2f}   {np.mean(tr_f):>10.2f}{np.mean(es_f):>10.2f}"
                      f"{np.mean(ef):>+8.2f}")
                if nw > 1:
                    print(f"     {'':>7}{'':>6}   ({'std':>9}{np.std(es_r, ddof=1):>9.2f}"
                          f"{np.std(er, ddof=1):>8.2f}   {'':>10}{np.std(es_f, ddof=1):>10.2f}"
                          f"{np.std(ef, ddof=1):>8.2f})")
        print("")
        print("  说明: '误差'是估计减真值; 'std' 是该长度下不同窗口之间的离散程度。")
        print("        离散度随长度下降 -> 说明长度足够;  误差不随长度下降 -> 那是估计器的系统偏差, 加长没用。")
        print("")


if __name__ == "__main__":
    main()

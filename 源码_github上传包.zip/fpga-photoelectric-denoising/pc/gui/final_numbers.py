# -*- coding: utf-8 -*-
r"""
================================================================================
 报告最终数字（唯一权威版）—— 一条命令复现报告里所有数据
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py final_numbers.py

为什么要有这个脚本:
    这批数字在沟通过程中改过几轮口径 (12.68->12.5 kSPS、全段->逐段拟合、
    1014.4->1000 Hz、1.4%->3.7%)。报告作者手上很容易混着旧版本。
    所以把所有要写进报告的数字集中在这里, 每一条都由抓包现算, 并注明口径。

口径总说明:
    · 采样率 12.5 kSPS —— 用"调制周期(采样点) x DDS频率"标定, 见 check_sample_rate.py
    · 交流 rms 一律先去直流: sqrt(mean((x-mean)^2))
    · 残余噪声分两个口径:
        口径A: 只扣基波 -> 残差里含 2~5 次谐波 (其中 2 次是 PWM 真谐波, 在通带内)
        口径B: 再扣各次谐波 -> 残差只剩随机噪声
    · 都用【逐段拟合取中位数】(8 段): 抓包有缓慢漂移, 整段拟合会把漂移残留在残差里
    · 1 LSB = 152.58 uV 暂按 +-5V 量程 (J2 跳线待 C 确认; 若 +-10V 则所有 mV 值 x2)
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from analyze_modulated import load, find_tone, seg_noise  # noqa: E402
from data_sources import FS_OUT_CONFIRMED as FS  # noqa: E402
from report_modulated import seg_resid, band_pct  # noqa: E402
from frame_proto import FrameParser, PairAssembler  # noqa: E402
from scipy.signal import welch  # noqa: E402

TOOLS = HERE.parent.parent / "tools"
LSB_UV = 152.58
MOD = ["cap_145038.bin", "cap_145044.bin", "cap_145049.bin"]
DARK = "cap_135142.bin"
BANDS = ["0-500", "500-1k", "1-2k", "2-3.5k", "3.5-4.5k", "4.5-6.3k"]


def frame_stats(fn):
    raw, filt, ps, qs, seqs = load(TOOLS / fn, FS)
    n = min(len(raw), len(filt))
    return raw[:n], filt[:n], ps, qs, seqs


def amp_at(x, f):
    idx = np.arange(len(x))
    ph = 2 * np.pi * f * idx / FS
    A = np.column_stack([np.cos(ph), np.sin(ph)])
    c, *_ = np.linalg.lstsq(A, x - x.mean(), rcond=None)
    return float(np.hypot(*c))


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    print("=" * 100)
    print(" 报告最终数字（唯一权威版）")
    print(f" 采样率 {FS:.0f} S/s | 1 LSB = {LSB_UV} uV (暂按 +-5V) | 逐段口径")
    print("=" * 100)

    # ---------- 1. 帧结构 ----------
    print("")
    print("【1】帧结构验收（逐字节，用上位机自己的解析器）")
    print(f"  {'文件':<18}{'好帧':>7}{'校验错':>7}{'块失步':>7}{'配成对':>7}"
          f"{'配对错':>7}{'孤儿':>6}{'SEQ丢失':>8}")
    rows = []
    for fn in MOD + [DARK]:
        raw, filt, ps, qs, seqs = frame_stats(fn)
        print(f"  {fn:<18}{ps.frames_ok:>7}{ps.checksum_errors:>7}{ps.sync_errors:>7}"
              f"{qs.pairs_ok:>7}{qs.pairing_errors:>7}{qs.orphan_filt:>6}"
              f"{qs.pairs_lost:>8}")

    # ---------- 2. 调制参数 ----------
    print("")
    print("【2】调制参数")
    print(f"  {'文件':<18}{'基波Hz':>10}{'A1k(LSB)':>11}{'峰峰(LSB)':>11}{'mVpp':>9}")
    f0s, amps = [], []
    data = []
    for fn in MOD:
        raw, filt, ps, qs, seqs = frame_stats(fn)
        f0 = find_tone(raw, FS)[0]
        a1 = amp_at(raw, f0)
        f0s.append(f0)
        amps.append(a1)
        data.append((fn, raw, filt, f0))
        print(f"  {fn:<18}{f0:>10.2f}{a1:>11.2f}{2 * a1:>11.1f}"
              f"{2 * a1 * LSB_UV / 1000:>9.1f}")
    f0, a1 = float(np.mean(f0s)), float(np.mean(amps))
    print(f"  平均: {f0:.2f} Hz, A1k={a1:.2f} LSB ({2 * a1 * LSB_UV / 1000:.1f} mVpp)")

    # ---------- 3. SNR ----------
    print("")
    print("【3】SNR（信号=基波；逐段拟合取中位数，8 段）")
    print(f"  {'文件':<18}{'A:残余RAW':>11}{'A:FILT':>9}{'A:ΔdB':>8}"
          f"{'B:残余RAW':>11}{'B:FILT':>9}{'B:ΔdB':>8}")
    resA, resB = [], []
    for fn, raw, filt, f0x in data:
        a_r = float(np.median(seg_noise(raw, FS, f0x, ks=(1,))))
        a_f = float(np.median(seg_noise(filt, FS, f0x, ks=(1,))))
        b_r = float(np.median(seg_noise(raw, FS, f0x, ks=(1, 2, 3, 4, 5))))
        b_f = float(np.median(seg_noise(filt, FS, f0x, ks=(1, 2, 3, 4, 5))))
        resA.append((a_r, a_f))
        resB.append((b_r, b_f))
        print(f"  {fn:<18}{a_r:>11.2f}{a_f:>9.2f}{20 * np.log10(a_f / a_r):>+8.2f}"
              f"{b_r:>11.2f}{b_f:>9.2f}{20 * np.log10(b_f / b_r):>+8.2f}")
    gA = np.mean([20 * np.log10(f / r) for r, f in resA])
    gB = np.mean([20 * np.log10(f / r) for r, f in resB])
    print(f"  {'平均压制':<18}{'':>11}{'':>9}{gA:>+8.2f}{'':>11}{'':>9}{gB:>+8.2f}")

    ps = a1 ** 2 / 2
    snrA_r = 10 * np.log10(ps / float(np.mean([r for r, f in resA])) ** 2)
    snrA_f = 10 * np.log10(ps / float(np.mean([f for r, f in resA])) ** 2)
    snrB_r = 10 * np.log10(ps / float(np.mean([r for r, f in resB])) ** 2)
    snrB_f = 10 * np.log10(ps / float(np.mean([f for r, f in resB])) ** 2)
    print("")
    print(f"  SNR 口径A: {snrA_r:.2f} -> {snrA_f:.2f} dB  ({snrA_f - snrA_r:+.2f})")
    print(f"  SNR 口径B: {snrB_r:.2f} -> {snrB_f:.2f} dB  ({snrB_f - snrB_r:+.2f})")
    print(f"  噪声占信号: 口径A {np.mean([r for r, f in resA]) / np.sqrt(ps) * 100:.1f}%"
          f" -> {np.mean([f for r, f in resA]) / np.sqrt(ps) * 100:.1f}%"
          f"   口径B {np.mean([r for r, f in resB]) / np.sqrt(ps) * 100:.1f}%"
          f" -> {np.mean([f for r, f in resB]) / np.sqrt(ps) * 100:.1f}%")

    # ---------- 4. 谐波 ----------
    print("")
    print("【4】谐波保留率（各次谐波幅度，含相位锁定判据）")
    print(f"  {'次数':>4}{'频率':>9}{'RAW':>8}{'FILT':>8}{'保留':>8}")
    for k in (2, 3, 4, 5):
        ar = amp_at(data[0][1], k * f0)
        af = amp_at(data[0][2], k * f0)
        print(f"  {k:>4}{k * f0:>8.0f}Hz{ar:>8.3f}{af:>8.3f}{af / ar * 100:>7.1f}%")

    # ---------- 5. 频段分布 ----------
    print("")
    print("【5】噪声频段分布（%）")
    print(f"  {'工况':<12}" + "".join(f"{b:>10}" for b in BANDS))
    mb = []
    for fn, raw, filt, f0x in data:
        b = band_pct(seg_resid(raw, FS, f0x, (1, 2, 3, 4, 5)), FS)
        mb.append(b)
    mb_avg = np.mean(mb, axis=0)
    print(f"  {'调制(平均)':<12}" + "".join(f"{v:>9.1f} " for v in mb_avg))
    drew, dflt, _, _, _ = frame_stats(DARK)
    db = band_pct(drew - drew.mean(), FS)
    print(f"  {'暗场':<12}" + "".join(f"{v:>9.1f} " for v in db))
    print(f"  调制: 带内(<3.5k) {sum(mb_avg[:4]):.0f}%  暗场: 带外(>3.5k) {db[4] + db[5]:.0f}%")

    # ---------- 6. 无调制工况的噪声压制 ----------
    print("")
    print("【6】噪声压制（无调制工况: 信号就是噪声本身, 可直接比 rms）")
    print(f"  {'工况':<8}{'文件':<18}{'RAW rms':>10}{'FILT rms':>10}{'压制':>9}")
    for fn, label in ((DARK, "遮光"), ("cap_135336.bin", "手电筒"),
                      ("cap_201917.bin", "10/26")):
        r_, f_, _, _, _ = frame_stats(fn)
        ra = float(np.sqrt(np.mean((r_ - r_.mean()) ** 2)))
        fa = float(np.sqrt(np.mean((f_ - f_.mean()) ** 2)))
        print(f"  {label:<8}{fn:<18}{ra:>10.3f}{fa:>10.3f}{20 * np.log10(fa / ra):>+9.2f}")
    print(f"  白噪声理论值 -10log10(sum(b^2)) = {-10 * np.log10(0.063901):.2f} dB"
          f"  (真实噪声 79% 在带外)")

    # ---------- 7. 直流 ----------
    print("")
    print("【7】直流电平")
    for fn, raw, filt, f0x in data:
        print(f"  {fn:<18}RAW mean {raw.mean():.1f} LSB = "
              f"{raw.mean() * LSB_UV / 1000:.1f} mV  (x2 if +-10V)")
    print(f"  {DARK:<18}RAW mean {drew.mean():.1f} LSB = "
          f"{drew.mean() * LSB_UV / 1000:.2f} mV  (暗电平; OPT101 手册典型 7.5 mV)")

    print("")
    print("=" * 100)
    print(" 以上所有数字均由本脚本从抓包现算。口径变更请改脚本，不要手改报告。")
    print("=" * 100)


if __name__ == "__main__":
    main()

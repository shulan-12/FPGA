# -*- coding: utf-8 -*-
r"""
================================================================================
 报告图 (调制工况): 降噪前后波形对比 + 为什么提升不大的证据链
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py report_modulated.py

产出: out\报告用_调制数据_降噪对比.png  (四联图)
  ① 时域对比 (真实硬件, 6 个调制周期)      —— 信号完整保留, 毛刺变小
  ② 残差 RAW-FILT (同一段)                  —— 被滤掉的到底是什么
  ③ 频谱 + 谐波标注                         —— 通带保留 / 阻带压制 (核心证据)
  ④ 噪声频段分布对照: 暗场 vs 调制          —— 解释为什么 8.13 dB vs 2.04 dB

★ 所有数字由脚本从抓包现算, 不写死。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from analyze_modulated import seg_noise  # noqa: E402
from data_sources import FS_OUT_CONFIRMED as FS  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402
from scipy.signal import welch  # noqa: E402

TOOLS = HERE.parent.parent / "tools"
OUT = HERE / "out"
BANDS = [(0, 500), (500, 1000), (1000, 2000), (2000, 3500), (3500, 4500), (4500, 6340)]
LABELS = ["0–500", "500–1k", "1–2k", "2–3.5k", "3.5–4.5k", "4.5–6.3k"]


def load(path):
    raw, filt = [], []

    def onp(r, f, s):
        raw.extend(parse_samples(r))
        filt.extend(parse_samples(f))

    asm = PairAssembler(on_pair=onp)
    FrameParser(on_frame=asm.feed).feed(Path(path).read_bytes())
    n = min(len(raw), len(filt))
    return np.array(raw[:n], float), np.array(filt[:n], float)


def find_f0(x, fs, lo=100.0, hi=4000.0):
    n = len(x)
    x = x - x.mean()
    S = np.abs(np.fft.rfft(np.hanning(n) * x))
    fr = np.fft.rfftfreq(n, 1.0 / fs)
    m = (fr >= lo) & (fr <= hi)
    k = int(np.argmax(S * m))
    if 1 <= k < len(S) - 1:
        y0, y1, y2 = (np.log(S[k - 1] + 1e-300), np.log(S[k] + 1e-300),
                      np.log(S[k + 1] + 1e-300))
        den = y0 - 2 * y1 + y2
        k = k + (0.5 * (y0 - y2) / den if abs(den) > 1e-15 else 0.0)
    return float(k * fs / n)


def fit_amp(x, fs, f):
    idx = np.arange(len(x))
    ph = 2 * np.pi * f * idx / fs
    A = np.column_stack([np.cos(ph), np.sin(ph)])
    c, *_ = np.linalg.lstsq(A, x - x.mean(), rcond=None)
    return float(np.hypot(*c))


def strip_components(x, fs, f0, ks):
    """扣掉 k*f0 (k in ks) 的 cos/sin 分量, 返回残差。"""
    x = x - x.mean()
    idx = np.arange(len(x))
    cols = []
    for k in ks:
        ph = 2 * np.pi * k * f0 * idx / fs
        cols += [np.cos(ph), np.sin(ph)]
    A = np.column_stack(cols)
    c, *_ = np.linalg.lstsq(A, x, rcond=None)
    return x - A @ c


def seg_resid(x, fs, f0, ks, nseg=8):
    """逐段拟合后把残差拼起来 (用于画频谱/算频段分布, 与逐段口径一致)。"""
    x = np.asarray(x, float) - np.mean(x)
    bs = len(x) // nseg
    out = []
    for b in range(nseg):
        seg = x[b * bs:(b + 1) * bs]
        idx = np.arange(len(seg))
        cols = []
        for k in ks:
            if k * f0 > fs / 2 * 0.95:
                continue
            ph = 2 * np.pi * k * f0 * idx / fs
            cols += [np.cos(ph), np.sin(ph)]
        A = np.column_stack(cols)
        c, *_ = np.linalg.lstsq(A, seg, rcond=None)
        out.append(seg - A @ c)
    return np.concatenate(out)


def band_pct(x, fs):
    f, P = welch(x, fs=fs, nperseg=min(1024, len(x) // 2))
    df = f[1] - f[0]
    tot = float(np.sum(P) * df)
    return [float(np.sum(P[(f >= lo) & (f < hi)]) * df) / tot * 100 for lo, hi in BANDS]


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    mod = TOOLS / "cap_145049.bin"
    dark = TOOLS / "cap_135142.bin"
    raw, filt = load(mod)
    f0 = find_f0(raw, FS)
    amp1 = fit_amp(raw, FS, f0)
    print(f"调制抓包: 基波 {f0:.2f} Hz, 幅度 {amp1:.2f} LSB")

    # 谐波幅度
    harm = {}
    for k in (2, 3, 4, 5):
        harm[k] = (fit_amp(raw, FS, k * f0), fit_amp(filt, FS, k * f0))

    # 纯噪声 (逐段扣基波+2..5 次谐波, 取中位数 —— 见 analyze_modulated.seg_noise)
    # ★ 不用整段拟合: 抓包有缓慢漂移, 整段拟合会把漂移留在残差里,
    #   残差偏大 (实测整段 3.31 vs 逐段 2.73), 压制量被系统性低估。
    pn_r = float(np.median(seg_noise(raw, FS, f0, ks=(1, 2, 3, 4, 5))))
    pn_f = float(np.median(seg_noise(filt, FS, f0, ks=(1, 2, 3, 4, 5))))
    a_r = float(np.median(seg_noise(raw, FS, f0, ks=(1,))))     # 只扣基波
    a_f = float(np.median(seg_noise(filt, FS, f0, ks=(1,))))
    print(f"逐段中位数残差: 口径A(含谐波) {a_r:.2f} -> {a_f:.2f} LSB "
          f"({20 * np.log10(a_f / a_r):+.2f} dB)")
    print(f"                口径B(纯噪声) {pn_r:.2f} -> {pn_f:.2f} LSB "
          f"({20 * np.log10(pn_f / pn_r):+.2f} dB)")

    # SNR (以基波为信号)
    psig = amp1 ** 2 / 2
    snr_r_all = 10 * np.log10(psig / a_r ** 2)
    snr_f_all = 10 * np.log10(psig / a_f ** 2)
    snr_r = 10 * np.log10(psig / pn_r ** 2)
    snr_f = 10 * np.log10(psig / pn_f ** 2)
    print(f"口径A(残留含谐波): {snr_r_all:.2f} -> {snr_f_all:.2f} dB ({snr_f_all - snr_r_all:+.2f})")
    print(f"口径B(纯噪声):     {snr_r:.2f} -> {snr_f:.2f} dB ({snr_f - snr_r:+.2f})")

    # 暗场频段分布 (无调制, 直接用原始噪声)
    dr, df_ = load(dark)
    dark_bands = band_pct(dr - dr.mean(), FS)
    mod_bands = band_pct(seg_resid(raw, FS, f0, (1, 2, 3, 4, 5)), FS)
    dark_db = 20 * np.log10(np.sqrt(np.mean((df_ - df_.mean()) ** 2))
                            / np.sqrt(np.mean((dr - dr.mean()) ** 2)))
    print(f"暗场 rms {np.sqrt(np.mean((dr - dr.mean()) ** 2)):.2f} -> "
          f"{np.sqrt(np.mean((df_ - df_.mean()) ** 2)):.2f} LSB ({dark_db:+.2f} dB)")

    OUT.mkdir(exist_ok=True)
    fig, ax = plt.subplots(2, 2, figsize=(13.2, 8.4))

    # ---- ① 时域 ----
    a = ax[0][0]
    win = 80
    t = np.arange(win) / FS * 1000.0
    a.plot(t, raw[:win], "o-", color="0.6", ms=3, lw=0.9, label="原始 (带噪)")
    a.plot(t, filt[:win], "o-", color="crimson", ms=3, lw=1.4, label="滤波后")
    per = 1.0 / f0 * 1000
    a.set_title(f"① 时域 (真实硬件, {win} 点 ≈ {win * per / (1e3 / FS * 1e3):.1f} 个周期)"
                if False else
                f"① 时域 (真实硬件抓包, {win} 点 = {win / FS * 1000:.1f} ms ≈ "
                f"{win / FS * f0:.1f} 个调制周期)\n"
                f"基波 {f0:.1f} Hz 幅度 {amp1:.1f}→{fit_amp(filt, FS, f0):.1f} LSB "
                f"(保留 {fit_amp(filt, FS, f0) / amp1 * 100:.1f}%)", fontsize=10)
    a.set_xlabel("时间 (ms)")
    a.set_ylabel("幅度 (LSB)")
    a.grid(alpha=0.3)
    a.legend(fontsize=8, loc="upper right")

    # ---- ② 噪声对比 (扣掉调制后, 放大到噪声量级 —— 这才看得出降噪) ----
    # ★ 为什么不画"原始 vs 滤波"整体叠加: 噪声只占信号的 3.6%,
    #   两条曲线在 ±110 LSB 的纵轴上完全重合, 看不出任何差别 (演示现场会被质疑)。
    #   把调制本身扣掉、只留噪声, 纵轴自动缩到 ±10 LSB, 降噪就看得很清楚。
    a = ax[0][1]
    nr = seg_resid(raw, FS, f0, (1, 2, 3, 4, 5))[:win]
    nf = seg_resid(filt, FS, f0, (1, 2, 3, 4, 5))[:win]
    a.plot(t, nr, "o-", color="0.6", ms=3, lw=0.9, label=f"原始噪声 (rms {pn_r:.2f})")
    a.plot(t, nf, "o-", color="crimson", ms=3, lw=1.3, label=f"滤波后噪声 (rms {pn_f:.2f})")
    a.axhline(0, color="0.4", lw=0.7)
    a.set_title(f"② 扣掉调制后的噪声对比 (纵轴 ±{max(abs(nr).max(), abs(nf).max()) * 1.15:.0f} LSB)\n"
                f"rms: {pn_r:.2f} → {pn_f:.2f} LSB   ({20 * np.log10(pn_f / pn_r):+.2f} dB)",
                fontsize=10)
    a.set_xlabel("时间 (ms)")
    a.set_ylabel("LSB")
    a.grid(alpha=0.3)

    # ---- ③ 频谱 + 谐波标注 ----
    a = ax[1][0]
    fr, Pr = welch(raw - raw.mean(), fs=FS, nperseg=2048)
    _, Pf = welch(filt - filt.mean(), fs=FS, nperseg=2048)
    a.semilogy(fr / 1000, Pr, color="0.6", lw=0.9, label="原始")
    a.semilogy(fr / 1000, Pf, color="crimson", lw=1.0, label="滤波后")
    a.axvline(3.5, color="k", ls="--", lw=0.8, alpha=0.6)
    a.text(3.55, a.get_ylim()[1] * 0.3, "截止 3.5 kHz", fontsize=7, rotation=90)
    for k, (ar, af) in harm.items():
        a.annotate(f"{k} 次\n{af / ar * 100:.0f}%", xy=(k * f0 / 1000, Pr.max() * 0.02),
                   ha="center", fontsize=6.5,
                   color="darkgreen" if af / ar > 0.5 else "darkorange")
    a.set_title("③ 频谱 (绿=通带内保留, 橙=阻带被压制)\n"
                f"2 次 保留 {harm[2][1] / harm[2][0] * 100:.0f}%，"
                f"4 次 {harm[4][1] / harm[4][0] * 100:.0f}%，"
                f"5 次 {harm[5][1] / harm[5][0] * 100:.0f}%", fontsize=10)
    a.set_xlabel("频率 (kHz)")
    a.set_ylabel("PSD (LSB²/Hz)")
    a.set_xlim(0, 6.4)
    a.grid(alpha=0.3, which="both")
    a.legend(fontsize=8, loc="upper right")

    # ---- ④ 频段对照 ----
    a = ax[1][1]
    x = np.arange(len(BANDS))
    wd = 0.38
    b1 = a.bar(x - wd / 2, dark_bands, wd, label=f"暗场 (压制 {dark_db:+.2f} dB)",
               color="0.6")
    b2 = a.bar(x + wd / 2, mod_bands, wd, label=f"调制工况 (纯噪声压制 "
              f"{20 * np.log10(pn_f / pn_r):+.2f} dB)", color="steelblue")
    a.set_xticks(x)
    a.set_xticklabels(LABELS, fontsize=8)
    a.set_ylabel("占噪声总能量 (%)")
    # 带内/带外占比由数据算, 不写死
    in_mod = sum(mod_bands[:4])          # 0~3.5 kHz 通带内
    out_dark = dark_bands[4] + dark_bands[5]   # 暗场 3.5 kHz 以上
    a.set_title("④ 噪声频段分布对照 —— 为什么两种工况收益不同\n"
                f"暗场({dark.stem}): {out_dark:.0f}% 在带外(>3.5k);  "
                f"调制({mod.stem}): {in_mod:.0f}% 在带内(<3.5k)", fontsize=9.5)
    a.legend(fontsize=7.5, loc="upper left")
    a.grid(alpha=0.3, axis="y")
    for bars in (b1, b2):
        for b in bars:
            h = b.get_height()
            if h > 4:
                a.text(b.get_x() + b.get_width() / 2, h + 1, f"{h:.0f}",
                       ha="center", fontsize=6)

    fig.suptitle(f"1 kHz 调制 · 真实硬件降噪实测  "
                 f"(fs={FS:.0f} S/s, 135 字节帧, 校验错 0, SEQ 连续)\n"
                 f"SNR {snr_r_all:.2f} → {snr_f_all:.2f} dB "
                 f"(只扣基波, {snr_f_all - snr_r_all:+.2f} dB)  |  "
                 f"纯噪声口径 {snr_r:.2f} → {snr_f:.2f} dB ({snr_f - snr_r:+.2f} dB)",
                 fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    png = OUT / "报告用_调制数据_降噪对比.png"
    fig.savefig(png, dpi=135)
    plt.close(fig)
    print(f"\n已出图: {png}")


if __name__ == "__main__":
    main()

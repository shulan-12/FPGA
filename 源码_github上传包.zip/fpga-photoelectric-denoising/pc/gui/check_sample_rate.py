# -*- coding: utf-8 -*-
r"""
================================================================================
 采样率再核对: 用调制周期当"标尺"
================================================================================
为什么又要核对:
    报告里现在写的是 12.68 kSPS + "1.44% 时钟偏快"。但我算 mod_gen.v 的 DDS 后发现对不上,
    必须查清楚 —— 因为这个数会写进报告。

两个互相独立的量, 可以定出采样率:
  ① 调制周期 = 多少个【采样点】(用 FFT bin / 相位斜率测, 与 fs 无关)
  ② 调制频率 = 多少 Hz (由 mod_gen.v 的 50 MHz 时钟 + DDS 定, 与采样率无关)

    fs = 调制频率 × 调制周期(采样点)

  ★ 关键是 ①② 各自都不依赖采样率, 所以它们能反过来定出采样率。
================================================================================
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from data_sources import FS_OUT_CONFIRMED  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402

TOOLS = Path(__file__).resolve().parent.parent.parent / "tools"

# ---- mod_gen.v 的数 ----
CLK = 50_000_000
MOD_FREQ = 1000
PWM_FREQ = 100_000
PWM_DIV = CLK // PWM_FREQ
AMP_PCT = 60
AMP_DELTA = (PWM_DIV // 2 * AMP_PCT) // 100
PHASE_INC = (MOD_FREQ * 2**32) // CLK
F_MOD_DDS = PHASE_INC * CLK / 2**32


def load(p):
    raw = []

    def onp(r, f, s):
        raw.extend(parse_samples(r))

    a = PairAssembler(on_pair=onp)
    FrameParser(on_frame=a.feed).feed(Path(p).read_bytes())
    return np.array(raw, float)


def period_samples(x, iters=3):
    """精确测"每多少个采样点一个调制周期"。

    ★ 不能用"分段相位 polyfit + unwrap": 3 秒里有 ~3000 个周期,
      跨段相位差远大于 2π, unwrap 会解错 (实测给出负周期)。
      改用【两段相位差】: 先用 FFT 峰把频率定到 ±0.5 bin 以内,
      那么两段的相位差扣掉 2π·f0·Δt 之后只剩一个小量, 可以无歧义地 wrap。
      迭代几次就收敛到 ppm 级。
    """
    x = np.asarray(x, float)
    x = x - x.mean()
    n = len(x)

    # 粗频: FFT 峰 + 抛物线插值 (单位: 周期/采样点)
    S = np.abs(np.fft.rfft(np.hanning(n) * x))
    fr = np.fft.rfftfreq(n, 1.0)
    m = (fr > 0.02) & (fr < 0.2)
    k = int(np.argmax(S * m))
    y0, y1, y2 = (np.log(S[k - 1] + 1e-300), np.log(S[k] + 1e-300),
                  np.log(S[k + 1] + 1e-300))
    den = y0 - 2 * y1 + y2
    d = 0.5 * (y0 - y2) / den if abs(den) > 1e-15 else 0.0
    f = (k + float(np.clip(d, -0.5, 0.5))) / n

    # 两段相位差精修
    half = n // 2
    for _ in range(iters):
        ph, mid = [], []
        for sl in (slice(0, half), slice(half, 2 * half)):
            seg = x[sl]
            idx = np.arange(sl.start, sl.stop, dtype=float)
            ang = 2 * np.pi * f * idx
            A = np.column_stack([np.cos(ang), np.sin(ang)])
            c, *_ = np.linalg.lstsq(A, seg, rcond=None)
            ph.append(np.arctan2(-c[1], c[0]))
            mid.append(float(np.mean(idx)))
        dphi = np.angle(np.exp(1j * (ph[1] - ph[0] - 2 * np.pi * f * (mid[1] - mid[0]))))
        f = f + dphi / (2 * np.pi * (mid[1] - mid[0]))
    return 1.0 / f


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    print("=" * 88)
    print(" 一、mod_gen.v 的 DDS 到底产生多少 Hz (只看 50 MHz 时钟, 与采样率无关)")
    print("=" * 88)
    print(f"   PWM_DIV = {CLK}/{PWM_FREQ} = {PWM_DIV} 拍  "
          f"(整数, 无需取整 -> ADC 的 100 kSPS 同理: 50e6/100e3 = 500 也是整数)")
    print(f"   AMP_PCT = {AMP_PCT}% -> AMP_DELTA = {AMP_DELTA} "
          f"(占空比 {50 - AMP_DELTA / PWM_DIV * 100:.1f}% ~ {50 + AMP_DELTA / PWM_DIV * 100:.1f}%)")
    print(f"   PHASE_INC = floor({MOD_FREQ}*2^32/{CLK}) = {PHASE_INC}")
    print(f"   => 调制频率 = {PHASE_INC} * {CLK} / 2^32 = {F_MOD_DDS:.5f} Hz")

    print("")
    print("=" * 88)
    print(" 二、从真实抓包测'每多少个采样点一个调制周期' (与采样率无关)")
    print("=" * 88)
    print(f"   {'文件':<18}{'周期(采样点)':>16}{'反推 fs (Hz)':>16}")
    ps_list = []
    for fn in ("cap_145038.bin", "cap_145044.bin", "cap_145049.bin"):
        x = load(TOOLS / fn)
        P = period_samples(x)
        ps_list.append(P)
        print(f"   {fn:<18}{P:>16.5f}{F_MOD_DDS * P:>16.1f}")
    P = float(np.mean(ps_list))
    fs_implied = F_MOD_DDS * P

    print("")
    print("=" * 88)
    print(" 三、结论")
    print("=" * 88)
    print(f"   调制周期(平均)      = {P:.5f} 采样点")
    print(f"   调制频率(DDS)       = {F_MOD_DDS:.5f} Hz")
    print(f"   => 采样率 = 频率 × 周期 = {fs_implied:.1f} Hz")
    print("")
    for cand in (12500.0, 12680.0, FS_OUT_CONFIRMED):
        err = (fs_implied - cand) / cand * 100
        print(f"   若 fs = {cand:>8.0f} Hz : 反推调制频率 = {fs_implied / cand * 1000:.2f} Hz"
              f"  (与 DDS 差 {err:+.3f}%)")
    print("")
    print(f"   ★ 若真实采样率是 {fs_implied:.0f}, 那么调制周期 {P:.2f} 点 = "
          f"{P * 8:.1f} 个 ADC 采样点")
    print(f"   ★ 若按 12.68 kSPS 读, 调制频率会算成 {F_MOD_DDS * P * 12680 / fs_implied:.1f} Hz")
    print(f"   ★ 一个 50 MHz 晶体振荡器不可能偏 1.44% (典型 ±50 ppm = 0.005%)")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
r"""
================================================================================
 调制工况分析: 1 kHz 调制抓包 (C 于 2026-10-31 提供)
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py analyze_modulated.py ..\..\tools\cap_145038.bin ..\..\tools\cap_145044.bin ..\..\tools\cap_145049.bin

回答四个问题:
  Q1 基波频率/幅度到底是多少 (自动测, 不靠猜)
  Q2 精确 SNR 是多少 (只把基波当信号, 其余全部算噪声)
  Q3 ★"残差"里到底有多少是噪声、多少是谐波? 谐波是不是真的谐波?
  Q4 ★调制工况下残余噪声的频段分布 (与暗场用同一套 6 个频段对比)

★ Q3 是这次最关键的问题:
    C 用"128 点分块拟合 sin/cos 取残差"算 SNR, 得到 RAW 5.28 / FILT 4.95。
    但同一份数据里 2 kHz 分量有 5.6 LSB —— 和 5.28 是同一个量级。
    如果残差主要是【二次谐波】(PWM 驱动的非线性产物), 那它不是噪声,
    低通滤波器本来就不该滤掉它 (2 kHz 在 3.5 kHz 通带内)。
    这样"只提升 0.55 dB"就从"滤波器没用"变成"残差主体是被保留下来的信号失真",
    是完全不同的结论。所以必须判清楚。

  判据: 真谐波的相位与基波锁定 (跨块相位差稳定); 噪声的相位随机。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data_sources import FS_OUT_CONFIRMED  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402
from scipy.signal import welch  # noqa: E402
from snr_offline import snr_fit  # noqa: E402

BANDS = [(0, 500), (500, 1000), (1000, 2000), (2000, 3500), (3500, 4500), (4500, 6340)]


# ---------------------------------------------------------------------------
# 逐段口径 (报告采用这个)
# ---------------------------------------------------------------------------
# ★ 为什么必须逐段: 抓包里存在缓慢漂移。如果拿整段 3 秒拟合一组 cos/sin,
#   漂移会被留在残差里, 残差因此偏大 (实测全段 3.31 vs 逐段 2.5~2.9),
#   得到的"噪声"其实是"噪声 + 漂移残渣", 压制量会被系统性低估。
#   逐段 (每段 ~375 ms) 拟合只在局部成立, 残差才代表局部真实噪声。
#   报告取 8 段的中位数 (抗单段异常)。
def seg_noise(x: np.ndarray, fs: float, f0: float, ks=(1, 2, 3, 4, 5),
              nseg: int = 8):
    """逐段扣掉 k*f0 分量, 返回各段残差 rms 数组。ks=(1,) 就是"只扣基波"。"""
    x = np.asarray(x, float) - np.mean(x)
    bs = len(x) // nseg
    out = []
    for b in range(nseg):
        seg = x[b * bs:(b + 1) * bs]
        idx = np.arange(len(seg))
        cols = []
        for k in ks:
            if k * f0 > fs / 2 * 0.95:
                continue
            ph = 2 * np.pi * k * f0 * idx / fs
            cols += [np.cos(ph), np.sin(ph)]
        A = np.column_stack(cols)
        c, *_ = np.linalg.lstsq(A, seg, rcond=None)
        r = seg - A @ c
        out.append(float(np.sqrt(np.mean(r ** 2))))
    return np.array(out)



def load(path: Path, fs: float):
    raw, filt, seqs = [], [], []

    def onp(r, f, seq):
        raw.extend(parse_samples(r))
        filt.extend(parse_samples(f))
        seqs.append(seq)

    asm = PairAssembler(on_pair=onp)
    fp = FrameParser(on_frame=asm.feed)
    fp.feed(path.read_bytes())
    return np.array(raw, float), np.array(filt, float), fp.stats, asm.stats, np.array(seqs)


def find_tone(x: np.ndarray, fs: float, lo=100.0, hi=4000.0):
    """在 [lo,hi] 内找最强的单频, 返回 (频率, 幅度, 相位)。"""
    n = len(x)
    x = x - x.mean()
    win = np.hanning(n)
    S = np.abs(np.fft.rfft(win * x))
    freqs = np.fft.rfftfreq(n, 1.0 / fs)
    m = (freqs >= lo) & (freqs <= hi)
    k = int(np.argmax(S * m))
    # 抛物线插值
    if 1 <= k < len(S) - 1:
        y0, y1, y2 = (np.log(S[k - 1] + 1e-300), np.log(S[k] + 1e-300),
                      np.log(S[k + 1] + 1e-300))
        den = y0 - 2 * y1 + y2
        d = 0.5 * (y0 - y2) / den if abs(den) > 1e-15 else 0.0
        k = k + float(np.clip(d, -0.5, 0.5))
    f0 = float(k * fs / n)
    # 在 f0 上最小二乘拟合, 拿幅度与相位
    idx = np.arange(n)
    ph = 2 * np.pi * f0 * idx / fs
    A = np.column_stack([np.cos(ph), np.sin(ph)])
    c, *_ = np.linalg.lstsq(A, x, rcond=None)
    amp = float(np.hypot(*c))
    phase = float(np.arctan2(-c[1], c[0]))
    return f0, amp, phase


def fit_harmonics(x: np.ndarray, fs: float, f0: float, kmax: int = 6, blocks: int = 8):
    """拟合 k*f0 各次谐波, 返回 {k: (幅度, 块间相位抖动度)}。"""
    n = len(x)
    x = x - x.mean()
    bs = n // blocks
    out = {}
    for k in range(1, kmax + 1):
        fk = k * f0
        if fk > fs / 2 * 0.95:
            continue
        amps, phases = [], []
        for b in range(blocks):
            seg = x[b * bs:(b + 1) * bs]
            idx = np.arange(len(seg))
            ph = 2 * np.pi * fk * idx / fs
            A = np.column_stack([np.cos(ph), np.sin(ph)])
            c, *_ = np.linalg.lstsq(A, seg, rcond=None)
            amps.append(float(np.hypot(*c)))
            phases.append(float(np.arctan2(-c[1], c[0])))
        out[k] = (float(np.mean(amps)), np.array(phases))
    return out


def circ_std(a: np.ndarray) -> float:
    """圆统计的标准差 (度)。"""
    z = np.mean(np.exp(1j * a))
    r = abs(z)
    if r <= 1e-12:
        return 180.0
    return float(np.degrees(np.sqrt(-2.0 * np.log(r))))


def band_dist(x: np.ndarray, fs: float):
    x = x - x.mean()
    f, P = welch(x, fs=fs, nperseg=min(1024, len(x) // 2))
    df = f[1] - f[0]
    tot = float(np.sum(P) * df)
    out = []
    for lo, hi in BANDS:
        m = (f >= lo) & (f < hi)
        out.append(float(np.sum(P[m]) * df))
    return out, tot


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    args = sys.argv[1:]
    if not args:
        t = HERE.parent.parent / "tools"
        args = [str(t / "cap_145038.bin"), str(t / "cap_145044.bin"),
                str(t / "cap_145049.bin")]
    rows = []
    for a in args:
        p = Path(a)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        if not p.exists():
            print(f"  跳过 {p}")
            continue
        raw, filt, ps, qs, seqs = load(p, FS_OUT_CONFIRMED)
        n = min(len(raw), len(filt))
        raw, filt = raw[:n], filt[:n]
        dur = n / FS_OUT_CONFIRMED
        print("=" * 96)
        print(f" {p.name}: {n} 点 ({dur:.2f}s) | 好帧 {ps.frames_ok} 校验错 {ps.checksum_errors} "
              f"配对 {qs.pairs_ok} | SEQ {seqs[0]}..{seqs[-1]}")
        print(f"   均値 RAW {raw.mean():.1f} / FILT {filt.mean():.1f} | "
              f"交流 rms RAW {raw.std():.2f} / FILT {filt.std():.2f}")
        print("=" * 96)

        # ---- Q1 基波 ----
        f0, amp, ph0 = find_tone(raw, FS_OUT_CONFIRMED)
        print(f"  Q1 基波: {f0:.3f} Hz, 幅度 {amp:.2f} LSB "
              f"(峰峰 {2 * amp:.0f} LSB), rms {amp / np.sqrt(2):.2f}")

        # ---- Q2 精确 SNR (只把基波当信号) ----
        s_raw = snr_fit(raw, FS_OUT_CONFIRMED, f0, freq_tol=0.01, return_parts=True)
        s_flt = snr_fit(filt, FS_OUT_CONFIRMED, f0, freq_tol=0.01, return_parts=True)
        snr_r, d_r = s_raw
        snr_f, d_f = s_flt
        print(f"     精修后的频率 (最小化残差得到): {d_r['f_est']:.3f} Hz")
        print(f"  Q2 精确 SNR (基波 / 其余全部):"
              f"  RAW {snr_r:.2f} dB -> FILT {snr_f:.2f} dB  (Δ {snr_f - snr_r:+.2f} dB)")
        print(f"     残差功率: RAW {d_r['p_noise']:.3f} (rms {np.sqrt(d_r['p_noise']):.2f}) "
              f"/ FILT {d_f['p_noise']:.3f} (rms {np.sqrt(d_f['p_noise']):.2f})")

        # ---- Q3 谐波: 是"真谐波"还是噪声? ----
        hr = fit_harmonics(raw, FS_OUT_CONFIRMED, f0)
        hf = fit_harmonics(filt, FS_OUT_CONFIRMED, f0)
        print("")
        print(f"  Q3 谐波分解 (k*f0, 单位为 LSB):")
        print(f"     {'k':>2}{'频率':>9}{'RAW幅度':>9}{'FILT幅度':>9}{'保留':>8}"
              f"{'RAW相位抖动':>12}{'FILT相位抖动':>13}")
        # 相对基波的相位, 判断是否锁相
        rel_r, rel_f = {}, {}
        base_r, base_f = hr[1][1], hf[1][1]
        for k in sorted(hr):
            if k == 1:
                continue
            ar, pr = hr[k]
            af, pf = hf[k]
            # 二次非线性: k 次谐波相位 ≈ k*基波相位 + 常数 -> 扣除后应稳定
            dr = np.angle(np.exp(1j * (pr - k * base_r)))
            df_ = np.angle(np.exp(1j * (pf - k * base_f)))
            rel_r[k], rel_f[k] = circ_std(dr), circ_std(df_)
            print(f"     {k:>2}{k * f0:>8.0f}Hz{ar:>9.3f}{af:>9.3f}"
                  f"{(af / ar if ar > 0 else 0) * 100:>7.1f}%"
                  f"{rel_r[k]:>10.1f}°{rel_f[k]:>12.1f}°")
        print("     (相对 k*基波相位 的圆标准差; 小 = 锁定 = 真谐波, 大 = 随机 = 噪声)")

        # ---- 把谐波也减掉后的"纯噪声" ----
        def strip(x, ks):
            x = x - x.mean()
            idx = np.arange(len(x))
            cols = []
            for k in ks:
                ph = 2 * np.pi * k * f0 * idx / FS_OUT_CONFIRMED
                cols += [np.cos(ph), np.sin(ph)]
            A = np.column_stack(cols)
            c, *_ = np.linalg.lstsq(A, x, rcond=None)
            return x - A @ c

        ks = [k for k in sorted(hr) if hr[k][0] > 0.2]      # 含 k=1 基波
        pure_r = strip(raw, ks)
        pure_f = strip(filt, ks)
        pn_r = float(np.mean(pure_r ** 2))
        pn_f = float(np.mean(pure_f ** 2))
        psig = float(d_r["p_sig"])
        print("")
        print(f"  扣除 基波 + {len(ks) - 1} 次谐波 ({', '.join(f'{k}f0' for k in ks)}) 后的【纯噪声】:")
        print(f"     RAW rms {np.sqrt(pn_r):.2f} LSB -> FILT rms {np.sqrt(pn_f):.2f} LSB"
              f"   (噪声压低 {20 * np.log10(np.sqrt(pn_f / pn_r)):+.2f} dB)")
        print(f"     纯噪声 SNR: RAW {10 * np.log10(psig / pn_r):.2f} dB -> "
              f"FILT {10 * np.log10(psig / pn_f):.2f} dB "
              f"(Δ {10 * np.log10(pn_r / pn_f):+.2f} dB)")
        print(f"     对比: 只扣基波时 ΔSNR = {snr_f - snr_r:+.2f} dB (残差里混了谐波)")

        # ---- Q4 残余噪声频段分布 ----
        dr_, tot_r = band_dist(pure_r, FS_OUT_CONFIRMED)
        df_, tot_f = band_dist(pure_f, FS_OUT_CONFIRMED)
        print("")
        print("  Q4 残余【纯噪声】频段分布 (扣除基波与谐波后, 与暗场同一套频段):")
        print(f"     {'频段':>14}{'RAW 占比':>10}{'FILT 占比':>11}")
        for (lo, hi), vr, vf in zip(BANDS, dr_, df_):
            print(f"     {lo:>5}-{hi:<6}Hz{lr(vr, tot_r):>9.1f}%{lr(vf, tot_f):>10.1f}%")
        print(f"     {'合计':>14}{100.0:>9.1f}%{100.0:>10.1f}%")

        rows.append(dict(name=p.stem, f0=f0, amp=amp, snr_r=snr_r, snr_f=snr_f,
                         pn_r=np.sqrt(pn_r), pn_f=np.sqrt(pn_f),
                         band_r=[lr(v, tot_r) for v in dr_],
                         band_f=[lr(v, tot_f) for v in df_]))
        print("")

    if len(rows) > 1:
        print("=" * 96)
        print(" 汇总")
        print("=" * 96)
        print(f"  {'文件':<14}{'基波Hz':>9}{'幅度':>8}{'SNR_RAW':>9}{'SNR_FILT':>10}"
              f"{'ΔSNR':>8}{'纯噪RAW':>9}{'纯噪FILT':>10}")
        for r in rows:
            print(f"  {r['name']:<14}{r['f0']:>9.2f}{r['amp']:>8.1f}{r['snr_r']:>9.2f}"
                  f"{r['snr_f']:>10.2f}{r['snr_f'] - r['snr_r']:>+8.2f}"
                  f"{r['pn_r']:>9.2f}{r['pn_f']:>10.2f}")
        print("")
        print(f"  {'文件':<14}" + "".join(f"{f'{lo}-{hi}':>12}" for lo, hi in BANDS))
        for r in rows:
            print(f"  {r['name']:<14}" + "".join(f"{v:>11.1f}%" for v in r['band_r']))


def lr(v, tot):
    return 100.0 * v / tot if tot > 0 else 0.0


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
r"""
================================================================================
 上位机界面: 串口解析 + 成对帧状态机 + 12.5 kSPS 实时绘图 + 丢帧检查
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui

    py dashboard.py                          # 界面, 默认用【假数据】(不需要硬件)
    py dashboard.py --source serial --port COM10    # 真实串口 (需先装 pyserial)
    py dashboard.py --headless 10 --png out.png     # 无界面跑 10 秒, 出图+出统计

依赖:
    tkinter (Python 标准库) + matplotlib (已装) -> 【本步不需要安装任何东西】
    只有接真实串口才需要: py -m pip install pyserial

--------------------------------------------------------------------------------
 界面里有什么
--------------------------------------------------------------------------------
    上: 时域曲线 —— 灰色=原始(带噪), 红色=滤波后, 两者是【同一个采样点】(协议保证)
    下: 功率谱   —— 看截止频率以上的噪声被砍掉, 这是不依赖"干净参考"的客观证据
    状态栏: 帧统计 / 实测样本率(丢帧检查) / 信噪比估计 / 刷新率

--------------------------------------------------------------------------------
 丢帧检查说明 (诚实交代能力边界)
--------------------------------------------------------------------------------
    A 定的协议里【没有帧计数器】, 所以能查到和不能查到的是:
      能查到: 校验和错(帧被破坏)、失步(丢字节)、配对错(丢了 0x02)、孤儿(丢了 0x01)
      查不到: 【整对丢失】—— 原始和滤波后两帧一起丢, 帧流本身看不出任何异常
    对"整对丢失"用【样本率】兜底: 按 12.5 kSPS 推算应收到多少样本, 与实收对比,
    累计缺口持续变大就说明在丢整对数据。这是估算, 不是精确计数。
    => 想精确计数, 正式方案是协议里加 1 字节帧计数器 (我已向 A 提出, 待确认)。
================================================================================
"""

from __future__ import annotations

import argparse
import sys
import time
from collections import deque
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from data_sources import (BYTE_RATE, FS_HW, FS_OUT_CONFIRMED, FRAME_POINTS,  # noqa: E402
                          FakeFpgaSource, FileSource, SerialSource, list_ports)
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402
from snr_offline import snr_fit  # noqa: E402

DEFAULT_FSIG = 1562.5      # Hz, 与 sim/pd_src.v 一致
# 时域显示多少个点。12.5 kSPS 下 80 点 = 6.4 ms ≈ 1562.5 Hz 的 10 个周期。
# ★ 不要设太大: 抽点后每周期只有 8 个点, 显示几百个点会变成"一条实心带",
#   看不出波形形状 (演示时最重要的是让评委看清"原始毛糙 / 滤波后干净")。
DEFAULT_WINDOW = 80
BUF_SAMPLES = 16384        # 环形缓冲长度 (1.31 s @12.5 kSPS), PSD 用
REDRAW_MS = 120            # 刷新间隔


# ==============================================================================
# 信噪比估计 —— 不依赖"干净参考信号"
# ==============================================================================
def _bh_window(n: int) -> np.ndarray:
    """4 项 Blackman-Harris 窗: 最高旁瓣约 -92 dB。

    ★ 选窗是这里的关键:
       矩形窗旁瓣 -13 dB, Hann 窗 -31 dB。降噪后 SNR 约 50 dB 时,
       信号比噪声底高 1e5 倍, 而 Hann 的 -31 dB 旁瓣 = 信号能量的 8e-4,
       比噪声底还高约 100 倍 —— 泄漏会被当成噪声算进去, 实测把 SNR 压低 5~6 dB。
       换成 -92 dB 旁瓣后, 泄漏只有信号能量的 6e-10,
       比噪声底低 6 个量级, 彻底不影响。
       代价是主瓣变宽 (约 ±4 bin), 掩蔽窗 ±8 bin 仍然罩得住。
    """
    a0, a1, a2, a3 = 0.35875, 0.48829, 0.14128, 0.01168
    k = np.arange(n)
    t = 2.0 * np.pi * k / (n - 1)
    return a0 - a1 * np.cos(t) + a2 * np.cos(2 * t) - a3 * np.cos(3 * t)


def snr_tone(x: np.ndarray, fs: float, f_sig: float,
             seg_len: int = 2048, mask_bins: int = 8, max_seg: int = 8,
             freq_tol: float = 0.05, return_parts: bool = False):
    r"""估计"单音信号 vs 其余全部"的信噪比 (dB)。已知大致调制频率时可用。

    做法 (直接量噪声, 不做大数相减):
      1) 加【Blackman-Harris 窗】(旁瓣 -92 dB) 做 FFT
      2) 在期望频点附近找实际峰值 (吸收采样率误差), 把峰值周围 ±mask_bins 挖掉
      3) 剩下频点的能量 / 归一化系数 = 噪声功率
      4) 信号功率 = 总功率 − 噪声功率 (减的是小量, 条件数良好)
      归一化: 对白噪声 E[Σ|X[k]|²] = N·Σw²·σ², 所以 σ² = Σ|X[k]|²/(N·Σw²)

    ★ 为什么不用"总功率 − 最小二乘拟合正弦":
      50 dB 时噪声只占总功率 1e-5, 大数相减 = 灾难性抵消。
      更麻烦的是: 拟合对频率精度要求到 ppm 级 —— 实测频率差 0.09 Hz
      就让残差从 539 涨到 3571 (因为信号太强, 任何频率失配都漏进残差),
      而抛物线插值只能到 ~0.1 bin, 远远不够。

    ★ 为什么不用 Hann 窗:
      旁瓣 -31 dB, 在 50 dB 信噪比下泄漏比噪声底高 100 倍 -> SNR 被压低 5~6 dB。
      换 Blackman-Harris (-92 dB) 后泄漏可忽略。

    ★ 为什么要在期望频点附近【搜峰】而不是直接用期望频点:
      采样率若与假设不符 (实测 12.68 kSPS 而按 12.5 kSPS 算, 差 1.44%),
      N=8192 时频点会偏 15 个 bin, ±8 的掩蔽就罩不住信号了。
      搜峰范围取 max(8, 5% 频点), 几个百分点的采样率误差都能吸收。

    ★ 分段平均: 滤波后噪声带宽只有约 3.5 kHz, 2048 点里独立噪声样本很少,
      单段方差大 (±0.5 dB)。切成多段先功率线性平均再取 dB, 方差按 sqrt(段数) 下降。

    已知残余偏差: 挖掉信号频带时也挖掉了那一段里的噪声, 按"噪声在频域平坦"补偿;
      对带限噪声补偿不完全, 实测残余约 +0.1~0.3 dB (偏乐观)。

    参考: Harris, "On the use of windows for harmonic analysis with the
      discrete Fourier transform", Proc. IEEE 1978 (各种窗的旁瓣指标);
      scipy.signal.welch 官方文档; Parseval 定理。
    """
    x = np.asarray(x, dtype=np.float64)
    n = len(x)
    if n < 512 or not (0.0 < f_sig < fs / 2.0):
        return None
    nseg = int(min(max_seg, max(1, n // seg_len)))
    use = nseg * seg_len
    if use < 512 or use > n:
        seg_len = n
        nseg = 1
        use = n
    x = x[-use:]

    win = _bh_window(seg_len)
    wt = np.full(seg_len // 2 + 1, 2.0)
    wt[0] = 1.0
    if seg_len % 2 == 0:
        wt[-1] = 1.0
    denom = seg_len * float(np.sum(win ** 2))

    specs = []
    p_tot = 0.0
    for i in range(nseg):
        seg = x[i * seg_len:(i + 1) * seg_len]
        seg = seg - seg.mean()
        specs.append(np.abs(np.fft.rfft(win * seg)) ** 2)
        p_tot += float(np.mean(seg ** 2))
    p_tot /= nseg
    S = np.mean(specs, axis=0)

    # ---- 在期望频点附近搜峰, 吸收采样率误差 ----
    k0_exp = int(round(f_sig * seg_len / fs))
    if k0_exp >= len(wt):
        return None
    span = max(8, int(round(freq_tol * max(1, k0_exp))))
    lo_s = max(0, k0_exp - span)
    hi_s = min(len(wt), k0_exp + span + 1)
    k0 = lo_s + int(np.argmax(S[lo_s:hi_s]))

    keep = wt.copy()
    keep[max(0, k0 - mask_bins):min(len(wt), k0 + mask_bins + 1)] = 0.0
    frac = float(np.sum(keep) / np.sum(wt))
    if frac <= 0.0:
        return None
    p_noise = float(np.sum(S * keep) / denom / frac)

    p_sig = p_tot - p_noise
    if p_sig <= 0.0 or p_noise <= 0.0:
        return None
    snr = 10.0 * np.log10(p_sig / p_noise)
    if return_parts:
        return snr, dict(p_tot=p_tot, p_sig=p_sig, p_noise=p_noise,
                         nseg=nseg, seg_len=seg_len, frac=frac,
                         k0=k0, k0_exp=k0_exp)
    return snr


def welch_psd(x: np.ndarray, fs: float, nperseg: int = 1024):
    from scipy.signal import welch
    return welch(np.asarray(x, dtype=np.float64), fs=fs, nperseg=nperseg)


# ==============================================================================
# 数据管线: 数据源 -> 解析 -> 配对 -> 环形缓冲 + 统计
# ==============================================================================
class Pipeline:
    """界面和 headless 自检共用的一套管线 (界面只是它的一个显示层)。"""

    def __init__(self, source, f_sig: float = DEFAULT_FSIG,
                 fs_out: float = FS_OUT_CONFIRMED, buf: int = BUF_SAMPLES,
                 log_path: str | None = None):
        self.src = source
        self.f_sig = f_sig
        self.fs_out = float(fs_out)
        self.raw = deque(maxlen=buf)
        self.filt = deque(maxlen=buf)
        # 数据存盘: 每对帧追加 64 行 "seq,raw,filt" 到 CSV
        self.log_path = Path(log_path) if log_path else None
        self._log_buf = []
        self._log_fh = None
        self._log_n = 0

        self.assembler = PairAssembler(on_pair=self._on_pair)
        self.parser = FrameParser(on_frame=self.assembler.feed)
        # 回放循环绕回时重置 SEQ 计数 (否则会显示"丢了 6 万对", 那是回放造成的)
        if hasattr(source, "on_wrap"):
            source.on_wrap = self._resync_seq

        self.n_samples = 0
        self.t_first = None
        self.gap_reported = 0
        self.last_deficit = 0.0
        self.last_seq = None
        # 音调频率缓存: 精修一次要 38ms, 实时界面里几秒才需要精修一次
        self._f_tone = None
        self._f_tone_t = 0.0
        # f_sig <= 0 表示自动检测 (接真机时调制频率不一定是 1562.5 Hz)
        self._fsig_auto = None

    def _resync_seq(self) -> None:
        """回放绕回文件头时调用: 忘掉上一对 SEQ, 避免把"绕回"算成丢帧。"""
        self.assembler.last_seq = None

    def _resolve_fsig(self, x) -> float:
        """调制频率。给了就用给的, 给 0 就在 100~4000 Hz 内自动找最强单频。"""
        if self.f_sig and self.f_sig > 0:
            return float(self.f_sig)
        if self._fsig_auto is None:
            n = len(x)
            if n < 512:
                return DEFAULT_FSIG
            win = np.hanning(n)
            S = np.abs(np.fft.rfft((np.asarray(x, float) - np.mean(x)) * win))
            fr = np.fft.rfftfreq(n, 1.0 / self.fs_out)
            m = (fr >= 100.0) & (fr <= 4000.0)
            if not m.any():
                return DEFAULT_FSIG
            self._fsig_auto = float(fr[int(np.argmax(S * m))])
        return self._fsig_auto

    def _freq_hint(self):
        """频率缓存: 5 秒内的精修结果直接复用 (省掉 38ms -> 1.5ms)。"""
        if self._f_tone is not None and (time.perf_counter() - self._f_tone_t) < 5.0:
            return self._f_tone
        return None

    def _on_pair(self, raw_bytes: bytes, filt_bytes: bytes, seq: int = 0) -> None:
        self.raw.extend(parse_samples(raw_bytes))
        self.filt.extend(parse_samples(filt_bytes))
        self.n_samples += len(raw_bytes) // 2
        self.last_seq = seq
        if self.log_path is not None:
            self._log_buf.append((seq, raw_bytes, filt_bytes))

    def flush_log(self) -> None:
        """把攒下的帧写进 CSV。界面上每次刷新调用一次, 退出前调用一次。"""
        if self.log_path is None or not self._log_buf:
            return
        if self._log_fh is None:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            new = not self.log_path.exists()
            self._log_fh = open(self.log_path, "a", encoding="utf-8", newline="")
            if new:
                self._log_fh.write("seq,raw,filt\n")
        for seq, rb, fb in self._log_buf:
            for r, f in zip(parse_samples(rb), parse_samples(fb)):
                self._log_fh.write(f"{seq},{r},{f}\n")
        self._log_n += len(self._log_buf)
        self._log_buf.clear()
        self._log_fh.flush()

    def close(self) -> None:
        self.flush_log()
        if self._log_fh is not None:
            self._log_fh.close()
            self._log_fh = None

    def poll(self, max_bytes: int = 65536) -> int:
        data = self.src.read(max_bytes)
        if data:
            if self.t_first is None:
                self.t_first = time.perf_counter()
            self.parser.feed(data)
        return len(data)

    # ---- 丢帧检查: 用样本率兜底, 抓"整对丢失" ----
    def rate_check(self):
        """返回 (实测样本率, 期望样本率, 累计缺口样本数)。"""
        if self.t_first is None:
            return 0.0, self.fs_out, 0.0
        dt = time.perf_counter() - self.t_first
        if dt <= 0.2:
            return 0.0, self.fs_out, 0.0
        expect = dt * self.fs_out
        self.last_deficit = expect - self.n_samples
        return self.n_samples / dt, self.fs_out, self.last_deficit

    def snr_pair(self):
        """(原始 SNR, 滤波后 SNR)。用【精确拟合】而不是频谱挖除。

        ★ 为什么换掉频谱挖除法: 它把信号频率附近 ±8 个频点整段挖掉,
          如果真实噪声在信号频率附近本来就有干扰 (实测抓包里确实有:
          一串 12.4 Hz 谐波正好落在 1004 Hz 附近), 那部分【真实噪声】被一起挖掉,
          噪声被低估 -> SNR 虚高。实测虚高 6~12 dB, 加长采集也消不掉。
          精确拟合只减掉那一个正弦 (2 个自由度), 附近噪声原样保留。
          实测在真实抓包上误差 0.00 dB (见 snr_budget.py)。
        """
        need = 4096
        if len(self.raw) < need:
            return None, None
        r = np.fromiter(self.raw, dtype=np.int64, count=len(self.raw))[-16384:]
        f = np.fromiter(self.filt, dtype=np.int64, count=len(self.filt))[-16384:]
        fsig = self._resolve_fsig(r)
        hint = self._freq_hint()
        o1 = snr_fit(r, self.fs_out, fsig, f_hint=hint, return_parts=True)
        if o1 is None:
            return None, None
        self._f_tone = o1[1]["f_est"]
        self._f_tone_t = time.perf_counter()
        o2 = snr_fit(f, self.fs_out, fsig, f_hint=self._f_tone, return_parts=True)
        return o1[0], (o2[0] if o2 else None)

    def status_text(self) -> str:
        rs, fs, _ = self.rate_check()
        r_snr, f_snr = self.snr_pair()
        ps = self.parser.stats
        qs = self.assembler.stats
        parts = [
            f"好帧 {ps.frames_ok}",
            f"配成 {qs.pairs_ok} 对",
            f"实测 {rs:.0f} S/s (期望 {fs:.0f})",
            f"校验错 {ps.checksum_errors}",
            f"失步 {ps.sync_errors}",
            f"配对错 {qs.pairing_errors}",
        ]
        # ★ 有了 SEQ 之后的精确丢帧计数 (不再是估算)
        if qs.pairs_lost or qs.seq_mismatch:
            parts.append(f"⚠SEQ丢失 {qs.pairs_lost} 对/错配 {qs.seq_mismatch}")
        else:
            parts.append("SEQ连续")
        if r_snr is not None and f_snr is not None:
            parts.append(f"SNR {r_snr:.2f}→{f_snr:.2f} dB ({f_snr - r_snr:+.2f})")
        else:
            parts.append("SNR 采集中…")
        return "  |  ".join(parts)


# ==============================================================================
# 有限状态: 采样率异常判定
# ==============================================================================
def rate_verdict(measured: float, expect: float, deficit: float) -> str:
    """把样本率结果翻译成"有没有丢数据"的一句话。"""
    if measured <= 0:
        return "等待数据…"
    ratio = measured / expect
    if ratio < 0.98 or deficit > expect * 0.5:
        return f"⚠ 疑似丢数据 (实测率只有期望的 {ratio * 100:.0f}%)"
    return "样本率正常"


# ==============================================================================
# 无界面模式: 用来做验证 (不需要显示器, 结果可出图)
def make_source(args):
    """按 --source 建数据源。界面和无界面自检共用, 避免两边行为不一致。"""
    src_kind = getattr(args, "source", "fake")
    if src_kind == "serial":
        if not args.port:
            raise RuntimeError("--source serial 需要 --port COMx (先跑 py serial_check.py 看有哪些口)")
        return SerialSource(args.port)
    if src_kind == "file":
        if not args.file:
            raise RuntimeError("--source file 需要 --file X.bin (回放真实抓包)")
        return FileSource(args.file, fs_out=args.fsout,
                          loop=not getattr(args, "once", False))
    return FakeFpgaSource(f_sig=args.fsig if getattr(args, "fsig", 0) > 0 else 1562.5,
                          noise_amp=args.noise, fs_out=args.fsout,
                          drop_frame_prob=0.02 if args.faults else 0.0,
                          drop_pair_prob=0.01 if args.faults else 0.0,
                          corrupt_prob=0.01 if args.faults else 0.0,
                          drop_byte_prob=0.005 if args.faults else 0.0)


# ==============================================================================
def run_headless(args) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    src = make_source(args)
    pipe = Pipeline(src, f_sig=args.fsig, fs_out=args.fsout, log_path=args.log)

    print("=" * 78)
    print(f" 无界面自检: {src.name}, 跑 {args.headless} 秒")
    print(f" 故障注入: {'开 (演示丢帧检查)' if args.faults else '关'}")
    print(f" 调制频率: {'自动检测' if args.fsig <= 0 else f'{args.fsig:.1f} Hz'}")
    print("=" * 78)
    t0 = time.perf_counter()
    last = t0
    while time.perf_counter() - t0 < args.headless:
        pipe.poll()
        pipe.flush_log()
        time.sleep(0.005)
        if time.perf_counter() - last > 1.0:
            last = time.perf_counter()
            print(f"  [{time.perf_counter() - t0:5.1f}s] {pipe.status_text()}")
    pipe.close()

    rs, fs, deficit = pipe.rate_check()
    ps, qs = pipe.parser.stats, pipe.assembler.stats
    r_snr, f_snr = pipe.snr_pair()
    truth = src.true_snr() if hasattr(src, "true_snr") else None

    print("")
    print("-" * 78)
    print(" 解析统计")
    print("-" * 78)
    print(f"  收到字节      : {ps.bytes_in} (= {ps.bytes_in / BYTE_RATE:.2f} 秒 @921600)")
    print(f"  好帧          : {ps.frames_ok}")
    print(f"  校验错        : {ps.checksum_errors}")
    print(f"  失步          : {ps.sync_errors}")
    print(f"  坏类型/坏长度 : {ps.bad_type} / {ps.bad_len}")
    print(f"  垃圾字节      : {ps.garbage_bytes}")
    print("")
    print(f"  成功配对      : {qs.pairs_ok}")
    print(f"  配对错(丢0x02): {qs.pairing_errors}")
    print(f"  孤儿帧(丢0x01): {qs.orphan_filt}")
    print(f"  长度不等      : {qs.length_mismatch}")
    print(f"  SEQ 错配      : {qs.seq_mismatch}   (同一对两帧 SEQ 不等)")
    print(f"  SEQ 跳号次数  : {qs.seq_gaps}")
    print(f"  ★SEQ 精确丢失 : {qs.pairs_lost} 对   (不再是估算, 是数出来的)")
    print(f"  SEQ 重复      : {qs.seq_duplicate}")
    print(f"  最后 SEQ      : {pipe.last_seq}")
    print("")
    print("-" * 78)
    print(" 丢帧检查 (双口径交叉验证)")
    print("-" * 78)
    print(f"  [精确] SEQ 跳号丢失 : {qs.pairs_lost} 对 "
          f"= {qs.pairs_lost * FRAME_POINTS} 个采样点")
    print(f"  [估算] 实测样本率   : {rs:.0f} S/s   期望 {fs:.0f} S/s")
    print(f"         累计缺口     : {deficit:+.0f} 个样本")
    print(f"         判定         : {rate_verdict(rs, fs, deficit)}")
    print(f"  两者若矛盾(SEQ 说没丢但样本率偏低) -> 说明问题不在丢帧, 在时序/波特率")
    print("")
    print("-" * 78)
    print(" 信噪比估计 (信号=调制基波, 噪声=其余全部)")
    print("-" * 78)
    if r_snr is None:
        print("  样本不足, 无法估计")
    else:
        print(f"  界面估计 : 原始 {r_snr:6.2f} dB -> 滤波后 {f_snr:6.2f} dB "
              f"(提升 {f_snr - r_snr:+.2f} dB)")
        if truth is not None:
            print(f"  仿真真值 : 原始 {truth[0]:6.2f} dB -> 滤波后 {truth[1]:6.2f} dB "
                  f"(提升 {truth[1] - truth[0]:+.2f} dB)")
            print(f"  估计误差 : 原始 {r_snr - truth[0]:+.2f} dB, "
                  f"滤波后 {f_snr - truth[1]:+.2f} dB")
        else:
            print("  (真实数据没有仿真真值可比; 估计器精度见 analyze_modulated.py)")

    # ---- 出图 ----
    fig, ax = plt.subplots(2, 1, figsize=(13, 7), height_ratios=[2, 1])
    raw = np.fromiter(pipe.raw, dtype=np.int64, count=len(pipe.raw))
    flt = np.fromiter(pipe.filt, dtype=np.int64, count=len(pipe.filt))
    n = min(len(raw), len(flt))
    raw, flt = raw[-n:], flt[-n:]
    win = min(args.window, n)
    t = np.arange(win) / pipe.fs_out * 1000.0
    ax[0].plot(t, raw[-win:], color="0.65", lw=0.8, label="原始 (带噪)")
    ax[0].plot(t, flt[-win:], color="crimson", lw=1.2, label="滤波后")
    title = (f"上位机实时显示 ({pipe.src.name})   fs={pipe.fs_out:.0f} S/s, "
             f"显示 {win} 点 = {win / pipe.fs_out * 1000:.0f} ms")
    if r_snr is not None and f_snr is not None:
        title += (f"\nSNR {r_snr:.2f} -> {f_snr:.2f} dB "
                  f"(提升 {f_snr - r_snr:+.2f} dB)")
    ax[0].set_title(title)
    ax[0].set_xlabel("时间 (ms)")
    ax[0].set_ylabel("幅度 (LSB)")
    ax[0].grid(alpha=0.3)
    ax[0].legend(fontsize=9)

    if n >= 1024:
        fr, pr = welch_psd(raw, pipe.fs_out)
        _, pf = welch_psd(flt, pipe.fs_out)
        ax[1].plot(fr / 1000.0, 10 * np.log10(pr), color="0.65", lw=0.9, label="原始")
        ax[1].plot(fr / 1000.0, 10 * np.log10(pf), color="crimson", lw=1.0, label="滤波后")
        ax[1].set_xlabel("频率 (kHz)")
        ax[1].set_ylabel("PSD (dB/Hz)")
        ax[1].set_title("功率谱: 截止频率以上噪声被砍掉 (Nyquist 6.25 kHz)", fontsize=10)
        ax[1].grid(alpha=0.3)
        ax[1].legend(fontsize=9)
        ax[1].set_xlim(0, 6.25)

    fig.tight_layout()
    if args.png:
        fig.savefig(args.png, dpi=125)
        print("")
        print(f"  已出图: {args.png}")
    plt.close(fig)


# ==============================================================================
# 图形界面
# ==============================================================================
def run_gui(args) -> None:
    import tkinter as tk
    from tkinter import ttk

    import matplotlib
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    root = tk.Tk()
    root.title("微弱光电信号降噪 · 上位机")
    # 尺寸取"能放进常见笔记本屏幕"的值, 用户可自行最大化
    root.geometry("1180x720")

    # ---------------- 顶部控制栏 ----------------
    bar = ttk.Frame(root, padding=6)
    bar.pack(side=tk.TOP, fill=tk.X)

    state = {"pipe": None, "running": False, "src": None}

    ttk.Label(bar, text="数据源:").pack(side=tk.LEFT)
    src_var = tk.StringVar(value=args.source)
    ttk.Radiobutton(bar, text="假数据", variable=src_var,
                    value="fake").pack(side=tk.LEFT)
    ttk.Radiobutton(bar, text="串口", variable=src_var,
                    value="serial").pack(side=tk.LEFT)
    ttk.Radiobutton(bar, text="回放抓包", variable=src_var,
                    value="file").pack(side=tk.LEFT)

    ports = list_ports()
    port_names = [p[0] for p in ports] or ["(无可用串口)"]
    port_var = tk.StringVar(value=port_names[0])
    ttk.Combobox(bar, textvariable=port_var, values=port_names,
                 width=12, state="readonly").pack(side=tk.LEFT, padx=4)

    ttk.Label(bar, text="显示点数:").pack(side=tk.LEFT, padx=(10, 2))
    win_var = tk.IntVar(value=args.window)
    ttk.Spinbox(bar, from_=40, to=16000, increment=40, textvariable=win_var,
                width=7).pack(side=tk.LEFT)

    ttk.Label(bar, text="调制频率(Hz):").pack(side=tk.LEFT, padx=(10, 2))
    fsig_var = tk.DoubleVar(value=args.fsig)
    ttk.Entry(bar, textvariable=fsig_var, width=9).pack(side=tk.LEFT)

    fault_var = tk.BooleanVar(value=False)
    ttk.Checkbutton(bar, text="注入故障(演示丢帧检查)",
                    variable=fault_var).pack(side=tk.LEFT, padx=(10, 4))

    btn_var = tk.StringVar(value="开始")

    # ---------------- 图形区 ----------------
    # ★ 布局顺序很重要: status 必须【先】pack 在底部, 再 pack 会 expand 的画布。
    #   反过来的话 (先 pack expand 的画布) 状态栏会被挤出可视区 —— 这是 Tkinter 的经典坑。
    status = ttk.Label(root, text="就绪", anchor="w", padding=6,
                       relief=tk.SUNKEN, font=("Consolas", 9))
    status.pack(side=tk.BOTTOM, fill=tk.X)

    # ★ 画布尺寸要跟随控件的实际像素大小, 不能写死 figsize:
    #   显示器若开了 DPI 缩放 (常见 125%/150%), Tk 的像素会被放大渲染,
    #   写死 11.5x5 英寸 (1150x500 px) 实际会占 1700+ px, 把频谱图和状态栏挤出窗口。
    # ★ figure 初始像素尺寸 = figsize x dpi(100)。图不能比窗口大:
    #   画布控件不会自动缩到比 figure 更小, 窗口小于 figure 时会被裁掉
    #   (现象: 只看到上面那张时域图, 频谱图和最下面的状态栏都不见了)。
    #   这里取 660x360, 小窗口也放得下; 窗口拉大后 matplotlib 会自己跟着放大。
    fig, ax = plt.subplots(2, 1, figsize=(6.6, 3.6), height_ratios=[2, 1])
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    # ---------------- 起停 ----------------
    def stop() -> None:
        state["running"] = False
        if state["pipe"] is not None:
            state["pipe"].close()      # 收尾: 把没写完的 CSV 刷出去
        if state["src"] is not None:
            state["src"].close()
            state["src"] = None
        btn_var.set("开始")

    def start() -> None:
        stop()
        try:
            if src_var.get() == "serial" and port_names[0].startswith("("):
                raise RuntimeError("没有检测到可用串口。若要用假数据请选【假数据】。")
            # 界面和无界面走同一个构造逻辑, 避免两边行为不一致
            a = argparse.Namespace(
                source=src_var.get(), port=port_var.get(), file=args.file,
                fsig=fsig_var.get(), noise=args.noise, fsout=args.fsout,
                faults=bool(fault_var.get()))
            src = make_source(a)
        except Exception as e:
            status.config(text=f"打不开数据源: {e}")
            return
        state["src"] = src
        state["pipe"] = Pipeline(src, f_sig=fsig_var.get(), fs_out=args.fsout,
                                 log_path=args.log)
        state["running"] = True
        state["t_last"] = time.perf_counter()
        state["fps"] = 0.0
        btn_var.set("停止")
        status.config(text=f"数据源: {src.name}")

    def toggle() -> None:
        start() if not state["running"] else stop()

    ttk.Button(bar, textvariable=btn_var, command=toggle, width=8).pack(
        side=tk.LEFT, padx=(4, 0))

    if args.autostart:
        root.after(200, start)

    # ---------------- 刷新循环 ----------------
    def tick() -> None:
        pipe = state["pipe"]
        if state["running"] and pipe is not None:
            try:
                pipe.poll()
            except Exception as e:
                status.config(text=f"读取失败: {e}")
                stop()
            else:
                now = time.perf_counter()
                if now - state["t_last"] >= REDRAW_MS / 1000.0:
                    state["fps"] = 1.0 / max(now - state["t_last"], 1e-6)
                    state["t_last"] = now
                    redraw(pipe)
                    pipe.flush_log()
        root.after(20, tick)

    def redraw(pipe: Pipeline) -> None:
        raw = np.fromiter(pipe.raw, dtype=np.int64, count=len(pipe.raw))
        flt = np.fromiter(pipe.filt, dtype=np.int64, count=len(pipe.filt))
        n = min(len(raw), len(flt))
        win = max(40, min(int(win_var.get()), max(n, 40)))
        r_snr, f_snr = pipe.snr_pair()
        # 自动检测到调制频率后回填到输入框, 免得界面一直显示 0
        if pipe._fsig_auto is not None and fsig_var.get() == 0:
            fsig_var.set(round(pipe._fsig_auto, 2))

        ax[0].clear()
        if n >= 2:
            raw, flt = raw[-n:], flt[-n:]
            w = min(win, n)
            t = np.arange(w) / pipe.fs_out * 1000.0
            ax[0].plot(t, raw[-w:], color="0.65", lw=0.8, label="原始 (带噪)")
            ax[0].plot(t, flt[-w:], color="crimson", lw=1.2, label="滤波后")
            ax[0].legend(fontsize=8, loc="upper right")
        ax[0].set_xlabel("时间 (ms)")
        ax[0].set_ylabel("幅度 (LSB)")
        ax[0].grid(alpha=0.3)
        title = (f"时域: 原始 vs 滤波后  |  {pipe.src.name}  |  "
                 f"fs={pipe.fs_out:.0f} S/s")
        if r_snr is not None and f_snr is not None:
            title += f"\nSNR {r_snr:.2f} → {f_snr:.2f} dB (提升 {f_snr - r_snr:+.2f} dB)"
        ax[0].set_title(title, fontsize=9.5)

        ax[1].clear()
        if n >= 1024:
            fr, pr = welch_psd(raw, pipe.fs_out)
            _, pf = welch_psd(flt, pipe.fs_out)
            ax[1].plot(fr / 1000.0, 10 * np.log10(pr), color="0.65", lw=0.9, label="原始")
            ax[1].plot(fr / 1000.0, 10 * np.log10(pf), color="crimson", lw=1.0,
                       label="滤波后")
            ax[1].legend(fontsize=8, loc="upper right")
        ax[1].set_xlabel("频率 (kHz)")
        ax[1].set_ylabel("PSD (dB/Hz)")
        ax[1].set_xlim(0, pipe.fs_out / 2000.0)
        ax[1].grid(alpha=0.3)
        ax[1].set_title("功率谱 (不依赖干净参考的客观证据)", fontsize=10)

        canvas.draw_idle()
        sv = rate_verdict(*pipe.rate_check()[:2],
                          pipe.last_deficit)
        t_snr = ""
        rs, fs_ = pipe.snr_pair()
        if rs is not None:
            t_snr = f"  |  {rs:.2f} → {fs_:.2f} dB  (提升 {fs_ - rs:+.2f})"
        status.config(text=f"{pipe.status_text()}  |  {sv}  |  刷新 {state['fps']:.1f} FPS"
                           f"  |  {t_snr}")

    root.after(50, tick)
    root.protocol("WM_DELETE_WINDOW", lambda: (stop(), root.destroy()))
    root.mainloop()


def parse_args():
    p = argparse.ArgumentParser(description="微弱光电信号降噪 上位机")
    p.add_argument("--source", choices=["fake", "serial", "file"], default="fake",
                   help="fake=假数据源 / serial=真实串口 / file=回放真实抓包")
    p.add_argument("--port", default=None, help="串口号, 如 COM10")
    p.add_argument("--file", default=None, help="回放的抓包 .bin (配合 --source file)")
    p.add_argument("--once", action="store_true",
                   help="回放只跑一遍不循环 (出报告图用, 避免绕回时出现截断帧)")
    p.add_argument("--fsig", type=float, default=0.0,
                   help="调制频率 Hz; 0=自动检测 (接真机时用这个)")
    p.add_argument("--fsout", type=float, default=FS_OUT_CONFIRMED,
                   help=f"显示采样率 Hz (实测确认值; 默认 {FS_OUT_CONFIRMED:.0f})")
    p.add_argument("--log", default=None,
                   help="把收到的原始/滤波后数据存成 CSV (列: seq,raw,filt)")
    p.add_argument("--noise", type=int, default=40, help="假数据噪声幅度 LSB (扫不同信噪比)")
    p.add_argument("--window", type=int, default=DEFAULT_WINDOW, help="时域显示点数")
    p.add_argument("--headless", type=float, default=None, help="无界面跑 N 秒")
    p.add_argument("--png", default=None, help="headless 出图路径")
    p.add_argument("--faults", action="store_true", help="注入故障演示丢帧检查")
    p.add_argument("--autostart", action="store_true", help="界面启动后自动开始采集")
    return p.parse_args()


if __name__ == "__main__":
    a = parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    if a.headless:
        run_headless(a)
    else:
        run_gui(a)

# -*- coding: utf-8 -*-
r"""
================================================================================
 报告用图: 从真实抓包出图 (给 C 写报告用)
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc\gui
    py report_figures.py                        # 默认读 tools\ 下的三份抓包
    py report_figures.py a.bin b.bin ...        # 也可指定

产出: out\report_real_data.png  (四联图)
  ① 暗场时域: RAW vs FILT (20 ms)        —— 噪声压低肉眼可见
  ② 亮场时域: RAW vs FILT (20 ms)        —— 信号大时的对比
  ③ 暗场功率谱: RAW vs FILT              —— 高频噪声被砍掉的证据
  ④ 噪声能量频段分布                     —— 解释为什么是 8.13 dB 而不是理论的 11.94 dB

★ 图里所有数字都是脚本算的, 不写死。
================================================================================
"""

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from data_sources import FS_OUT_CONFIRMED as FS, q15_coeffs  # noqa: E402
from frame_proto import FrameParser, PairAssembler, parse_samples  # noqa: E402
from scipy.signal import welch  # noqa: E402

LSB_UV = 152.58
OUT = HERE / "out"


def load(path: Path):
    raw, filt = [], []

    def onp(r, f, s):
        raw.extend(parse_samples(r))
        filt.extend(parse_samples(f))

    asm = PairAssembler(on_pair=onp)
    fp = FrameParser(on_frame=asm.feed)
    fp.feed(path.read_bytes())
    return np.array(raw, float), np.array(filt, float), fp.stats, asm.stats


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    args = sys.argv[1:]
    if args:
        paths = [Path(a) for a in args]
    else:
        t = HERE.parent.parent / "tools"
        paths = [t / "cap_135142.bin", t / "cap_135336.bin", t / "cap_201917.bin"]
        paths = [p for p in paths if p.exists()]
    if not paths:
        print("找不到抓包文件")
        raise SystemExit(1)

    data = []
    for p in paths:
        raw, filt, ps, qs = load(p)
        n = min(len(raw), len(filt))
        data.append(dict(name=p.stem, raw=raw[:n], filt=filt[:n],
                         frames=ps.frames_ok, ck=ps.checksum_errors, pairs=qs.pairs_ok))
        print(f"  {p.name}: 好帧 {ps.frames_ok}, 校验错 {ps.checksum_errors}, 配对 {qs.pairs_ok}")

    dark = data[0]                    # 第一份按 A 的说明是遮光
    bright = data[1] if len(data) > 1 else data[0]

    OUT.mkdir(exist_ok=True)
    fig, ax = plt.subplots(2, 2, figsize=(13, 8))

    # ---- ①② 时域 ----
    def ts(a, d, title):
        raw, filt = d["raw"], d["filt"]
        m = min(int(0.020 * FS), len(raw))
        t = np.arange(m) / FS * 1000.0
        a.plot(t, raw[:m], color="0.65", lw=0.8, label="原始 RAW")
        a.plot(t, filt[:m], color="crimson", lw=1.2, label="滤波后 FILT")
        ra = np.sqrt(np.mean((raw - raw.mean()) ** 2))
        fa = np.sqrt(np.mean((filt - filt.mean()) ** 2))
        a.set_title(f"{title}\n交流 rms: RAW {ra:.2f} → FILT {fa:.2f} LSB  "
                    f"({20 * np.log10(fa / ra):+.2f} dB)", fontsize=10)
        a.set_xlabel("时间 (ms)")
        a.set_ylabel("幅度 (LSB)")
        a.grid(alpha=0.3)
        a.legend(fontsize=8, loc="upper right")

    ts(ax[0][0], dark, "① 暗场(遮光) 20 ms")
    ts(ax[0][1], bright, "② 强光(手电筒) 20 ms")

    # ---- ③ 功率谱 ----
    a = ax[1][0]
    for key, lab, col in (("raw", "RAW", "0.6"), ("filt", "FILT", "crimson")):
        f, P = welch(dark[key] - dark[key].mean(), fs=FS, nperseg=1024)
        a.semilogy(f / 1000.0, P, color=col, lw=1.0, label=lab)
    a.set_title("③ 暗场功率谱：FILT 在高频被压低", fontsize=10)
    a.set_xlabel("频率 (kHz)")
    a.set_ylabel("PSD (LSB²/Hz)")
    a.grid(alpha=0.3, which="both")
    a.legend(fontsize=8, loc="upper right")

    # ---- ④ 噪声频段分布 ----
    a = ax[1][1]
    bands = [(0, 500), (500, 1000), (1000, 2000), (2000, 3500), (3500, 4500), (4500, 6340)]
    f, P = welch(dark["raw"] - dark["raw"].mean(), fs=FS, nperseg=1024)
    df = f[1] - f[0]
    tot = float(np.sum(P) * df)
    pct = []
    for lo, hi in bands:
        m = (f >= lo) & (f < hi)
        pct.append(float(np.sum(P[m]) * df) / tot * 100)
    labels = [f"{lo//1000 if lo>=1000 else lo}\n–{hi/1000:.1f}k" if hi >= 1000
              else f"{lo}–{hi}" for lo, hi in bands]
    labels = [f"{lo}–{hi}" if hi <= 1000 else f"{lo/1000:.1f}k–{hi/1000:.1f}k"
              for lo, hi in bands]
    bars = a.bar(range(len(bands)), pct, color="steelblue")
    a.set_xticks(range(len(bands)))
    a.set_xticklabels(labels, fontsize=8)
    a.set_ylabel("占噪声总能量 (%)")
    sumb2 = float(np.sum((q15_coeffs() / 32768.0) ** 2))
    a.set_title(f"④ 暗场噪声能量分布 (Hz)\n"
                f"白噪声理论压低 {-10 * np.log10(sumb2):.2f} dB，"
                f"实测 {20 * np.log10(np.sqrt(np.mean((dark['filt'] - dark['filt'].mean()) ** 2)) / np.sqrt(np.mean((dark['raw'] - dark['raw'].mean()) ** 2))):.2f} dB",
                fontsize=10)
    for b, v in zip(bars, pct):
        a.text(b.get_x() + b.get_width() / 2, v + 1, f"{v:.1f}", ha="center", fontsize=7)
    a.grid(alpha=0.3, axis="y")

    fig.suptitle(f"真实硬件抓包验收 (采样率 {FS:.0f} S/s, 135 字节帧, "
                 f"校验错 0, 重复帧 0)", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    png = OUT / "report_real_data.png"
    fig.savefig(png, dpi=130)
    plt.close(fig)
    print(f"\n  已出图: {png}")


if __name__ == "__main__":
    main()

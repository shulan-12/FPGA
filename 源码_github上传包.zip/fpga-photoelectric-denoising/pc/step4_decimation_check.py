# -*- coding: utf-8 -*-
r"""
================================================================================
 第4步 / 电脑端 : 回答 A 的两个问题 (921600 行不行 / 8点每周期够不够看)
================================================================================
跑法:
    cd D:\deepseek\CODE\fpga_denoise\pc
    py step4_decimation_check.py

产出:
    out/step4_decimation.png   不同抽点倍率下, 上位机屏幕上实际长什么样
    (控制台打印波特率分频误差 + 数据率预算)

两个问题分开回答:
  Q1 "921600 行不行"  -> 算术问题, 本脚本把分频误差和余量算清楚
  Q2 "8 点/周期够不够看" -> 眼睛问题, 只算数没用, 把图画出来看
================================================================================
"""

import sys
from pathlib import Path

import numpy as np
from scipy.signal import firwin, lfilter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from step1_gen_and_filter import FS, make_clean, make_noise  # noqa: E402

OUT = Path(__file__).resolve().parent / "out"

# ---- A 的新参数 ----
BAUD = 921600
CLK_FREQ = 50_000_000
FRAME_POINTS = 64                 # 每帧 64 点
FRAME_BYTES = 4 + FRAME_POINTS * 2 + 1   # 0xAA 0x55 type len + 数据 + 累加和 = 133
DATA_BYTES_PER_POINT = 2 * FRAME_BYTES / FRAME_POINTS   # 双路(原始+滤波)摊到每个时间点

# ---- 滤波器 (和第1步/第4步一致) ----
NUMTAPS, CUTOFF_HZ = 129, 3500.0
GROUP_DELAY = (NUMTAPS - 1) // 2          # 64

DECIM = [8, 6, 4]                          # 抽点倍率
FREQS = [(1562.5, "A 验证台的测试频率 1562.5 Hz"),
         (1000.0, "第3步计划里的真实调制频率 1 kHz")]

N_SAMP = 40_000
SEED = 0xDEADBEEF


def baud_error(baud: int, clk: int = CLK_FREQ) -> tuple:
    """算 FPGA 侧分频的实际波特率和误差。DIV 是整数除法, 所以一定有误差。"""
    div = clk // baud
    actual = clk / div
    return div, actual, (actual - baud) / baud * 100.0


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    OUT.mkdir(parents=True, exist_ok=True)
    L = []

    def say(s: str = "") -> None:
        print(s)
        L.append(s)

    # ==========================================================================
    # Q1: 波特率
    # ==========================================================================
    say("=" * 78)
    say(" Q1: 921600 行不行?")
    say("=" * 78)
    say(f"  uart_tx.v 里 DIV = CLK_FREQ / BAUD = {CLK_FREQ} / {BAUD} "
        f"(整数除法, 一定除不尽)")
    say("")
    say(f"  {'波特率':>10} {'DIV':>5} {'实际波特率':>12} {'误差':>9} {'第10位采样偏移':>14}")
    for b in (115200, 460800, 921600):
        div, act, err = baud_error(b)
        # 接收方在每 bit 中间采样: 第10位(停止位)采样点在 9.5 个 bit 时间处。
        # 发送方每个 bit 短了 err, 累积到 9.5 位就是 9.5*err 个 bit 的偏移。
        shift = 9.5 * abs(err) / 100.0 * 100          # 占一个 bit 的百分比
        say(f"  {b:>10} {div:>5} {act:>12.1f} {err:>+8.3f}% {shift:>13.1f}%")
    say("")
    say("  判据: 接收方在每 bit 中间采样, 一帧 10 bit, 到停止位时采样点总共偏移")
    say("        9.5 个 bit 宽度的误差。UART 的通用容限是 ±2~3%(两端合计)。")
    div, act, err = baud_error(BAUD)
    shift = 9.5 * abs(err) / 100.0 * 100
    say(f"  => 921600 时偏移只有 {shift:.1f}% 个 bit, 离 50%(采样跑到相邻 bit)差得远,")
    say(f"     FPGA 侧【够安全】。剩下的不确定项是 CP2102 自己的波特率精度(手册说")
    say(f"     标准波特率误差很小, 但我们必须上板实测一次, 见下面的回环测试)。")
    say("")
    say("  ★ 上板验证方法(30 秒): 发固定图案 0x55 0xAA 0x00 0xFF + 0..255 计数序列,")
    say("    上位机逐个字节比对。全对 = 921600 可用; 出现错字节 = 退回 460800。")

    # ==========================================================================
    # 数据率预算
    # ==========================================================================
    say("")
    say("-" * 78)
    say(" 数据率预算 (A 的报文: 每帧 64 点, 帧长 133 字节, 原始/滤波成对出现)")
    say("-" * 78)
    say(f"  单帧 = 4(帧头/类型/长度) + {FRAME_POINTS}*2(数据) + 1(累加和) = {FRAME_BYTES} 字节")
    say(f"  一对帧(0x01+0x02) = {2 * FRAME_BYTES} 字节, 覆盖 {FRAME_POINTS} 个时间点")
    say(f"  -> 每个时间点消耗 {DATA_BYTES_PER_POINT:.3f} 字节 "
        f"(4 字节数据 + {DATA_BYTES_PER_POINT - 4:.3f} 字节开销)")
    say("")
    cap = BAUD / 10.0                     # 8N1: 10 bit/字节
    say(f"  {BAUD} 波特 8N1 -> 上限 {cap:.0f} 字节/秒")
    say("")
    say(f"  {'抽点':>5} {'采样率':>10} {'需字节/秒':>11} {'带宽占用':>9} "
        f"{'1562.5Hz':>10} {'1kHz':>8}")
    for d in DECIM:
        rate = FS / d
        need = rate * DATA_BYTES_PER_POINT
        util = need / cap * 100
        say(f"  ÷{d:<4} {rate:>9.0f} {need:>11.0f} {util:>8.1f}% "
            f"{FS / d / 1562.5:>9.1f}点 {FS / d / 1000.0:>6.1f}点")
    say("")
    say("  A 选的 ÷8 = 12.5 kSPS, 占用 56% -> 有余量 ✓")
    say("  ÷6 = 16.7 kSPS, 占用 75% -> 仍然放得下, 但余量收窄到 1/4")
    say("  ÷4 = 25 kSPS(112%) -> ★ 放不下, 别选")

    # ==========================================================================
    # Q2: 画图出来看 (这个只能看, 不能算)
    # ==========================================================================
    say("")
    say("=" * 78)
    say(" Q2: 8 点/周期够不够看? —— 画出来看")
    say("=" * 78)

    b = firwin(NUMTAPS, CUTOFF_HZ, fs=FS, window="hamming")
    fig_rows = []
    for f_sig, label in FREQS:
        period = int(round(FS / f_sig))
        clean = make_clean(period, 3000, N_SAMP)
        noise = make_noise(40, N_SAMP, SEED)
        code = clean + noise
        y = lfilter(b, [1.0], code.astype(np.float64))
        # 群延迟对齐: 滤波后左移 64 个样本
        y_al = np.full(N_SAMP, np.nan)
        y_al[:N_SAMP - GROUP_DELAY] = y[GROUP_DELAY:]
        fig_rows.append((f_sig, label, code, y_al, period))

    # ---- 画图 ----
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    nshow_periods = 3
    fig, ax = plt.subplots(len(FREQS), len(DECIM),
                           figsize=(5.0 * len(DECIM), 7.0), squeeze=False)
    fig.suptitle("抽点后上位机屏幕上实际长什么样  |  原始(灰) vs 滤波后(红), 各 3 个信号周期\n"
                 "滤波器仍在 100 kHz 上工作, 只是曲线被抽点显示", fontsize=13)

    for r, (f_sig, label, code, y_al, period) in enumerate(fig_rows):
        for c, d in enumerate(DECIM):
            rate = FS / d
            npts = int(nshow_periods * period / d)      # 3 个周期内有几个抽点
            idx = np.arange(0, npts * d, d)
            t = idx / FS * 1000.0
            a = ax[r][c]
            a.plot(t, code[idx], color="0.65", lw=0.7, marker="o", ms=2.2,
                   label="原始(带噪)")
            a.plot(t, y_al[idx], color="crimson", lw=1.2, marker="o", ms=2.2,
                   label="FIR 滤波后")
            a.set_title(f"÷{d}  ->  {rate / 1000:.2f} kSPS\n"
                        f"{rate / f_sig:.1f} 点/周期 ({npts} 点/3周期)", fontsize=10)
            a.set_xlabel("时间 (ms)")
            a.set_ylabel("幅度 (LSB)")
            a.grid(alpha=0.3)
            if r == 0 and c == 0:
                a.legend(fontsize=8, loc="upper right")
            if c == 0:
                a.text(0.02, 0.04, label, transform=a.transAxes, fontsize=8,
                       color="steelblue")

    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(OUT / "step4_decimation.png", dpi=125)
    plt.close(fig)
    say(f"  已输出 {OUT / 'step4_decimation.png'}")

    # ==========================================================================
    # ★ 顺带发现的更重要的事: 演示效果的决定因素是【噪声有多大】, 不是抽点倍率
    # ==========================================================================
    say("")
    say("-" * 78)
    say(" ★ 顺带: 决定演示效果的不是抽点倍率, 是噪声相对信号有多大")
    say("-" * 78)
    say("  上面那张图里, 灰色原始曲线被红线的噪声毛刺遮不太住 —— 因为验证台默认")
    say("  噪声幅度 40 LSB, 相对 3000 LSB 的信号只有 0.77%。这种情况下无论抽点 ÷8")
    say("  还是 ÷4, 原始曲线看起来都【几乎和干净的一样】, 评委看不出降噪效果。")
    say("")
    say(f"  {'噪声幅度':>9} {'噪声RMS':>9} {'占信号幅度':>11} {'SNR_in':>9} {'演示效果':>10}")
    rows = []
    for nz_amp in (40, 400, 1200):
        nz = make_noise(nz_amp, N_SAMP, SEED)
        rms_n = float(np.sqrt(np.mean(nz.astype(np.float64) ** 2)))
        rms_s = float(np.sqrt(np.mean(make_clean(64, 3000, N_SAMP).astype(np.float64) ** 2)))
        snr = 20 * np.log10(rms_s / rms_n)
        verdict = "★看不出" if snr > 30 else ("★能看出" if snr > 12 else "★很明显")
        say(f"  {nz_amp:>9} {rms_n:>8.1f} {rms_n / 3000 * 100:>10.2f}% "
            f"{snr:>8.2f}dB {verdict:>10}")
        rows.append((nz_amp, nz, snr))

    fig2, ax2 = plt.subplots(1, 2, figsize=(12, 4.2))
    for a, (nz_amp, nz, snr) in zip(ax2, (rows[0], rows[2])):
        clean = make_clean(64, 3000, N_SAMP)
        code = clean + nz
        y = lfilter(b, [1.0], code.astype(np.float64))
        y_al = np.full(N_SAMP, np.nan)
        y_al[:N_SAMP - GROUP_DELAY] = y[GROUP_DELAY:]
        d = 8
        npts = int(3 * 64 / d)
        idx = np.arange(0, npts * d, d)
        t = idx / FS * 1000.0
        a.plot(t, code[idx], color="0.6", lw=0.8, marker="o", ms=2.2, label="原始(带噪)")
        a.plot(t, y_al[idx], color="crimson", lw=1.3, marker="o", ms=2.2, label="FIR 滤波后")
        a.set_title(f"噪声幅度 {nz_amp} LSB (RMS {np.sqrt(np.mean(nz**2)):.0f} LSB, "
                    f"SNR_in {snr:.1f} dB)\n÷8 = 12.5 kSPS, 8 点/周期", fontsize=10)
        a.set_xlabel("时间 (ms)")
        a.set_ylabel("幅度 (LSB)")
        a.grid(alpha=0.3)
        a.legend(fontsize=8, loc="upper right")
    fig2.suptitle("同样 ÷8 抽点, 只改噪声大小: 演示效果差多少", fontsize=13)
    fig2.tight_layout(rect=(0, 0, 1, 0.90))
    fig2.savefig(OUT / "step4_demo_visible.png", dpi=125)
    plt.close(fig2)
    say("")
    say(f"  已输出 {OUT / 'step4_demo_visible.png'} (左: 验证台默认噪声, 右: 真实微弱信号)")
    say("")
    say("  => 给 A 的结论: 抽点 ÷8 和 ÷6 的差别是次要的;")
    say("     【真正决定演示效果的是板卡上采到的噪声相对信号有多大】。")
    say("     按第3步的表2调 LED 距离/增益时, 要保证原始曲线上的噪声【肉眼可见】,")
    say("     否则降噪效果在屏幕上看不出来, 给评委看的图就没说服力。")

    (OUT / "step4_report.txt").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

# 基于 FPGA 的微弱光电信号实时降噪系统

> 2026 全国大学生嵌入式芯片与系统设计竞赛 · FPGA 创新设计赛道（AMD 平台）
> 目标器件：Xilinx Artix-7 **XC7A35T-2FGG484I**（ALINX AX7035B）

在 FPGA 上实现一条从光电探测到上位机显示的完整实时降噪链路：
**OPT101 → AD7606（16 bit / 100 kSPS）→ FPGA 内 129 抽头 FIR → UART 921600 → 上位机实时叠图**。

---

## 系统框图

![系统框图](figures/system_block.png)

两级降噪：

| 级 | 位置 | 作用 |
|---|---|---|
| 第一级 | AD7606 内置模拟抗混叠 | 3 dB 截止 22 kHz，拦住带外能量 |
| 第二级 | FPGA 内 129 抽头线性相位 FIR | 截止 3.5 kHz（Q1.15 定点），压带内高端噪声 |

---

## 关键设计

**FIR 的可行实现**：线性相位 FIR 系数对称（`b[k] = b[N-1-k]`），把对称的两个抽头一次算两个，
配合时分复用，129 抽头每样本只需 **65 次乘累加**，整机仅占 **2 个 DSP48E1**（器件共 90 个）。
全并行结构需要 65 个 DSP，在这颗器件上不可行 —— 这是本设计的核心取舍。

![RTL 数据通路](figures/rtl_datapath.png)

**采集时序自适应**：控制器不数固定的转换时间，而是等 `BUSY` 下降沿，并设超时保护。
换 AD7606 型号或改过采样设置，都不需要改代码。

**成对帧 + 序号**：原始与滤波两路共用帧序号 SEQ 上传，使"降噪是否保住信号"
可以直接叠图判读，传输丢帧也因此成为可计量的指标。

---

## 实测结果

| 指标 | 实测值 |
|---|---|
| 采集速率 | **100 kSPS**（CONV_DIV = 500，整除） |
| 每路上传速率 | **12.50 kSPS**（滤波后 ÷8） |
| 帧格式 | 135 字节：`AA55` + 类型 + `LEN=128` + `SEQ`(2B) + 64×int16 + 校验和 |
| 校验和通过率 | **100%**（1188 帧连续），**丢帧 0、重复帧 0** |
| 前端暗电平 | **7.62 mV**（TI 手册典型 7.5 mV，误差 <2%） |
| 前端受照输出 | 2.297 V，动态范围 **301 倍** |
| 噪声压制（暗场） | **−8.13 dB**（rms 3.462 → 1.358 LSB） |
| 信噪比增益（1 kHz 调制） | **+0.49 dB**（含谐波）/ **+2.81 dB**（纯随机噪声） |
| 资源占用 | LUT **1844**（8.87%）/ FF **2638**（6.34%）/ DSP **2**/90 |
| 时序 | WNS **+5.194 ns** / WHS **+0.047 ns**（保持裕量偏紧，47 ps） |
| 实现正确性 | RTL 与电脑端定点模型 **360/360 样本逐位一致**，最大偏差 **0 LSB** |

![降噪实测对比](figures/denoise_result.png)

降噪效果与噪声谱型一致：暗场工况 79% 的噪声能量位于 3.5 kHz 以上，压低 **8.13 dB**；
调制工况 78% 位于通带内，低通可削减的余量有限，随机噪声压制 **2.81 dB**。
**同一个滤波器、两种噪声谱型、两个结果** —— 限制来自工况而非实现。

---

## 目录

```
rtl/                Verilog 源码（写入开发板）
  ad7606_if.v         AD7606 采集接口状态机（等 BUSY 下降沿 + 超时保护）
  denoise_filter.v    129 抽头线性相位 FIR（Hamming 窗，Q1.15，对称 + 时分复用）
  capture_buf.v       乒乓双缓冲 + ÷8 抽点
  frame_tx.v          135 字节定长帧发送
  mod_gen.v           100 kHz PWM + 1 kHz 正弦包络调制发生器
  uart_tx.v           UART 发送（921600 8N1）
  top_adc_stream.v    最终顶层
constrs/            XDC 引脚与时序约束
sim/                构建 TCL / 自检 testbench / 行为模型 / 比特流
pc/                 上位机与算法
  step1~step5_*.py    含噪生成、定点化、冲激比对、抽点核算、系数核对
  gui/dashboard.py    实时显示界面（假数据 / 串口 / 抓包回放）
  gui/final_numbers.py  报告全部数字的一键复现
figures/            README 与报告用图
```

---

## 复现

**FPGA**

```bash
cd sim
vivado -mode batch -source build_adc_stream.tcl
```

也可直接烧录 `sim/ax7035_adc_stream.bit`（MD5 `143D9312B2354B9E92AF32FD162152F1`）。

**仿真**

```bash
cd sim
vivado -mode batch -source run_msim.tcl
```

**上位机**

```bash
cd pc
pip install numpy scipy matplotlib pyserial
python final_numbers.py                        # 复现报告全部数字
python gui/dashboard.py                        # 启动界面
python gui/dashboard.py --source serial --port COM10   # 接真实板卡
```

---

## 硬件注意事项

1. AD7606 模块的 **J1 跳线必须置 3.3 V 侧**，否则 5 V 输出可能损伤 FPGA 的 BANK。
2. AD7606 的 **J2 跳线选模拟量程**（接 AGND 侧为 ±5 V，1 LSB = 152.58 µV）。
3. **OPT101 模块的 `-V`（第 3 脚）出厂未接地**，必须外部补线到 GND；
   `1M`（第 4 脚）需短接到 `OUT`。两者漏接都会导致输出卡在 4.6 V、完全不响应光照。

---

## 许可

MIT License，见 [LICENSE](LICENSE)

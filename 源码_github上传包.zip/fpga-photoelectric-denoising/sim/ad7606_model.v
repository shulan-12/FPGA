//=============================================================================
// ad7606_model.v  --  AD7606 行为级模型 (只用于仿真, 综合不了也不该综合)
//-----------------------------------------------------------------------------
// 它干什么:
//   在没有实物模块的情况下, 冒充一颗 AD7606, 按芯片手册的时序规律响应 FPGA:
//     1) 看到 CONVST 上升沿 -> 把 8 个模拟输入"采样"进来, BUSY 拉高
//     2) 过 TCONV 时间          -> BUSY 拉低 (表示数据就绪)
//     3) CS 低时每个 RD 下降沿  -> 往 DB[15:0] 上送出下一个通道的数据
//     4) FRSTDATA 在送第一个通道时为高
//     5) 不读的时候 DB 呈高阻 (z), 和真实芯片一样
//
// 时序依据: AD7606 数据手册 (Analog Devices Rev.0) 并行读时序图
//   本项目只依赖"BUSY 拉低后数据有效"这一条, 所以 TCONV 参数即使和实物有偏差,
//   也不会让 ad7606_if.v 的验证失真 —— 它等的是 BUSY, 不是等固定时间。
//
// ch_flat 输出是为了让 testbench 能拿到"芯片内部到底存了什么真值"做逐通道比对。
// 排布: {ch7, ch6, ..., ch0}, 即 ch_flat[n*16 +: 16] 就是通道 n。
//=============================================================================
`timescale 1ns / 1ps

module ad7606_model #(
    parameter integer TCONV_NS       = 4000,   // 转换时间, AD7606(8通道)典型 4us
    parameter integer BUSY_DELAY_NS  = 40,     // CONVST 之后 BUSY 拉高的延迟
    parameter integer CLK_PERIOD_NS  = 20      // 仿真时钟周期, 用于换算成时钟数
)(
    input  wire        clk,
    input  wire        convst,
    input  wire        cs_n,
    input  wire        rd_n,
    input  wire        ad_reset,

    // 8 路"模拟输入"(这里用已经量化好的 16bit 补码表示, 由 testbench 产生)
    input  wire signed [15:0] vin0,
    input  wire signed [15:0] vin1,
    input  wire signed [15:0] vin2,
    input  wire signed [15:0] vin3,
    input  wire signed [15:0] vin4,
    input  wire signed [15:0] vin5,
    input  wire signed [15:0] vin6,
    input  wire signed [15:0] vin7,

    output wire [15:0] db,        // 数据总线 (不读时高阻)
    output reg         busy,      // 转换中
    output reg         frstdata,  // 首通道标志

    output wire [127:0] ch_flat   // 芯片内部锁存的 8 通道真值 (给 TB 比对)
);

    localparam integer TCONV_CYC      = (TCONV_NS      + CLK_PERIOD_NS - 1) / CLK_PERIOD_NS;
    localparam integer BUSY_DLY_CYC   = (BUSY_DELAY_NS + CLK_PERIOD_NS - 1) / CLK_PERIOD_NS;

    reg signed [15:0] ch [0:7];
    reg [15:0] db_reg;
    reg        db_oe;
    reg [2:0]  rd_idx;
    reg [15:0] conv_cnt;
    reg [15:0] busy_dly;
    reg        convst_d;

    // ★ 必须有确定初值: 否则上电时 busy/busy_dly 是 X, 会把所有 if 分支全变成
    //   未知态而永不执行 —— 这正是第一版仿真卡死的原因。真实芯片有上电复位,
    //   模型也必须显式模拟这一点。
    initial begin
        db_reg   = 16'd0;
        db_oe    = 1'b0;
        rd_idx   = 3'd0;
        conv_cnt = 16'd0;
        busy_dly = 16'd0;
        convst_d = 1'b0;
        busy     = 1'b0;
        frstdata = 1'b0;
        ch[0]=16'sd0; ch[1]=16'sd0; ch[2]=16'sd0; ch[3]=16'sd0;
        ch[4]=16'sd0; ch[5]=16'sd0; ch[6]=16'sd0; ch[7]=16'sd0;
    end

    assign db      = db_oe ? db_reg : 16'hzzzz;
    assign ch_flat = {ch[7], ch[6], ch[5], ch[4], ch[3], ch[2], ch[1], ch[0]};

    wire convst_rise = convst & ~convst_d;

    reg rd_n_d;
    wire rd_fall = ~rd_n & rd_n_d;

    //-------------------------------------------------------------------------
    // 转换控制: CONVST 上升沿 -> BUSY 高 -> TCONV 后 BUSY 低
    //-------------------------------------------------------------------------
    always @(posedge clk) begin
        convst_d <= convst;
        rd_n_d   <= rd_n;

        if (ad_reset) begin
            busy      <= 1'b0;
            busy_dly  <= 16'd0;
            conv_cnt  <= 16'd0;
            rd_idx    <= 3'd0;
            db_reg    <= 16'd0;
            db_oe     <= 1'b0;
            frstdata  <= 1'b0;
            ch[0] <= 16'sd0; ch[1] <= 16'sd0; ch[2] <= 16'sd0; ch[3] <= 16'sd0;
            ch[4] <= 16'sd0; ch[5] <= 16'sd0; ch[6] <= 16'sd0; ch[7] <= 16'sd0;
        end
        else if (convst_rise && !busy) begin
            // 采样: 把当前 8 路输入锁进芯片内部
            ch[0] <= vin0; ch[1] <= vin1; ch[2] <= vin2; ch[3] <= vin3;
            ch[4] <= vin4; ch[5] <= vin5; ch[6] <= vin6; ch[7] <= vin7;
            busy_dly <= BUSY_DLY_CYC;
            busy     <= 1'b0;                 // 等 BUSY_DLY 之后再拉高
        end
        else if (busy_dly != 16'd0) begin
            busy_dly <= busy_dly - 16'd1;
            if (busy_dly == 16'd1) begin
                busy     <= 1'b1;
                conv_cnt <= TCONV_CYC;
            end
        end
        else if (busy) begin
            if (conv_cnt == 16'd0) begin
                busy <= 1'b0;                 // 转换完成, 数据就绪
            end
            else begin
                conv_cnt <= conv_cnt - 16'd1;
            end
        end

        //---------------------------------------------------------------------
        // 读控制: CS 低时每个 RD 下降沿送出下一个通道
        //---------------------------------------------------------------------
        if (ad_reset) begin
            // 已在上面清掉
        end
        else if (!cs_n && rd_fall) begin
            db_reg   <= ch[rd_idx];
            db_oe    <= 1'b1;
            frstdata <= (rd_idx == 3'd0);
            rd_idx   <= rd_idx + 3'd1;
        end
        else if (cs_n) begin
            db_oe    <= 1'b0;                 // CS 高 -> 释放总线
            rd_idx   <= 3'd0;
            frstdata <= 1'b0;
        end
    end

endmodule

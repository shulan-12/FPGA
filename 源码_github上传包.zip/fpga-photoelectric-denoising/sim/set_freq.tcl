open_hw
connect_hw_server -url localhost:3121
open_hw_target [lindex [get_hw_targets] 0]
set tgt [current_hw_target]
puts "FREQ_BEFORE = [get_property PARAM.FREQUENCY $tgt]"
foreach f {1000000 500000 2000000} {
    if {[catch { set_property PARAM.FREQUENCY $f $tgt } e]} {
        puts "SET_$f FAIL: $e"
    } else {
        puts "SET_$f OK -> now = [get_property PARAM.FREQUENCY $tgt]"
        break
    }
}
puts "########## DONE ##########"

#=============================================================================
# Frontend test stream: synth -> impl -> timing -> bitstream
# Top: top_adc_stream  (real AD7606 -> FIR -> UART)
# Output: ../sim/ax7035_adc_stream.bit
#=============================================================================
create_project -in_memory -part xc7a35tfgg484-2

read_verilog ../rtl/uart_tx.v
read_verilog ../rtl/frame_tx.v
read_verilog ../rtl/capture_buf.v
read_verilog ../rtl/denoise_filter.v
read_verilog ../rtl/ad7606_if.v
read_verilog ../rtl/mod_gen.v
read_verilog ../rtl/top_adc_stream.v
read_xdc     ../constrs/AX7035_adc_stream.xdc

synth_design -top top_adc_stream -part xc7a35tfgg484-2
puts "########## SYNTH DONE ##########"

opt_design
place_design
route_design
puts "########## IMPL DONE ##########"

report_timing_summary -delay_type min_max -check_timing_verbose
report_utilization

puts "########## IO PLACEMENT ##########"
foreach port [get_ports] {
    set p [get_ports $port]
    puts "  port $port -> [get_property -quiet PACKAGE_PIN $p] iostd=[get_property -quiet IOSTANDARD $p]"
}

puts "########## DRC ##########"
report_drc -return_string

puts "########## BITSTREAM ##########"
write_bitstream -force ../sim/ax7035_adc_stream.bit
puts "########## ALL DONE ##########"

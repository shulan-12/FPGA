//=============================================================================
// tb_top_blink_uart.v  --  self-checking testbench for top_blink_uart
//-----------------------------------------------------------------------------
// What it proves (automatic PASS/FAIL, no eyeballing waveforms):
//   1) uart_tx is HIGH during reset (idle level of an async serial line)
//   2) it decodes the line back into bytes at 115200/8N1 and compares with
//      "HELLO\r\n" byte by byte
//   3) led1 toggle period == 2*BLINK_DIV clocks
// The receiver model samples at the CENTER of every bit, exactly like a real
// UART receiver chip, so a wrong divider ratio would actually fail here.
//
// NOTE: all $display strings are ASCII on purpose -- the ModelSim console on a
// Chinese Windows codepage mangles UTF-8 Chinese text. Comments stay Chinese.
//=============================================================================
`timescale 1ns / 1ps

module tb_top_blink_uart;

    // ---- same timing parameters as the DUT ----
    localparam integer CLK_FREQ  = 50_000_000;
    localparam integer BAUD      = 115200;
    localparam integer BLINK_DIV = 25;      // small for sim: toggle every 25 clks = 500ns
    localparam integer SEND_DIV  = 40000;   // small for sim: one burst per 800us

    localparam real CLK_PERIOD = 20.0;                          // 50 MHz
    localparam real BIT_TIME   = CLK_PERIOD * (CLK_FREQ/BAUD);  // 434 * 20 = 8680 ns

    reg  clk   = 1'b0;
    reg  rst_n = 1'b0;
    wire led1, led2, uart_tx;

    integer errors = 0;

    always #(CLK_PERIOD/2.0) clk = ~clk;

    top_blink_uart #(
        .CLK_FREQ  (CLK_FREQ),
        .BAUD      (BAUD),
        .BLINK_DIV (BLINK_DIV),
        .SEND_DIV  (SEND_DIV)
    ) dut (
        .clk     (clk),
        .rst_n   (rst_n),
        .led1    (led1),
        .led2    (led2),
        .uart_tx (uart_tx)
    );

    //-------------------------------------------------------------------------
    // UART receiver model: wait for start-bit falling edge, then step to the
    // middle of each bit and sample it. LSB first, 8 data bits, 1 stop bit.
    //-------------------------------------------------------------------------
    reg [7:0] rx_byte;
    integer   k;

    task rx_one;
        begin
            @(negedge uart_tx);        // start bit
            #(BIT_TIME * 1.5);         // centre of bit0
            for (k = 0; k < 8; k = k + 1) begin
                rx_byte[k] = uart_tx;
                #(BIT_TIME);
            end
            // now sitting at the centre of the stop bit
            if (uart_tx !== 1'b1) begin
                $display("[%0t] FAIL: stop bit is not high", $time);
                errors = errors + 1;
            end
            #(BIT_TIME * 0.5);         // move to end of frame
        end
    endtask

    //-------------------------------------------------------------------------
    // main
    //-------------------------------------------------------------------------
    reg [7:0] expected [0:6];
    reg [7:0] got      [0:6];
    integer   i;
    real      t1, t2, led_period;

    initial begin
        expected[0] = 8'h48; expected[1] = 8'h45; expected[2] = 8'h4C;
        expected[3] = 8'h4C; expected[4] = 8'h4F; expected[5] = 8'h0D;
        expected[6] = 8'h0A;

        $display("=== tb_top_blink_uart start ===");

        // 1) idle level during reset
        #200;
        if (uart_tx !== 1'b1) begin
            $display("[%0t] FAIL: uart_tx must be high (idle) during reset", $time);
            errors = errors + 1;
        end
        else begin
            $display("[%0t] OK  : uart_tx = 1 (idle) during reset", $time);
        end
        rst_n = 1'b1;

        // 2) receive 7 bytes and compare
        for (i = 0; i < 7; i = i + 1) begin
            rx_one;
            got[i] = rx_byte;
            if (got[i] !== expected[i]) begin
                $display("[%0t] FAIL: byte %0d expected %02h got %02h", $time, i, expected[i], got[i]);
                errors = errors + 1;
            end
            else begin
                $display("[%0t] OK  : byte %0d = %02h ('%c')", $time, i, got[i], got[i]);
            end
        end

        // 3) LED toggle period
        @(posedge led1); t1 = $realtime;
        @(posedge led1); t2 = $realtime;
        led_period = t2 - t1;
        $display("[%0t] led1 period = %0.1f ns (expected %0.1f ns)", $time, led_period, 2.0*BLINK_DIV*CLK_PERIOD);
        if (led_period != 2.0*BLINK_DIV*CLK_PERIOD) begin
            $display("[%0t] FAIL: led1 period wrong", $time);
            errors = errors + 1;
        end
        if (led2 !== ~led1) begin
            $display("[%0t] FAIL: led2 should be the inverse of led1", $time);
            errors = errors + 1;
        end

        // 4) verdict
        if (errors == 0) $display("=== ALL CHECKS PASSED ===");
        else             $display("=== %0d CHECK(S) FAILED ===", errors);
        $finish;
    end

    // timeout guard: a normal burst takes ~610us, allow 3ms
    initial begin
        #3_000_000;
        $display("FAIL: simulation timeout - no UART output at all");
        $finish;
    end

endmodule

//=============================================================================
// tb_ad7606_if.v  --  AD7606 采集接口自检 testbench
//-----------------------------------------------------------------------------
// 验证什么 (全部自动判 PASS/FAIL):
//   1) 采集控制器读回来的 8 个通道数据, 与 AD7606 模型内部锁存的真值【逐位相等】
//   2) 通道顺序对不对 (vin1..vin7 特意给了 0x1111..0x7777 这种"身份码",
//      通道顺序一错立刻暴露)
//   3) sample_valid 每帧正好 8 个, 每个通道号按 0..7 顺序出现
//   4) 采样率是否等于设定的 CONV_RATE
//   5) BUSY 高电平持续时间是否接近芯片手册的 TCONV (4us)
//   6) 超时保护 error_timeout 全程必须保持 0
//   7) 顺便统计 pd_src 造出来的信号实际 SNR, 给 B 调滤波器当基准
//
// 全部用 Verilog-2001 语法 (不用 fork/join_any 等 SystemVerilog 结构)
// 注意: 所有 $display 用 ASCII, 因为中文 Windows 的 ModelSim 控制台是 GBK 码页。
//=============================================================================
`timescale 1ns / 1ps

module tb_ad7606_if;

    //---------------- 参数 ----------------
    // ★ 下面这三个故意用 parameter 而不是 localparam: 可以在命令行覆盖, 方便做实验
    //   例:  vsim -gRD_LOW_CYC=1 -c -do "run -all; quit -f" work.tb_ad7606_if
    //   (localparam 是覆盖不了的, 这是 ModelSim 的规则)
    parameter integer CONV_RATE   = 100_000;     // 100 kHz 采样
    parameter integer RD_LOW_CYC  = 3;           // RD 低电平持续时钟数
    parameter integer RD_HIGH_CYC = 2;           // RD 高电平持续时钟数

    localparam integer CLK_FREQ   = 50_000_000;
    localparam integer CLK_PERIOD = 20;          // ns
    localparam integer TCONV_NS   = 4000;        // AD7606 转换时间
    localparam integer N_FRAMES   = 500;         // 跑多少帧
    localparam integer CHK_FRAMES = 10;          // 前多少帧做逐通道严格比对
    localparam integer MAX_CLKS   = 2_000_000;   // 主循环保护上限

    localparam real CLK_HALF = CLK_PERIOD / 2.0;

    //---------------- 时钟/复位 ----------------
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_HALF) clk = ~clk;

    //---------------- DUT <-> 模型 连线 ----------------
    wire        convst, cs_n, rd_n, ad_reset;
    wire [15:0] db;
    wire        busy, frstdata;

    wire signed [15:0] sample_data;
    wire [2:0]         sample_ch;
    wire               sample_valid, frame_done, error_timeout;

    //---------------- 信号源 ----------------
    reg  src_step;
    wire signed [15:0] src_clean, src_code;

    //---------------- 模型真值 ----------------
    wire [127:0] ch_flat;
    reg  [127:0] ch_captured;

    //---------------- 统计变量 (全部放模块级, 保证 Verilog-2001 兼容) ----------------
    integer errors          = 0;
    integer frame_cnt       = 0;
    integer valid_in_frame  = 0;
    integer total_valid     = 0;
    integer chk_frames_done = 0;
    integer convst_cnt      = 0;
    integer stat_cnt        = 0;
    integer guard           = 0;

    real acc_clean2   = 0.0;
    real acc_noise2   = 0.0;
    real t_busy_rise  = 0.0;
    real t_busy_fall  = 0.0;
    real busy_width_ns = 0.0;
    real t_first_convst = -1.0;
    real t_last_convst  = 0.0;

    reg busy_d    = 1'b0;
    reg convst_d2 = 1'b0;
    reg rd_n_d    = 1'b1;
    reg convst_d1 = 1'b0;
    reg err_to_d  = 1'b0;

    integer c_val = 0;
    integer n_val = 0;

    real measured_rate;
    real snr_db;

    //=========================================================================
    // 采集控制器 (DUT)
    //=========================================================================
    ad7606_if #(
        .CLK_FREQ    (CLK_FREQ),
        .CONV_RATE   (CONV_RATE),
        .CONV_PULSE  (2),
        .RD_LOW_CYC  (RD_LOW_CYC),
        .RD_HIGH_CYC (RD_HIGH_CYC),
        .BUSY_TO_CYC (2000)
    ) dut (
        .clk          (clk),
        .rst_n        (rst_n),
        .convst       (convst),
        .cs_n         (cs_n),
        .rd_n         (rd_n),
        .ad_reset     (ad_reset),
        .db           (db),
        .busy         (busy),
        .frstdata     (frstdata),
        .sample_data  (sample_data),
        .sample_ch    (sample_ch),
        .sample_valid (sample_valid),
        .frame_done   (frame_done),
        .error_timeout(error_timeout)
    );

    //=========================================================================
    // AD7606 行为模型
    //   ch0 接带噪信号源; ch1..ch7 接固定"身份码", 用来抓通道顺序错误
    //=========================================================================
    ad7606_model #(
        .TCONV_NS      (TCONV_NS),
        .BUSY_DELAY_NS (40),
        .CLK_PERIOD_NS (CLK_PERIOD)
    ) u_adc (
        .clk      (clk),
        .convst   (convst),
        .cs_n     (cs_n),
        .rd_n     (rd_n),
        .ad_reset (ad_reset),
        .vin0     (src_code),
        .vin1     (16'sh1111),
        .vin2     (16'sh2222),
        .vin3     (16'sh3333),
        .vin4     (16'sh4444),
        .vin5     (16'sh5555),
        .vin6     (16'sh6666),
        .vin7     (16'sh7777),
        .db       (db),
        .busy     (busy),
        .frstdata (frstdata),
        .ch_flat  (ch_flat)
    );

    //=========================================================================
    // 带噪信号源 (模拟光电探测器 + 前置放大的输出)
    //=========================================================================
    pd_src #(
        .AMP    (3000),
        .NOISE  (40),
        .PERIOD (64),
        .SEED   (32'hDEAD_BEEF)
    ) u_src (
        .clk   (clk),
        .rst_n (rst_n),
        .step  (src_step),
        .clean (src_clean),
        .code  (src_code)
    );

    // 用 CONVST 上升沿当作"采样节拍"
    always @(posedge clk) begin
        convst_d2 <= convst;
        src_step  <= convst & ~convst_d2;
    end

    //=========================================================================
    // 监视进程
    //=========================================================================
    always @(posedge clk) begin
        busy_d    <= busy;
        convst_d1 <= convst;

        // ---- BUSY 上升沿: 芯片刚锁存完模拟输入, 抓一份真值 ----
        if (busy & ~busy_d) begin
            ch_captured    <= ch_flat;
            valid_in_frame <= 0;
            t_busy_rise    <= $realtime;
        end

        // ---- BUSY 下降沿: 量高电平宽度 ----
        if (~busy & busy_d) begin
            t_busy_fall   = $realtime;
            busy_width_ns = t_busy_fall - t_busy_rise;
        end

        // ---- 每个有效通道 ----
        if (sample_valid) begin
            total_valid <= total_valid + 1;

            // 逐通道逐位比对 (前 CHK_FRAMES 帧)
            if (chk_frames_done < CHK_FRAMES) begin
                if (sample_data !== ch_captured[sample_ch*16 +: 16]) begin
                    $display("[%0t] FAIL: frame=%0d ch=%0d expected=%04h got=%04h",
                             $time, frame_cnt, sample_ch,
                             ch_captured[sample_ch*16 +: 16], sample_data);
                    errors = errors + 1;
                end
            end

            // 通道号必须按 0..7 依次出现
            if (sample_ch !== valid_in_frame[2:0]) begin
                $display("[%0t] FAIL: 通道顺序错 frame=%0d expected ch=%0d got ch=%0d",
                         $time, frame_cnt, valid_in_frame, sample_ch);
                errors = errors + 1;
            end

            valid_in_frame <= valid_in_frame + 1;
        end

        // ---- 每帧收尾 ----
        if (frame_done) begin
            if (valid_in_frame != 8) begin
                $display("[%0t] FAIL: frame=%0d 只读到 %0d 个通道 (应为 8)",
                         $time, frame_cnt, valid_in_frame);
                errors = errors + 1;
            end
            frame_cnt <= frame_cnt + 1;
            if (chk_frames_done < CHK_FRAMES) chk_frames_done <= chk_frames_done + 1;
        end

        // ---- 超时保护必须一直不触发 ----
        //     注意: error_timeout 是【锁存型】标志, 置位后一直为高。
        //     所以只能在上跳沿报一次, 否则每个时钟都刷屏。
        if (error_timeout & ~err_to_d) begin
            $display("[%0t] FAIL: error_timeout 被触发, BUSY 没按预期翻转", $time);
            errors = errors + 1;
        end
        err_to_d <= error_timeout;

        // ---- CONVST 计数 + 采样率测量 ----
        if (convst & ~convst_d1) begin
            convst_cnt <= convst_cnt + 1;
            if (t_first_convst < 0.0) t_first_convst = $realtime;
            t_last_convst = $realtime;
        end

        // ---- 信号源统计: 干净信号与噪声分离, 算实际 SNR ----
        if (src_step) begin
            c_val = src_clean;
            n_val = src_code - src_clean;
            acc_clean2 = acc_clean2 + $itor(c_val) * $itor(c_val);
            acc_noise2 = acc_noise2 + $itor(n_val) * $itor(n_val);
            stat_cnt   = stat_cnt + 1;
        end
    end

    //=========================================================================
    // 主流程
    //=========================================================================
    initial begin
        $display("=== tb_ad7606_if 开始 ===");
        $display("  采样率设定 = %0d Hz, 每帧 8 通道, 计划跑 %0d 帧", CONV_RATE, N_FRAMES);

        rst_n    = 1'b0;
        src_step = 1'b0;
        #200;
        rst_n = 1'b1;

        // 等跑够帧数 (纯 Verilog-2001 轮询, 带保护上限, 不会 hang 死)
        guard = 0;
        while (frame_cnt < N_FRAMES && guard < MAX_CLKS) begin
            @(posedge clk);
            guard = guard + 1;
        end
        if (frame_cnt < N_FRAMES) begin
            $display("FAIL: 等待超时, 只收到 %0d/%0d 帧", frame_cnt, N_FRAMES);
            errors = errors + 1;
        end

        //---------------- 汇总 ----------------
        $display("");
        $display("--- 时序统计 ---");
        $display("  CONVST 次数        = %0d", convst_cnt);
        if (t_first_convst >= 0.0 && convst_cnt > 1) begin
            measured_rate = $itor(convst_cnt - 1) * 1.0e9 / (t_last_convst - t_first_convst);
            $display("  实测采样率         = %0.1f Hz  (设定 %0d Hz)", measured_rate, CONV_RATE);
            if (measured_rate < $itor(CONV_RATE)*0.98 || measured_rate > $itor(CONV_RATE)*1.02) begin
                $display("  FAIL: 采样率偏差超过 2%%");
                errors = errors + 1;
            end
            else $display("  OK  : 采样率在 2%% 容差内");
        end
        $display("  BUSY 高电平宽度     = %0.1f ns  (手册 TCONV = %0d ns)", busy_width_ns, TCONV_NS);
        if (busy_width_ns < $itor(TCONV_NS)-100.0 || busy_width_ns > $itor(TCONV_NS)+400.0) begin
            $display("  FAIL: BUSY 宽度与 TCONV 不符");
            errors = errors + 1;
        end
        else $display("  OK  : BUSY 宽度符合 TCONV");

        $display("");
        $display("--- 数据通路 ---");
        $display("  完成帧数           = %0d", frame_cnt);
        $display("  读到通道总数        = %0d  (期望 %0d)", total_valid, frame_cnt*8);
        $display("  逐通道严格比对帧数   = %0d  (每帧 8 通道逐位比对)", chk_frames_done);

        $display("");
        $display("--- 信号源实测 (pd_src, 给 B 当滤波器基准) ---");
        if (acc_noise2 > 0.0 && stat_cnt > 0) begin
            snr_db = 10.0 * $log10(acc_clean2 / acc_noise2);
            $display("  统计样本数          = %0d", stat_cnt);
            $display("  干净信号 RMS        = %0.1f LSB", $sqrt(acc_clean2 / $itor(stat_cnt)));
            $display("  噪声     RMS        = %0.1f LSB", $sqrt(acc_noise2 / $itor(stat_cnt)));
            $display("  实测 SNR            = %0.2f dB", snr_db);
            $display("  (滤波器要打败的基线就是这条线)");
        end
        else begin
            $display("  信号源没有产生数据, 检查 src_step");
            errors = errors + 1;
        end

        $display("");
        if (errors == 0) $display("=== 全部通过 PASS ===");
        else             $display("=== 失败 %0d 项 FAIL ===", errors);
        $finish;
    end

endmodule

#=============================================================================
# AX7035 全流程检查: 综合 -> 实现 -> 时序 -> 生成比特流
# 目的: 证明 AX7035 的引脚约束是真的能用, 不是纸上写的
# 跑法: vivado -mode batch -source build_check.tcl
#=============================================================================
create_project -in_memory -part xc7a35tfgg484-2

read_verilog ../rtl/uart_tx.v
read_verilog ../rtl/top_blink_uart.v
read_xdc     ../constrs/AX7035_led_uart.xdc

synth_design -top top_blink_uart -part xc7a35tfgg484-2

puts "########## SYNTH DONE ##########"

opt_design
place_design
route_design

puts "########## IMPL DONE ##########"

puts "########## TIMING SUMMARY ##########"
report_timing_summary -delay_type min_max -report_unconstrained -check_timing_verbose

puts "########## IO PLACEMENT ##########"
foreach port [get_ports] {
    set p [get_ports $port]
    puts "  port $port -> [get_property -quiet PACKAGE_PIN $p] iostd=[get_property -quiet IOSTANDARD $p]"
}

puts "########## DRC ##########"
report_drc -return_string

puts "########## BITSTREAM ##########"
write_bitstream -force ../sim/ax7035_led_uart.bit

puts "########## ALL DONE ##########"

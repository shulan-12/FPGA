//=============================================================================
// tb_top_adc_stream.v  --  前端联调测试流 (top_adc_stream) 的集成仿真
//-----------------------------------------------------------------------------
// 验证什么:
//   1) 真实 AD7606 模型 -> ad7606_if -> 通道0筛选 -> FIR -> 双缓冲 -> 串口
//      整条链路能不能跑通, 帧格式对不对
//   2) ★ 通道筛选是否正确:
//      给通道0 恒定 1000 LSB, 其它通道故意给 -3000。
//      如果 ch0 筛选写错(比如 8 通道全灌进滤波器), 输出就不可能是 1000,
//      而且滤波器会因 65 拍/样本 x 8 通道 > 500 拍而丢样本。
//   3) ★ raw 与 flt 的对齐是否正确(都应该是 ~1000, 不能一个 1000 一个 0)
//   4) 两帧同 SEQ (成对发送)
//
// 仿真时长约 12 ms (warm-up 2.56 ms + 两对帧 ~3 ms + 余量)
//=============================================================================
`timescale 1ns / 1ps

module tb_top_adc_stream;

    parameter integer CLK_FREQ  = 50_000_000;
    parameter integer BAUD      = 921600;
    parameter integer DEPTH     = 64;
    parameter integer NPAIRS    = 2;

    // ★ 模型输入: 通道0 恒为这个值, 其余通道故意给别的值
    parameter integer V_CH0     = 1000;
    parameter integer V_OTHER   = -3000;

    localparam integer CLK_PERIOD = 20;
    localparam real    BIT_TIME   = CLK_PERIOD * (CLK_FREQ / BAUD);   // 54*20 = 1080 ns
    localparam integer LEN_EXPECT = DEPTH * 2;

    //---------------- 时钟/复位 ----------------
    reg clk   = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2.0) clk = ~clk;

    //---------------- DUT ----------------
    wire       led1, led2, led3, uart_tx;
    wire       ad_convst, ad_convst_b, ad_cs_n, ad_rd_n, ad_reset;
    wire [2:0] ad_os;
    wire       ad_stby, ad_ser;
    wire [15:0] ad_db;
    wire       ad_busy, ad_frstdata;

    top_adc_stream #(
        .CLK_FREQ   (CLK_FREQ),
        .BAUD       (BAUD),
        .CONV_RATE  (100_000),
        .DECIM      (8),
        .DEPTH      (DEPTH),
        .FLT_DELAY  (64),
        .BLINK_DIV  (100),
        .TAPS       (129),
        .OS_SET     (0)
    ) dut (
        .clk         (clk),
        .rst_n       (rst_n),
        .led1        (led1),
        .led2        (led2),
        .led3        (led3),
        .uart_tx     (uart_tx),
        .ad_convst   (ad_convst),
        .ad_convst_b (ad_convst_b),
        .ad_cs_n     (ad_cs_n),
        .ad_rd_n     (ad_rd_n),
        .ad_reset    (ad_reset),
        .ad_os       (ad_os),
        .ad_stby     (ad_stby),
        .ad_ser      (ad_ser),
        .ad_db       (ad_db),
        .ad_busy     (ad_busy),
        .ad_frstdata (ad_frstdata)
    );

    //---------------- AD7606 行为模型 ----------------
    wire [127:0] ch_flat;

    ad7606_model u_adc (
        .clk       (clk),
        .convst    (ad_convst),
        .cs_n      (ad_cs_n),
        .rd_n      (ad_rd_n),
        .ad_reset  (ad_reset),
        .vin0      (V_CH0[15:0]),
        .vin1      (V_OTHER[15:0]),
        .vin2      (V_OTHER[15:0]),
        .vin3      (V_OTHER[15:0]),
        .vin4      (V_OTHER[15:0]),
        .vin5      (V_OTHER[15:0]),
        .vin6      (V_OTHER[15:0]),
        .vin7      (V_OTHER[15:0]),
        .db        (ad_db),
        .busy      (ad_busy),
        .frstdata  (ad_frstdata),
        .ch_flat   (ch_flat)
    );

    //=========================================================================
    // UART 接收模型 (每位正中间采样)
    //=========================================================================
    reg [7:0] rx_byte;
    integer   k;

    task rx_one;
        begin
            @(negedge uart_tx);
            #(BIT_TIME * 1.5);
            for (k = 0; k < 8; k = k + 1) begin
                rx_byte[k] = uart_tx;
                #(BIT_TIME);
            end
            #(BIT_TIME * 0.5);
        end
    endtask

    //=========================================================================
    // 帧解析 + 比对
    //=========================================================================
    integer errors = 0;
    integer pairs  = 0;
    integer i, di, v;

    reg [7:0] b;
    reg [7:0] type_rx, len_rx, sum_rx, sum_calc;
    reg [15:0] seq_lo, seq_rx, seq_raw, last_seq;

    reg [7:0]  data [0:255];
    integer    state = 0;
    integer    raw_first = 1;
    integer    have_raw = 0;
    integer    samp [0:255];
    integer    raw_samp [0:255];
    integer    guard;

    integer    flt_min, flt_max, raw_all_ok;
    integer    dump_fd;

    initial dump_fd = $fopen("../tools/adc_stream_dump.bin", "wb");

    //---------------- 全局超时 ----------------
    initial begin
        #20_000_000;                                    // 20 ms
        $display("");
        $display("!!! TIMEOUT: 20 ms 内没收到 %0d 对帧, 只收到 %0d 对", NPAIRS, pairs);
        $display("=== RESULT: FAIL (timeout) ===");
        $finish;
    end

    //---------------- 主流程 ----------------
    initial begin
        $timeformat(-9, 3, " ns", 12);

        $display("=== tb_top_adc_stream : real AD7606 -> FIR -> UART ===");
        $display("  baud=%0d  depth=%0d  decim=8 -> 12.5 kSPS", BAUD, DEPTH);
        $display("  通道0 = %0d LSB (恒定), 其余通道 = %0d LSB (应被排除)", V_CH0, V_OTHER);
        $display("  期望: RAW 全部 = %0d; FILT 接近 %0d; 两帧同 SEQ", V_CH0, V_CH0);
        $display("");

        rst_n = 1'b0;
        #200;
        rst_n = 1'b1;

        // 检查静态配置脚
        #2000;
        if (ad_stby !== 1'b1) begin
            $display("[%0t] FAIL: ad_stby=%b, 应为 1 (否则芯片待机)", $time, ad_stby);
            errors = errors + 1;
        end
        if (ad_ser !== 1'b0) begin
            $display("[%0t] FAIL: ad_ser=%b, 应为 0 (并行接口)", $time, ad_ser);
            errors = errors + 1;
        end
        if (ad_os !== 3'b000) begin
            $display("[%0t] FAIL: ad_os=%b, 应为 000 (不过采样)", $time, ad_os);
            errors = errors + 1;
        end
        if (errors == 0) $display("[%0t] OK  : STBY=1 SER=0 OS=000 静态配置正确", $time);

        guard = 0;
        while (pairs < NPAIRS && errors == 0 && guard < 4000) begin
            rx_one;
            b = rx_byte;
            $fwrite(dump_fd, "%c", rx_byte);
            guard = guard + 1;

            case (state)
            0: if (b == 8'hAA) state = 1;
            1: begin
                   if (b == 8'h55)      state = 2;
                   else if (b == 8'hAA) state = 1;
                   else                 state = 0;
               end
            2: begin type_rx = b; sum_calc = b; state = 3; end
            3: begin
                   len_rx = b; sum_calc = sum_calc + b; di = 0;
                   if (b != LEN_EXPECT[7:0]) begin
                       $display("[%0t] FAIL: length=%0d expected %0d", $time, b, LEN_EXPECT);
                       errors = errors + 1;
                   end
                   state = 4;
               end
            4: begin seq_lo = {8'd0, b}; sum_calc = sum_calc + b; state = 5; end
            5: begin seq_rx = {b, seq_lo[7:0]}; sum_calc = sum_calc + b; state = 6; end
            6: begin
                   data[di] = b; sum_calc = sum_calc + b; di = di + 1;
                   if (di >= LEN_EXPECT) state = 7;
               end
            7: begin
                   sum_rx = b;
                   if (sum_calc !== sum_rx) begin
                       $display("[%0t] FAIL: checksum calc=%02h rx=%02h", $time, sum_calc, sum_rx);
                       errors = errors + 1;
                   end
                   else begin
                       for (i = 0; i < DEPTH; i = i + 1) begin
                           v = {data[i*2+1], data[i*2]};
                           if (v >= 32768) v = v - 65536;
                           samp[i] = v;
                       end

                       if (type_rx == 8'h01) begin
                           if (!raw_first) begin
                               $display("[%0t] FAIL: 期望 FILTERED 帧却收到 RAW", $time);
                               errors = errors + 1;
                           end
                           raw_all_ok = 1;
                           for (i = 0; i < DEPTH; i = i + 1) begin
                               raw_samp[i] = samp[i];
                               if (samp[i] !== V_CH0) raw_all_ok = 0;
                           end
                           if (!raw_all_ok) begin
                               $display("[%0t] FAIL: RAW 帧采样不等于 %0d!", $time, V_CH0);
                               $display("        samples[0..7] = %0d %0d %0d %0d %0d %0d %0d %0d",
                                        samp[0],samp[1],samp[2],samp[3],samp[4],samp[5],samp[6],samp[7]);
                               errors = errors + 1;
                           end
                           seq_raw   = seq_rx;
                           have_raw  = 1;
                           raw_first = 0;
                           $display("[%0t] OK  : frame RAW      seq=%0d len=%0d csum=%02h  samples[0..7]=%0d %0d %0d %0d %0d %0d %0d %0d",
                                    $time, seq_rx, len_rx, sum_rx,
                                    samp[0],samp[1],samp[2],samp[3],samp[4],samp[5],samp[6],samp[7]);
                       end
                       else if (type_rx == 8'h02) begin
                           if (raw_first) begin
                               $display("[%0t] FAIL: 期望 RAW 帧却收到 FILTERED", $time);
                               errors = errors + 1;
                           end
                           flt_min =  999999;
                           flt_max = -999999;
                           for (i = 0; i < DEPTH; i = i + 1) begin
                               if (samp[i] < flt_min) flt_min = samp[i];
                               if (samp[i] > flt_max) flt_max = samp[i];
                           end
                           // 直流输入经 FIR 后应接近原值(允许 Q1.15 定点误差)
                           if (flt_min < V_CH0-100 || flt_max > V_CH0+100) begin
                               $display("[%0t] FAIL: FILT 帧范围 [%0d, %0d] 偏离 %0d 超过 100",
                                        $time, flt_min, flt_max, V_CH0);
                               errors = errors + 1;
                           end
                           if (seq_rx !== seq_raw) begin
                               $display("        FAIL: pair seq mismatch raw=%0d filtered=%0d",
                                        seq_raw, seq_rx);
                               errors = errors + 1;
                           end
                           last_seq = seq_rx;
                           pairs    = pairs + 1;
                           raw_first = 1;
                           have_raw  = 0;
                           $display("[%0t] OK  : frame FILTERED seq=%0d len=%0d csum=%02h  range=[%0d, %0d]  (DC 输入 %0d)",
                                    $time, seq_rx, len_rx, sum_rx, flt_min, flt_max, V_CH0);
                       end
                       else begin
                           $display("[%0t] FAIL: 未知帧类型 0x%02h", $time, type_rx);
                           errors = errors + 1;
                       end
                   end
                   state = 0;
               end
            default: state = 0;
            endcase
        end

        // 收尾
        $display("");
        if (errors == 0 && pairs >= NPAIRS) begin
            $display("  收到成对帧            = %0d 对 (期望 %0d)", pairs, NPAIRS);
            $display("  LED: led1=%b led2=%b led3(常亮应为0)=%b", led1, led2, led3);
            $display("=== RESULT: PASS ===");
        end
        else begin
            $display("  收到成对帧 = %0d 对, errors = %0d", pairs, errors);
            $display("=== RESULT: FAIL ===");
        end
        $fclose(dump_fd);
        $finish;
    end

endmodule

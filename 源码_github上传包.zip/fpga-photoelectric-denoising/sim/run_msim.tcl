#=============================================================================
# ModelSim 命令行仿真脚本 (配合 vsim -c 使用)
#
# 在 sim 目录下依次执行:
#   vlib work
#   vlog -work work ..\rtl\uart_tx.v ..\rtl\top_blink_uart.v .\tb_top_blink_uart.v
#   vsim -c -do run_msim.tcl work.tb_top_blink_uart
#
# 想要波形: 把下面两行注释掉换成
#   add wave -r /*
#   run -all
# 然后用 vsim -gui -do run_msim.tcl work.tb_top_blink_uart 打开图形界面
#=============================================================================
run -all
quit -f

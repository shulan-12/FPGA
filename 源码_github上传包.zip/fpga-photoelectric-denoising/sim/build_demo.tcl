#=============================================================================
# 整机数据通路演示 (top_demo) 全流程: 综合 -> 实现 -> 时序 -> 比特流
# 引脚约束复用 AX7035_led_uart.xdc (端口名完全一致: clk/rst_n/led1/led2/uart_tx)
#=============================================================================
create_project -in_memory -part xc7a35tfgg484-2

read_verilog ../rtl/uart_tx.v
read_verilog ../rtl/fake_src.v
read_verilog ../rtl/denoise_filter.v
read_verilog ../rtl/capture_buf.v
read_verilog ../rtl/frame_tx.v
read_verilog ../rtl/top_demo.v
read_xdc     ../constrs/AX7035_led_uart.xdc

synth_design -top top_demo -part xc7a35tfgg484-2

puts "########## SYNTH DONE ##########"

opt_design
place_design
route_design

puts "########## IMPL DONE ##########"

report_timing_summary -delay_type min_max -check_timing_verbose

puts "########## IO PLACEMENT ##########"
foreach port [get_ports] {
    set p [get_ports $port]
    puts "  port $port -> [get_property -quiet PACKAGE_PIN $p] iostd=[get_property -quiet IOSTANDARD $p]"
}

puts "########## BITSTREAM ##########"
write_bitstream -force ../sim/ax7035_top_demo.bit

puts "########## ALL DONE ##########"

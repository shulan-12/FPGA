set MCS "D:/deepseek/CODE/fpga_denoise/sim/ax7035_adc_stream.mcs"
if {![file exists $MCS]} { puts "MCS_MISSING: $MCS"; exit 1 }
puts "MCS: $MCS  ([file size $MCS] bytes)"

open_hw
connect_hw_server -url localhost:3121
set ts [get_hw_targets]
open_hw_target [lindex $ts 0]
set dev [lindex [get_hw_devices] 0]
current_hw_device $dev
puts "DEVICE: $dev"

set ok 0
foreach pn {n25q64-3.3v-spi-x1_x2_x4 w25q128-qspi-x4-single n25q32-3.3v-spi-x1_x2_x4} {
    if {$ok} { break }
    puts "--- try part: $pn ---"
    if {[catch { create_hw_cfgmem -hw_device $dev [lindex [get_cfgmem_parts $pn] 0] } e]} {
        puts "  CREATE_FAIL: $e"
        continue
    }
    set cfg [get_property PROGRAM.HW_CFGMEM $dev]
    if {$cfg eq ""} { puts "  NO_CFGMEM"; continue }

    set_property PROGRAM.BLANK_CHECK 0 $cfg
    set_property PROGRAM.ERASE       1 $cfg
    set_property PROGRAM.CFG_PROGRAM 1 $cfg
    set_property PROGRAM.VERIFY      1 $cfg
    set_property PROGRAM.CHECKSUM    0 $cfg
    set_property PROGRAM.FILES [list $MCS] $cfg

    puts "  PROGRAM.PART = [get_property -quiet PROGRAM.PART $cfg]"
    puts "  FILES        = [get_property -quiet PROGRAM.FILES $cfg]"
    puts "  >>> programming, do NOT unplug <<<"
    if {[catch { program_hw_cfgmem -hw_cfgmem $cfg } e2]} {
        puts "  PROGRAM_FAIL: $e2"
    } else {
        puts "  PROGRAM_OK"
        set ok 1
    }
}
if {$ok} { puts "########## FLASH PROGRAMMED OK ##########" } else { puts "########## FLASH PROGRAM FAILED ##########" }

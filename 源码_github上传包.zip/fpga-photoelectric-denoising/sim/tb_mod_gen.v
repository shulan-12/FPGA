//=============================================================================
// tb_mod_gen.v -- 验证 1kHz 正弦调制发生器
//-----------------------------------------------------------------------------
// 验三件事:
//   1) mod_out 真的在翻转 (不是恒 0/恒 1)
//   2) PWM 载波频率 = 100 kHz (每 500 拍一个 PWM 周期)
//   3) 每个 PWM 周期的占空比按 1 kHz 正弦变化:
//        - 占空比 min ≈ (250-AMP_DELTA)/500
//        - 占空比 max ≈ (250+AMP_DELTA)/500
//        - 占空比穿越 50% 的上升次数 / 时长 = 调制频率 (应 1 kHz)
//=============================================================================
`timescale 1ns / 1ps

module tb_mod_gen;

    localparam integer CLK_FREQ  = 50_000_000;
    localparam integer CLK_PERIOD = 20;
    localparam integer MOD_FREQ  = 1_000;
    localparam integer PWM_FREQ  = 100_000;
    localparam integer AMP_PCT   = 60;

    localparam integer PWM_DIV   = CLK_FREQ / PWM_FREQ;      // 500
    localparam integer PWM_MID   = PWM_DIV / 2;              // 250
    localparam integer AMP_DELTA = (PWM_MID * AMP_PCT) / 100; // 150

    localparam real PWM_T_NS   = 1.0e9 / PWM_FREQ;           // 10000 ns
    localparam real RUN_MS     = 20.0;                        // 仿真 20 ms

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2.0) clk = ~clk;

    wire mod_out;

    mod_gen #(
        .CLK_FREQ (CLK_FREQ),
        .MOD_FREQ (MOD_FREQ),
        .PWM_FREQ (PWM_FREQ),
        .AMP_PCT  (AMP_PCT)
    ) dut (
        .clk     (clk),
        .rst_n   (rst_n),
        .mod_out (mod_out)
    );

    integer errors = 0;
    integer clk_cnt = 0;        // PWM 周期内计数
    integer high_cnt = 0;       // 本 PWM 周期高电平拍数
    integer pwm_periods = 0;
    integer duty_min = 99999, duty_max = -1;
    integer duty_prev = 0;
    integer rise_cross = 0;     // 占空比向上穿越 PWM_MID 的次数
    reg     first_period = 1'b1;

    // 记录 PWM 周期边界
    always @(posedge clk) begin
        if (!rst_n) begin
            clk_cnt <= 0; high_cnt <= 0;
        end
        else begin
            if (mod_out) high_cnt <= high_cnt + 1;
            if (clk_cnt == PWM_DIV-1) begin
                clk_cnt <= 0;
                // 一个 PWM 周期结束, 统计占空比
                if (pwm_periods > 4) begin      // 跳过前几个稳定周期
                    if (high_cnt < duty_min) duty_min <= high_cnt;
                    if (high_cnt > duty_max) duty_max <= high_cnt;
                    if (duty_prev < PWM_MID && high_cnt >= PWM_MID) begin
                        rise_cross <= rise_cross + 1;
                    end
                end
                duty_prev  <= high_cnt;
                pwm_periods <= pwm_periods + 1;
                high_cnt   <= 0;
            end
            else begin
                clk_cnt <= clk_cnt + 1;
            end
        end
    end

    integer i;
    real    t_ms;
    real    meas_mod_freq;
    integer exp_min, exp_max;

    initial begin
        $timeformat(-9, 3, " ns", 12);
        $display("=== tb_mod_gen : 1 kHz 正弦调制发生器 ===");
        $display("  PWM 载波 = %0d Hz (每 %0d 拍一个周期), 调制 = %0d Hz, 深度 %0d%%",
                 PWM_FREQ, PWM_DIV, MOD_FREQ, AMP_PCT);

        rst_n = 1'b0;
        #200;
        rst_n = 1'b1;

        for (i = 0; i < 200; i = i + 1) @(posedge clk);   // 等 DDS 跑起来

        #(RUN_MS * 1_000_000);

        t_ms          = RUN_MS;
        meas_mod_freq = rise_cross * 1000.0 / t_ms;
        exp_min       = PWM_MID - ((127 * AMP_DELTA) >>> 7);
        exp_max       = PWM_MID + ((127 * AMP_DELTA) >>> 7);

        $display("");
        $display("  PWM 周期总数              = %0d", pwm_periods);
        $display("  占空比(拍)  min=%0d  max=%0d   期望 min≈%0d max≈%0d",
                 duty_min, duty_max, exp_min, exp_max);
        $display("  占空比(%%)   min=%.1f  max=%.1f",
                 100.0*duty_min/PWM_DIV, 100.0*duty_max/PWM_DIV);
        $display("  穿越 50%% 上升次数         = %0d  -> 调制频率 ≈ %.0f Hz",
                 rise_cross, meas_mod_freq);

        // ---- 判定 ----
        if (duty_max <= duty_min) begin
            $display("  FAIL: 占空比没有变化, 没有调制!");
            errors = errors + 1;
        end
        if (duty_min < exp_min - 6 || duty_min > exp_min + 6) begin
            $display("  FAIL: 占空比 min 偏离期望 (实测 %0d, 期望 %0d±6)", duty_min, exp_min);
            errors = errors + 1;
        end
        if (duty_max < exp_max - 6 || duty_max > exp_max + 6) begin
            $display("  FAIL: 占空比 max 偏离期望 (实测 %0d, 期望 %0d±6)", duty_max, exp_max);
            errors = errors + 1;
        end
        if (meas_mod_freq < MOD_FREQ*0.95 || meas_mod_freq > MOD_FREQ*1.05) begin
            $display("  FAIL: 调制频率偏离 (实测 %.0f Hz, 期望 %0d Hz)", meas_mod_freq, MOD_FREQ);
            errors = errors + 1;
        end

        $display("");
        if (errors == 0)
            $display("=== RESULT: PASS ===");
        else
            $display("=== RESULT: FAIL (%0d) ===", errors);
        $finish;
    end

endmodule

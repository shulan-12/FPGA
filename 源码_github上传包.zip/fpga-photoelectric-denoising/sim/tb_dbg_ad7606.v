//=============================================================================
// tb_dbg_ad7606.v  --  短时间调试用: 把 CONVST/BUSY/CS/RD 的每次变化打出来
//=============================================================================
`timescale 1ns / 1ps

module tb_dbg_ad7606;

    // ★ 用 parameter 而不是 localparam, 这样可以在命令行覆盖, 用来做实验:
    //     vsim -gRD_LOW_CYC=1 -voptargs="+acc" -gui -do wave_ad7606.do work.tb_dbg_ad7606
    //   改成 1 之后你会亲眼看到"采样点比数据到达早一拍"长什么样
    parameter integer RD_LOW_CYC  = 3;
    parameter integer RD_HIGH_CYC = 2;

    localparam integer CLK_PERIOD = 20;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2.0) clk = ~clk;

    wire        convst, cs_n, rd_n, ad_reset;
    wire [15:0] db;
    wire        busy, frstdata;
    wire signed [15:0] sample_data;
    wire [2:0]         sample_ch;
    wire               sample_valid, frame_done, error_timeout;

    reg  src_step;
    wire signed [15:0] src_clean, src_code;
    wire [127:0] ch_flat;

    ad7606_if #(
        .CLK_FREQ    (50_000_000),
        .CONV_RATE   (100_000),
        .CONV_PULSE  (2),
        .RD_LOW_CYC  (RD_LOW_CYC),
        .RD_HIGH_CYC (RD_HIGH_CYC),
        .BUSY_TO_CYC (2000)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .convst(convst), .cs_n(cs_n), .rd_n(rd_n), .ad_reset(ad_reset),
        .db(db), .busy(busy), .frstdata(frstdata),
        .sample_data(sample_data), .sample_ch(sample_ch),
        .sample_valid(sample_valid), .frame_done(frame_done),
        .error_timeout(error_timeout)
    );

    ad7606_model #(
        .TCONV_NS(4000), .BUSY_DELAY_NS(40), .CLK_PERIOD_NS(CLK_PERIOD)
    ) u_adc (
        .clk(clk), .convst(convst), .cs_n(cs_n), .rd_n(rd_n), .ad_reset(ad_reset),
        .vin0(src_code), .vin1(16'sh1111), .vin2(16'sh2222), .vin3(16'sh3333),
        .vin4(16'sh4444), .vin5(16'sh5555), .vin6(16'sh6666), .vin7(16'sh7777),
        .db(db), .busy(busy), .frstdata(frstdata), .ch_flat(ch_flat)
    );

    pd_src #(.AMP(3000), .NOISE(40), .PERIOD(64), .SEED(32'hDEADBEEF)) u_src (
        .clk(clk), .rst_n(rst_n), .step(src_step), .clean(src_clean), .code(src_code)
    );

    reg convst_d2;
    always @(posedge clk) begin
        convst_d2 <= convst;
        src_step  <= convst & ~convst_d2;
    end

    // ---- 把状态机的数字编号翻译成人看得懂的名字 ----
    // 注意: 必须【右补空格到 8 字符】, 不能写 "IDLE" 就完事。
    // 因为 Verilog 里字符串赋值是右对齐的, "IDLE" 存进去高位全是 0x00,
    // 波形窗口按 ascii 显示时会变成 4 个空字符 + IDLE, 很难看。
    reg [8*8-1:0] state_name;
    always @* begin
        case (dut.state)
            3'd0: state_name = "IDLE    ";
            3'd1: state_name = "CONV    ";
            3'd2: state_name = "WAITBH  ";
            3'd3: state_name = "WAITBL  ";
            3'd4: state_name = "RDLOW   ";
            3'd5: state_name = "RDHIGH  ";
            3'd6: state_name = "DONE    ";
            default: state_name = "UNKNOWN ";
        endcase
    end

    // 信号变化就打一行 (带上升/下降沿标记)
    reg c_d, b_d, s_d, r_d;
    reg [2:0] st_d;
    reg error_timeout_d = 1'b0;

    // 量时间用的变量
    real t_busy_rise  = 0.0;
    real t_prev_convst = 0.0;
    integer convst_n = 0;
    real frame_period = 0.0;
    always @(posedge clk) begin
        c_d <= convst; b_d <= busy; s_d <= cs_n; r_d <= rd_n; st_d <= dut.state;
        if (convst !== c_d)  $display("[%0t] CONVST -> %b", $time, convst);

        // BUSY: 上升沿记开始时刻, 下降沿把宽度算出来打出去
        if (busy & ~b_d) begin
            t_busy_rise = $realtime;
            $display("[%0t] BUSY   -> 1                <<== 芯片开始转换", $time);
        end
        if (~busy & b_d) begin
            $display("[%0t] BUSY   -> 0                <<== 转换完成, 耗时 %0.1f ns (= 手册 tCONV)",
                     $time, $realtime - t_busy_rise);
        end

        // CONVST 上升沿: 算采样周期
        if (convst & ~c_d) begin
            convst_n = convst_n + 1;
            if (convst_n > 1) begin
                frame_period = $realtime - t_prev_convst;
                $display("[%0t]                            采样周期 = %0.1f ns  (采样率 %0.1f kHz)",
                         $time, frame_period, 1.0e6 / frame_period);
            end
            t_prev_convst = $realtime;
        end
        if (cs_n   !== s_d)  $display("[%0t] CS_n   -> %b", $time, cs_n);
        if (rd_n   !== r_d)  $display("[%0t] RD_n   -> %b   db=%04h", $time, rd_n, db);
        if (dut.state !== st_d) $display("[%0t] STATE  -> %0d ( %s )", $time, dut.state, state_name);
        if (sample_valid)    $display("[%0t]   >>> sample ch=%0d data=%04h", $time, sample_ch, sample_data);
        if (frame_done)      $display("[%0t]   >>> FRAME DONE", $time);
        if (error_timeout & ~error_timeout_d) $display("[%0t]   !!! ERROR_TIMEOUT", $time);
        error_timeout_d <= error_timeout;
    end

    initial begin
        // ★ 关键: 不设这个, %t 会用仿真精度(1ps)显示, 你会看到 [10370000] 这种数字。
        //   设了之后显示成 "  10370.000 ns", 一眼就知道是 10.37 微秒。
        $timeformat(-9, 3, " ns", 12);

        $display("=== 调试跟踪开始 ===");
        rst_n = 1'b0;
        #200;
        rst_n = 1'b1;
        #60000;                 // 只跑 60us
        $display("=== 跟踪结束, 当前 state=%0d ===", dut.state);
        $finish;
    end

endmodule

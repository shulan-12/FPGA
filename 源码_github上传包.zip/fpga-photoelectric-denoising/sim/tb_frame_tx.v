//=============================================================================
// tb_frame_tx.v  --  整机数据通路协议级自检
//-----------------------------------------------------------------------------
// 验证:
//   1) 两种帧类型都出现, 且按 0x01(原始) -> 0x02(滤波后) 成对交替
//   2) 每帧的同步头 / 长度 / 累加和 全部正确
//   3) ★ raw 和 flt 是否【时间对齐】—— 这条最关键
//        滤波器有 64 个样本的群延迟, top_demo 里把 raw 也延迟了 64 个样本去对齐。
//        如果延迟参数写错一个样本, 12.5kHz 抽点下正弦会错开 5.6 度,
//        残差 |raw-flt| 会从 ~20 LSB 暴涨到 ~293 LSB。
//        所以用一个阈值就能把"对齐对不对"卡出来。
//   4) 采样值都在合理范围内
//
// 顺带把原始字节流导出到 tools/frame_dump.bin, 供解码器做端到端验证。
//=============================================================================
`timescale 1ns / 1ps

module tb_frame_tx;

    //---------------- 参数 ----------------
    parameter integer CLK_FREQ    = 50_000_000;
    parameter integer BAUD        = 921600;
    parameter integer DEPTH       = 64;
    parameter integer NPAIRS      = 2;        // 收几对(原始+滤波)就够了
    parameter integer AMP         = 3000;
    parameter integer NOISE       = 40;
    parameter integer RESID_LIMIT = 200;      // |raw-flt| 平均值的上限 (对齐时约 20)

    localparam integer CLK_PERIOD = 20;
    localparam real    BIT_TIME   = CLK_PERIOD * (CLK_FREQ / BAUD);   // 54*20 = 1080 ns
    localparam integer LEN_EXPECT = DEPTH * 2;

    //---------------- 时钟/复位 ----------------
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2.0) clk = ~clk;

    //---------------- DUT ----------------
    wire led1, led2, uart_tx;

    top_demo #(
        .CLK_FREQ    (CLK_FREQ),
        .BAUD        (BAUD),
        .SAMPLE_RATE (100_000),
        .DECIM       (8),
        .DEPTH       (DEPTH),
        .FLT_DELAY   (64),
        .BLINK_DIV   (100),
        .AMP         (AMP),
        .NOISE       (NOISE),
        .PERIOD      (64)
    ) dut (
        .clk     (clk),
        .rst_n   (rst_n),
        .led1    (led1),
        .led2    (led2),
        .uart_tx (uart_tx)
    );

    //=========================================================================
    // UART 接收模型 (每位正中间采样)
    //=========================================================================
    reg [7:0] rx_byte;
    integer   k;

    task rx_one;
        begin
            @(negedge uart_tx);
            #(BIT_TIME * 1.5);
            for (k = 0; k < 8; k = k + 1) begin
                rx_byte[k] = uart_tx;
                #(BIT_TIME);
            end
            #(BIT_TIME * 0.5);
        end
    endtask

    //=========================================================================
    // 帧解析 + 比对
    //=========================================================================
    integer errors = 0;
    integer pairs  = 0;
    integer i, di;

    reg [7:0]  b;
    reg [7:0]  type_rx, len_rx, sum_rx, sum_calc;
    reg [15:0] seq_lo, seq_rx, seq_raw, last_seq;
    reg [7:0]  data [0:255];
    integer    state = 0;
    integer    seq_err = 0;       // 序号错(两帧不同号 / 不连续)
    integer    seq_lo_seen = 0;

    // 一帧完整的数据 (解码成有符号数)
    integer    samp [0:255];
    integer    n_samp;
    integer    raw_first;      // 1 = 下一帧应该是原始帧

    // 成对比较
    reg        have_raw = 0;
    integer    raw_samp [0:255];
    integer    n_raw;
    integer    resid_sum;
    integer    resid_max;
    integer    v;

    integer    dump_fd;
    initial dump_fd = $fopen("../tools/frame_dump.bin", "wb");

    integer    guard;

    initial begin
        $timeformat(-9, 3, " ns", 12);

        $display("=== tb_frame_tx : full data path protocol check ===");
        $display("  baud=%0d  depth=%0d  decim=8  -> 12.5 kSPS per stream", BAUD, DEPTH);
        $display("  expect frames: 0x01(raw) then 0x02(filtered), %0d pairs", NPAIRS);
        $display("");

        rst_n   = 1'b0;
        raw_first = 1;
        #200;
        rst_n = 1'b1;

        guard = 0;
        while (pairs < NPAIRS && errors == 0 && guard < 200000) begin
            rx_one;
            b = rx_byte;
            $fwrite(dump_fd, "%c", rx_byte);
            guard = guard + 1;

            case (state)
            0: if (b == 8'hAA) state = 1;
            1: begin
                   if (b == 8'h55) state = 2;
                   else if (b == 8'hAA) state = 1;
                   else state = 0;
               end
            2: begin type_rx = b; sum_calc = b; state = 3; end
            3: begin
                   len_rx = b; sum_calc = sum_calc + b; di = 0;
                   if (b != LEN_EXPECT[7:0]) begin
                       $display("[%0t] FAIL: length field=%0d expected %0d", $time, b, LEN_EXPECT);
                       errors = errors + 1;
                   end
                   state = 4;
               end
            //---- 序号 SEQ (小端) ----
            4: begin seq_lo = {8'd0, b}; sum_calc = sum_calc + b; state = 5; end
            5: begin seq_rx = {b, seq_lo[7:0]}; sum_calc = sum_calc + b; state = 6; end
            //---- 数据 ----
            6: begin
                   data[di] = b; sum_calc = sum_calc + b; di = di + 1;
                   if (di >= LEN_EXPECT) state = 7;
               end
            //---- 校验和 ----
            7: begin
                   sum_rx = b;
                   if (sum_calc !== sum_rx) begin
                       $display("[%0t] FAIL: checksum calc=%02h rx=%02h", $time, sum_calc, sum_rx);
                       errors = errors + 1;
                   end
                   else begin
                       // 解成有符号样本
                       for (i = 0; i < DEPTH; i = i + 1) begin
                           v = {data[i*2+1], data[i*2]};
                           if (v >= 32768) v = v - 65536;
                           samp[i] = v;
                           if (v > (AMP+NOISE) || v < -(AMP+NOISE)) begin
                               $display("[%0t] FAIL: sample[%0d]=%0d out of range", $time, i, v);
                               errors = errors + 1;
                           end
                       end

                       // ---- 类型检查 ----
                       if (type_rx == 8'h01) begin
                           if (!raw_first) begin
                               $display("[%0t] FAIL: got RAW frame but expected FILTERED", $time);
                               errors = errors + 1;
                           end
                           for (i = 0; i < DEPTH; i = i + 1) raw_samp[i] = samp[i];
                           n_raw     = DEPTH;
                           have_raw  = 1;
                           seq_raw   = seq_rx;      // ★ 记住原始帧的序号
                           raw_first = 0;
                           $display("[%0t] OK  : frame RAW        seq=%0d len=%0d csum=%02h", $time, seq_rx, len_rx, sum_rx);
                           $display("        raw  samples[8..15] = %0d %0d %0d %0d %0d %0d %0d %0d",
                                    samp[8],samp[9],samp[10],samp[11],samp[12],samp[13],samp[14],samp[15]);
                       end
                       else if (type_rx == 8'h02) begin
                           if (raw_first) begin
                               $display("[%0t] FAIL: got FILTERED frame but expected RAW", $time);
                               errors = errors + 1;
                           end
                           $display("[%0t] OK  : frame FILTERED   seq=%0d len=%0d csum=%02h", $time, seq_rx, len_rx, sum_rx);
                           $display("        flt  samples[8..15] = %0d %0d %0d %0d %0d %0d %0d %0d",
                                    samp[8],samp[9],samp[10],samp[11],samp[12],samp[13],samp[14],samp[15]);

                           // ---- ★ 序号检查: 两帧必须同号, 且跨轮递增 ----
                           if (seq_rx !== seq_raw) begin
                               $display("        FAIL: pair seq mismatch: raw=%0d filtered=%0d", seq_raw, seq_rx);
                               errors = errors + 1; seq_err = seq_err + 1;
                           end
                           if (pairs > 0 && seq_rx !== ((last_seq + 16'd1) & 16'hFFFF)) begin
                               $display("        WARN: seq not continuous: last=%0d now=%0d", last_seq, seq_rx);
                               seq_err = seq_err + 1;
                           end
                           last_seq = seq_rx;

                           // ---- ★ 成对: 检查 raw 与 flt 的时间对齐 ----
                           if (have_raw) begin
                               resid_sum = 0;
                               resid_max = 0;
                               for (i = 0; i < DEPTH; i = i + 1) begin
                                   v = raw_samp[i] - samp[i];
                                   if (v < 0) v = -v;
                                   resid_sum = resid_sum + v;
                                   if (v > resid_max) resid_max = v;
                               end
                               $display("        raw-flt residual: mean=%0d  max=%0d", resid_sum/DEPTH, resid_max);
                               $display("        (本项【只用来验证时间对齐】: 对齐时残差应 << 293,");
                               $display("         错开一个样本会到 ~293。残差里既有被滤掉的噪声, 也有滤波器");
                               $display("         在 1562.5Hz 处的通带增益偏差, 所以它不等于噪声大小。");
                               $display("         真正的降噪 dB 数要用 pc/ 那边的工具测。)");

                               if (resid_sum/DEPTH > RESID_LIMIT) begin
                                   $display("        FAIL: residual too big -> raw/flt NOT time aligned (check FLT_DELAY)");
                                   errors = errors + 1;
                               end
                               else begin
                                   $display("        OK  : raw and filtered are time-aligned");
                               end
                               have_raw = 0;
                               pairs    = pairs + 1;
                               raw_first = 1;
                           end
                       end
                       else begin
                           $display("[%0t] FAIL: unknown frame type %02h", $time, type_rx);
                           errors = errors + 1;
                       end
                   end
                   state = 0;
               end
            default: state = 0;
            endcase
        end

        $display("");
        $display("--- summary ---");
        $display("  frame pairs   = %0d / %0d", pairs, NPAIRS);
        $display("  seq errors    = %0d   (0 = the two frames of each pair share one seq)", seq_err);
        $display("  errors        = %0d", errors);
        $display("  frame length  = %0d bytes (6 header + %0d data + 1 checksum)",
                 6 + LEN_EXPECT + 1, LEN_EXPECT);
        $display("  raw bytes dumped to ../tools/frame_dump.bin");
        $fclose(dump_fd);
        $display("");
        if (errors == 0 && pairs == NPAIRS) $display("=== ALL CHECKS PASSED ===");
        else                                $display("=== FAILED ===");
        $finish;
    end

    // 看门狗
    initial begin
        #300_000_000;
        $display("FAIL: timeout - only %0d pairs received", pairs);
        $finish;
    end

endmodule

//=============================================================================
// tb_impulse_check.v  --  ★ 逐位验证: RTL 定点实现 == Python 定点模型
//-----------------------------------------------------------------------------
// 干什么:
//   喂给 denoise_filter 一个【冲激】信号(一个采样点是 32767, 其余全是 0),
//   把每一个 dout 按顺序写进 impulse_out.txt。
//   Python 那边用完全一样的整数算法算一遍, 逐个数比对 —— 必须【一模一样】。
//
// 为什么这个测试比"SNR 差不多"强得多:
//   SNR 是统计量, 两边噪声序列不同, 天然有 ±0.26 dB 的散差, 差 0.3 dB 说明不了对错。
//   冲激响应是【确定性的】: 它直接暴露每一级系数、抽头顺序、对齐关系、定点移位。
//   只要有一个抽头接错、错位一个周期、右移位数写错, 这里立刻逐位对不上。
//
// 冲激响应 = 系数本身: 输出[200+k] 应该等于 coef[k] * 32767 >> 15
//
// ★ 采样间隔必须 > 滤波器的 66 拍延迟, 否则前一个样本还没算完
//   下一个 din_valid 就来了, 样本会被丢掉。这里取 80 拍。
//=============================================================================
`timescale 1ns / 1ps

module tb_impulse_check;

    localparam integer CLK_PERIOD = 20;      // 50MHz
    localparam integer NSAMP      = 360;     // 送多少个样本
    localparam integer IMP_IDX    = 200;     // 冲激在第几个样本
    localparam integer IMP_AMP    = 32767;   // 冲激幅度
    localparam integer GAP        = 80;      // 采样间隔(拍), 必须 > 66

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD / 2.0) clk = ~clk;

    reg signed [15:0] din       = 16'sd0;
    reg               din_valid = 1'b0;
    reg [2:0]         din_ch    = 3'd0;
    wire signed [15:0] dout;
    wire               dout_valid;

    denoise_filter #(.DATA_W(16), .CH_SEL(0)) u_dut (
        .clk       (clk),
        .rst_n     (rst_n),
        .din       (din),
        .din_valid (din_valid),
        .din_ch    (din_ch),
        .dout      (dout),
        .dout_valid(dout_valid)
    );

    integer fd;
    integer k;
    integer ncap;
    integer errors;

    initial begin
        errors = 0;
        ncap   = 0;
        fd = $fopen("impulse_out.txt", "w");
        if (fd == 0) begin
            $display("FAIL: cannot open impulse_out.txt");
            errors = errors + 1;
            $finish;
        end

        $display("=== impulse response check: one spike of %0d at sample %0d ===",
                 IMP_AMP, IMP_IDX);

        rst_n = 1'b0;
        #200;
        rst_n = 1'b1;

        for (k = 0; k < NSAMP; k = k + 1) begin
            din       = (k == IMP_IDX) ? IMP_AMP[15:0] : 16'sd0;
            din_valid = 1'b1;
            @(posedge clk);
            din_valid = 1'b0;
            din       = 16'sd0;
            repeat (GAP - 1) @(posedge clk);
        end

        repeat (200) @(posedge clk);         // 等最后几拍的流水线出完

        $fclose(fd);
        $display("  captured %0d output samples (expected %0d)", ncap, NSAMP);
        if (ncap != NSAMP) begin
            $display("  FAIL: sample count mismatch (filter dropped or added samples)");
            errors = errors + 1;
        end
        else $display("  OK  : one in -> one out");
        $display("  wrote impulse_out.txt -- now run pc/step3_verify_rtl_impulse.py");
        $display("=== TB DONE (%0d problem(s)) ===", errors);
        $finish;
    end

    always @(posedge clk) begin
        if (rst_n && dout_valid) begin
            if (ncap < NSAMP) $fdisplay(fd, "%0d", dout);
            ncap = ncap + 1;
        end
    end

endmodule

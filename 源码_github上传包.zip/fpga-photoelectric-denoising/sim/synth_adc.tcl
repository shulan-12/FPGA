#=============================================================================
# 验证 ad7606_if.v 能不能综合 (纯 RTL, 不需要引脚约束)
# 跑法: vivado -mode batch -source synth_adc.tcl
#=============================================================================
create_project -in_memory -part xc7a35tfgg484-2

read_verilog ../rtl/ad7606_if.v

synth_design -top ad7606_if -part xc7a35tfgg484-2

puts "########## SYNTH OK ##########"
report_utilization -return_string
report_timing_summary -return_string

puts "########## DONE ##########"

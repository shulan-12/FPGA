//=============================================================================
// pd_src.v  --  "光电探测器 + 前置放大" 的仿真信号源 (假数据)
//-----------------------------------------------------------------------------
// 【只在仿真里用, 不上板】。它的任务是给滤波器和采集接口提供:
//     clean : 干净信号 (正弦, 模拟被调制的光信号)
//     code  : 干净信号 + 白噪声 (= 真实 ADC 会看到的带噪数字量)
//
// 为什么要造这个:
//   第 1-2 周 B 的滤波器还没定, 板子上的 AD 模块也没到。但滤波器的正确性
//   现在就能用假数据验证 —— 不用等人。
//
// 参数怎么调 (给 B 用):
//   AMP    : 信号幅度, 单位 LSB。±5V 量程下 1 LSB = 152.58uV, 所以 AMP=3000 约等于 ±458mV
//   NOISE  : 白噪声幅度, 单位 LSB (均匀分布)。改它就能扫不同 SNR
//   改变 SEED 可以得到统计上不同的噪声序列, 用来跑多次试验
//
// 输出都是二进制补码 (和 AD7606 的输出格式一致: AD7606 是 two's complement)
//=============================================================================
`timescale 1ns / 1ps

module pd_src #(
    parameter integer AMP   = 3000,          // 信号幅度 (LSB)
    parameter integer NOISE = 40,            // 噪声幅度 (LSB)
    parameter integer PERIOD = 64,           // 正弦一个周期多少个采样点
    parameter [31:0]  SEED  = 32'hDEAD_BEEF  // 噪声 LFSR 种子
)(
    input  wire               clk,
    input  wire               rst_n,
    input  wire               step,   // 采样节拍: 每来一个脉冲输出一组新值
    output reg signed [15:0]  clean,  // 干净信号
    output reg signed [15:0]  code    // 带噪信号 (给 ADC 当输入)
);

    //------------------------------------------------------------------
    // 64 点正弦表, 幅度 ±1024 (后续按 AMP/1024 缩放)
    //------------------------------------------------------------------
    reg signed [15:0] sine_lut [0:63];
    initial begin
        sine_lut[ 0]=  16'sd0;    sine_lut[ 1]= 16'sd100;  sine_lut[ 2]= 16'sd200;  sine_lut[ 3]= 16'sd297;
        sine_lut[ 4]= 16'sd392;   sine_lut[ 5]= 16'sd483;  sine_lut[ 6]= 16'sd569;  sine_lut[ 7]= 16'sd650;
        sine_lut[ 8]= 16'sd724;   sine_lut[ 9]= 16'sd792;  sine_lut[10]= 16'sd851;  sine_lut[11]= 16'sd903;
        sine_lut[12]= 16'sd946;   sine_lut[13]= 16'sd980;  sine_lut[14]=16'sd1004;  sine_lut[15]=16'sd1019;
        sine_lut[16]=16'sd1024;   sine_lut[17]=16'sd1019;  sine_lut[18]=16'sd1004;  sine_lut[19]= 16'sd980;
        sine_lut[20]= 16'sd946;   sine_lut[21]= 16'sd903;  sine_lut[22]= 16'sd851;  sine_lut[23]= 16'sd792;
        sine_lut[24]= 16'sd724;   sine_lut[25]= 16'sd650;  sine_lut[26]= 16'sd569;  sine_lut[27]= 16'sd483;
        sine_lut[28]= 16'sd392;   sine_lut[29]= 16'sd297;  sine_lut[30]= 16'sd200;  sine_lut[31]= 16'sd100;
        sine_lut[32]=  16'sd0;    sine_lut[33]=-16'sd100;  sine_lut[34]=-16'sd200;  sine_lut[35]=-16'sd297;
        sine_lut[36]=-16'sd392;   sine_lut[37]=-16'sd483;  sine_lut[38]=-16'sd569;  sine_lut[39]=-16'sd650;
        sine_lut[40]=-16'sd724;   sine_lut[41]=-16'sd792;  sine_lut[42]=-16'sd851;  sine_lut[43]=-16'sd903;
        sine_lut[44]=-16'sd946;   sine_lut[45]=-16'sd980;  sine_lut[46]=-16'sd1004; sine_lut[47]=-16'sd1019;
        sine_lut[48]=-16'sd1024;  sine_lut[49]=-16'sd1019; sine_lut[50]=-16'sd1004; sine_lut[51]=-16'sd980;
        sine_lut[52]=-16'sd946;   sine_lut[53]=-16'sd903;  sine_lut[54]=-16'sd851;  sine_lut[55]=-16'sd792;
        sine_lut[56]=-16'sd724;   sine_lut[57]=-16'sd650;  sine_lut[58]=-16'sd569;  sine_lut[59]=-16'sd483;
        sine_lut[60]=-16'sd392;   sine_lut[61]=-16'sd297;  sine_lut[62]=-16'sd200;  sine_lut[63]=-16'sd100;
    end

    //------------------------------------------------------------------
    // 噪声: 32bit LFSR (Xilinx XAPP052 抽头), 取低 8 位做均匀白噪声 ±128
    //------------------------------------------------------------------
    reg [31:0] lfsr;

    wire [31:0] lfsr_nxt = {lfsr[30:0], lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};

    wire signed [15:0] noise_u = $signed({1'b0, lfsr[7:0]}) - 16'sd128;  // -128 .. +127
    wire signed [31:0] noise_s = (noise_u * NOISE) >>> 7;                // 缩放到 ±NOISE

    //------------------------------------------------------------------
    // 相位累加器: 高 16 位当小数, 这样 PERIOD 取任何值都能精确走完一个正弦周期
    //   每步相位增量 = (64/PERIOD) 定点表示, 取 phase[21:16] 当 64 点表的索引
    localparam integer PHASE_INC = (64 * 65536) / PERIOD;

    reg [31:0] phase;
    wire [5:0] idx = phase[21:16];                     // 只要 64 点
    wire signed [31:0] clean_s = (sine_lut[idx] * AMP) >>> 10;   // 幅度 ±1024 -> ±AMP

    always @(posedge clk) begin
        if (!rst_n) begin
            lfsr  <= SEED;
            phase <= 32'd0;
            clean <= 16'sd0;
            code  <= 16'sd0;
        end
        else begin
            lfsr <= lfsr_nxt;
            if (step) begin
                // 相位步进: 让一个正弦周期恰好是 PERIOD 个采样点
                phase <= phase + PHASE_INC[31:0];
                clean <= clean_s[15:0];
                code  <= clean_s[15:0] + noise_s[15:0];
            end
        end
    end

endmodule

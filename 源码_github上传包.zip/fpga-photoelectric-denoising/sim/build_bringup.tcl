#=============================================================================
# AD7606 联调最小系统全流程: 综合 -> 实现 -> 时序 -> 比特流
# 目的: 验证 AX7035_ad7606_J10.xdc 里的每个引脚都真实可用
#=============================================================================
create_project -in_memory -part xc7a35tfgg484-2

read_verilog ../rtl/ad7606_if.v
read_verilog ../rtl/top_adc_bringup.v
read_xdc     ../constrs/AX7035_ad7606_J10.xdc

synth_design -top top_adc_bringup -part xc7a35tfgg484-2
puts "########## SYNTH DONE ##########"

opt_design
place_design
route_design
puts "########## IMPL DONE ##########"

report_timing_summary -delay_type min_max -check_timing_verbose

puts "########## IO PLACEMENT ##########"
foreach port [get_ports] {
    set p [get_ports $port]
    puts "  port $port -> [get_property -quiet PACKAGE_PIN $p] iostd=[get_property -quiet IOSTANDARD $p]"
}

puts "########## DRC ##########"
report_drc -return_string

puts "########## BITSTREAM ##########"
write_bitstream -force ../sim/ax7035_adc_bringup.bit
puts "########## ALL DONE ##########"

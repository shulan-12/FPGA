#=============================================================================
# AD7606 采集接口 + 含噪信号源 的 ModelSim 批量仿真脚本
#
# 在 sim 目录下依次执行:
#   vlib work_adc
#   vlog -work work_adc ..\rtl\ad7606_if.v .\pd_src.v .\ad7606_model.v .\tb_ad7606_if.v
#   vsim -c -work work_adc -do run_msim.tcl work_adc.tb_ad7606_if
#
# 想看波形 (调试握手时序很好用):
#   vsim -gui -work work_adc work_adc.tb_dbg_ad7606
#   然后把 convst / busy / cs_n / rd_n / db / dut.state 拖进波形窗口
#
# 短时间调试跟踪 (只打 60us, 把每次信号变化都打出来):
#   vlib work_dbg
#   vlog -work work_dbg ..\rtl\ad7606_if.v .\pd_src.v .\ad7606_model.v .\tb_dbg_ad7606.v
#   vsim -c -work work_dbg -do run_msim.tcl work_dbg.tb_dbg_ad7606
#=============================================================================
run -all
quit -f

# Generate QSPI flash image (.mcs) from the bitstream
# Flash: N25Q128, 128 Mbit = 16 MB, 3.3V, quad SPI
write_cfgmem -format MCS -interface SPIx4 -size 16 \
    -loadbit "up 0x0 ../sim/ax7035_adc_stream.bit" \
    -file ../sim/ax7035_adc_stream.mcs -force
puts "########## MCS DONE ##########"

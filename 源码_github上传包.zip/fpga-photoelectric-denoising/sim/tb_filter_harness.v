//=============================================================================
// tb_filter_harness.v  --  滤波器降噪效果验证台 (B 的主力工具)
//-----------------------------------------------------------------------------
// 它干什么:
//   1) 用 pd_src 造出"干净信号"和"干净信号+白噪声"
//   2) 同时跑【两个】denoise_filter 实例:
//        u_flt_n : 输入带噪信号
//        u_flt_c : 输入干净信号
//   3) 两个实例完全一样、延迟完全一样, 所以
//        dout_noisy - dout_clean  ==  被滤波器处理后的【纯噪声】
//      —— 这样就不需要去猜滤波器的群延迟、不需要做样本对齐, 测量是精确的
//   4) 分别统计输入 SNR 和输出 SNR, 打印【降噪增益】
//
// 为什么用两个实例而不是"延迟对齐":
//   滑动平均/中值/FIR 的群延迟各不相同, 如果靠人工把干净信号延迟几拍去对齐,
//   只要延迟猜错一个样本, 测出来的 SNR 就完全是错的。双实例法从根上避免了这个问题。
//
// B 要做的只有一件事: 改 denoise_filter.v 里的算法, 然后跑这个 tb 看增益。
//
// 注: 所有 $display 字符串都是 ASCII, 因为中文 Windows 的 ModelSim 控制台是
//     GBK 码页, 打 UTF-8 中文会变乱码。代码注释保持中文, 不影响编译。
//=============================================================================
`timescale 1ns / 1ps

module tb_filter_harness;

    //---------------- 参数 (B 可以随便调) ----------------
    localparam integer CLK_PERIOD  = 20;          // ns, 50MHz
    localparam integer SAMPLE_RATE = 100_000;     // Hz, 和 AD7606 采集率一致
    localparam integer NSAMP       = 4000;        // 统计多少个样本
    localparam integer SKIP        = 300;         // 跳过前多少个(滤波器启动瞬态)
    localparam integer SRC_AMP     = 3000;        // 信号幅度 LSB
    localparam integer SRC_NOISE   = 40;          // 噪声幅度 LSB
    localparam integer SRC_PERIOD  = 64;          // 正弦周期(采样点数)
    localparam [31:0]  SRC_SEED    = 32'hDEAD_BEEF;

    localparam integer DIV_MAX  = 50_000_000 / SAMPLE_RATE;
    localparam integer MAX_CLKS = 20_000_000;     // 主循环保护上限

    //---------------- 时钟/复位 ----------------
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2.0) clk = ~clk;

    //---------------- 采样节拍 ----------------
    reg [31:0] div_cnt;
    reg        step;
    always @(posedge clk) begin
        if (!rst_n) begin
            div_cnt <= 32'd0;
            step    <= 1'b0;
        end
        else if (div_cnt == DIV_MAX-1) begin
            div_cnt <= 32'd0;
            step    <= 1'b1;
        end
        else begin
            div_cnt <= div_cnt + 32'd1;
            step    <= 1'b0;
        end
    end

    // pd_src 的输出比 step 晚一拍, 所以滤波器要拿 step 的延迟版当 valid
    reg step_d;
    always @(posedge clk) step_d <= step;

    //---------------- 信号源 ----------------
    wire signed [15:0] clean, code;

    pd_src #(
        .AMP    (SRC_AMP),
        .NOISE  (SRC_NOISE),
        .PERIOD (SRC_PERIOD),
        .SEED   (SRC_SEED)
    ) u_src (
        .clk   (clk),
        .rst_n (rst_n),
        .step  (step),
        .clean (clean),
        .code  (code)
    );

    //---------------- 两个滤波器实例 (同一个模块, 只是喂不同输入) ----------------
    wire signed [15:0] dout_noisy, dout_clean;
    wire               v_noisy,    v_clean;

    denoise_filter #(.DATA_W(16), .CH_SEL(0)) u_flt_n (
        .clk(clk), .rst_n(rst_n),
        .din(code), .din_valid(step_d), .din_ch(3'd0),
        .dout(dout_noisy), .dout_valid(v_noisy)
    );

    denoise_filter #(.DATA_W(16), .CH_SEL(0)) u_flt_c (
        .clk(clk), .rst_n(rst_n),
        .din(clean), .din_valid(step_d), .din_ch(3'd0),
        .dout(dout_clean), .dout_valid(v_clean)
    );

    //---------------- 统计 ----------------
    integer in_cnt  = 0;
    integer out_cnt = 0;
    integer errors  = 0;

    real in_sig2  = 0.0, in_noi2  = 0.0;   // 输入端: 信号功率 / 噪声功率
    real out_sig2 = 0.0, out_noi2 = 0.0;   // 输出端

    integer c_val, n_val, os_val, on_val;

    real snr_in, snr_out, gain_db;

    // 输入端统计: 在滤波器实际采样的那一拍取数
    always @(posedge clk) begin
        if (rst_n && step_d) begin
            in_cnt = in_cnt + 1;
            if (in_cnt > SKIP && in_cnt <= SKIP + NSAMP) begin
                c_val = clean;
                n_val = code - clean;
                in_sig2 = in_sig2 + $itor(c_val) * $itor(c_val);
                in_noi2 = in_noi2 + $itor(n_val) * $itor(n_val);
            end
        end

        // 输出端统计: 两个实例的 valid 必须同步(同样的延迟), 不同步就是滤波器有 bug
        if (rst_n && v_noisy) begin
            if (v_noisy !== v_clean) begin
                $display("[%0t] FAIL: two filter instances' dout_valid are not in sync", $time);
                errors = errors + 1;
            end
            out_cnt = out_cnt + 1;
            if (out_cnt > SKIP && out_cnt <= SKIP + NSAMP) begin
                os_val = dout_clean;
                on_val = dout_noisy - dout_clean;
                out_sig2 = out_sig2 + $itor(os_val) * $itor(os_val);
                out_noi2 = out_noi2 + $itor(on_val) * $itor(on_val);
            end
        end
    end

    //---------------- 主流程 ----------------
    integer guard;

    initial begin
        $display("=== tb_filter_harness : denoise filter test bench ===");
        $display("  signal amp = %0d LSB, noise amp = %0d LSB, Fs = %0d Hz",
                 SRC_AMP, SRC_NOISE, SAMPLE_RATE);
        $display("  measuring %0d samples (skipping first %0d startup samples)", NSAMP, SKIP);
        $display("");

        rst_n = 1'b0;
        #200;
        rst_n = 1'b1;

        guard = 0;
        while (out_cnt < SKIP + NSAMP && guard < MAX_CLKS) begin
            @(posedge clk);
            guard = guard + 1;
        end

        if (out_cnt < SKIP + NSAMP) begin
            $display("FAIL: timeout, only got %0d output samples", out_cnt);
            errors = errors + 1;
        end

        //---------------- 结果 ----------------
        $display("--- SAMPLE COUNT (in must equal out) ---");
        $display("  input  samples = %0d", in_cnt);
        $display("  output samples = %0d", out_cnt);
        if (in_cnt != out_cnt) begin
            $display("  FAIL: sample count mismatch! filter dropped or added samples");
            errors = errors + 1;
        end
        else $display("  OK  : one in -> one out, sample rate unchanged");

        $display("");
        $display("--- DENOISE RESULT ---");
        if (in_noi2 <= 0.0 || out_noi2 <= 0.0) begin
            $display("  FAIL: noise power is zero, check source or filter");
            errors = errors + 1;
        end
        else begin
            snr_in  = 10.0 * $log10(in_sig2  / in_noi2);
            snr_out = 10.0 * $log10(out_sig2 / out_noi2);
            gain_db = snr_out - snr_in;

            $display("  input  signal RMS = %8.1f LSB", $sqrt(in_sig2  / $itor(NSAMP)));
            $display("  input  noise  RMS = %8.1f LSB", $sqrt(in_noi2  / $itor(NSAMP)));
            $display("  input  SNR        = %8.2f dB", snr_in);
            $display("");
            $display("  output signal RMS = %8.1f LSB", $sqrt(out_sig2 / $itor(NSAMP)));
            $display("  output noise  RMS = %8.1f LSB", $sqrt(out_noi2 / $itor(NSAMP)));
            $display("  output SNR        = %8.2f dB", snr_out);
            $display("");
            $display("  ===============================================");
            $display("  ** DENOISE GAIN = %8.2f dB **", gain_db);
            $display("  ===============================================");

            if (gain_db > 0.0) $display("  OK  : filter is actually reducing noise");
            else               $display("  NOTE: gain <= 0 -- filter not working or params wrong");
        end

        $display("");
        if (errors == 0) $display("=== HARNESS RAN CLEAN ===");
        else             $display("=== %0d PROBLEM(S) ===", errors);
        $finish;
    end

endmodule

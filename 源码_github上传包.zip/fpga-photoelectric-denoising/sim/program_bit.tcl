# ??? bit ? FPGA (JTAG)
set BIT "D:/deepseek/CODE/fpga_denoise/sim/ax7035_adc_stream.bit"
if {![file exists $BIT]} { puts "BIT_MISSING"; exit 1 }
open_hw
connect_hw_server -url localhost:3121
set ts [get_hw_targets]
if {[llength $ts] == 0} { puts "NO_TARGET"; exit 1 }
open_hw_target [lindex $ts 0]
current_hw_device [lindex [get_hw_devices] 0]
puts "DEVICE: [current_hw_device]"
set_property PROGRAM.FILE $BIT [current_hw_device]
if {[catch { program_hw_devices [current_hw_device] } e]} {
    puts "PGM_FAIL: $e"
} else {
    puts "PGM_OK"
}
close_hw_target
disconnect_hw_server
puts "########## DONE ##########"

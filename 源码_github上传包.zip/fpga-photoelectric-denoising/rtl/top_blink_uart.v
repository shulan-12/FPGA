//=============================================================================
// top_blink_uart.v  --  第 1-2 周"跑通板卡"用的最小顶层
//-----------------------------------------------------------------------------
// 它同时证明两件事:
//   1) led1 / led2 交替闪  -> 证明 时钟进来、综合/实现/下载全流程通
//   2) 串口每秒打印 HELLO -> 证明串口链路通, 第 3-4 周直接把数据往这条路上塞
// 两个功能写在一个顶层里, 不额外造模块 (能少一个文件就少一个)。
//-----------------------------------------------------------------------------
// 参数 SEND_DIV / BLINK_DIV 是为了"可仿真"才做成参数的:
//   上板用默认值(真实的 0.5s / 1s), 仿真时改小, 否则要跑几千万个时钟。
//=============================================================================
`timescale 1ns / 1ps

module top_blink_uart #(
    parameter integer CLK_FREQ  = 50_000_000,   // 板上晶振 50MHz
    parameter integer BAUD      = 115200,       // 串口波特率
    parameter integer BLINK_DIV = 25_000_000,   // 25e6/50e6 = 0.5s 翻转一次 -> 1Hz 闪烁
    parameter integer SEND_DIV  = 50_000_000    // 1s 发一轮 "HELLO\r\n"
)(
    input  wire clk,
    input  wire rst_n,      // 低有效复位 (按键)
    output wire led1,
    output wire led2,
    output wire uart_tx
);

    //-------------------------------------------------------------------------
    // 1. 心跳灯: 计数器数到 BLINK_DIV-1 就翻转一次
    //-------------------------------------------------------------------------
    reg [31:0] blink_cnt;
    reg        led_r;

    always @(posedge clk) begin
        if (!rst_n) begin
            blink_cnt <= 32'd0;
            led_r     <= 1'b0;
        end
        else if (blink_cnt == BLINK_DIV-1) begin
            blink_cnt <= 32'd0;
            led_r     <= ~led_r;
        end
        else begin
            blink_cnt <= blink_cnt + 32'd1;
        end
    end

    // ⚠️ ALINX AX7035 官方手册 Part21 原文:
    //   "When the IO voltage connected to the user LED is configured low level,
    //    the user LED lights up."
    //   → 板上 4 个用户 LED 是【低电平点亮】(共阳接法), 所以这里取反。
    //   (如果是 A7-Lite 那种高电平点亮的板子, 把这两行的 ~ 去掉即可)
    assign led1 = ~led_r;
    assign led2 =  led_r;   // 两个灯反相, 一眼看出都在动

    //-------------------------------------------------------------------------
    // 2. 要发的内容: 7 个字节 "HELLO\r\n"
    //    用 initial 初始化 ROM, Vivado 会综合成 LUT/BRAM 初值, ModelSim 也能跑。
    //-------------------------------------------------------------------------
    localparam integer MSG_LEN = 7;
    reg [7:0] msg [0:MSG_LEN-1];

    initial begin
        msg[0] = 8'h48;   // 'H'
        msg[1] = 8'h45;   // 'E'
        msg[2] = 8'h4C;   // 'L'
        msg[3] = 8'h4C;   // 'L'
        msg[4] = 8'h4F;   // 'O'
        msg[5] = 8'h0D;   // '\r'
        msg[6] = 8'h0A;   // '\n'
    end

    //-------------------------------------------------------------------------
    // 3. 发送调度: 每 SEND_DIV 个时钟启动一轮, 一轮里一个字节接一个字节发完
    //    (第 3-4 周把 msg[] 换成"滤波器输出缓存", 这段逻辑不用改)
    //-------------------------------------------------------------------------
    reg [31:0] send_timer;
    reg [3:0]  tx_idx;
    reg        tx_start;
    reg [7:0]  tx_data;
    reg        sending;
    wire       tx_busy;

    always @(posedge clk) begin
        if (!rst_n) begin
            send_timer <= 32'd0;
            tx_idx     <= 4'd0;
            tx_start   <= 1'b0;
            tx_data    <= 8'd0;
            sending    <= 1'b0;
        end
        else begin
            tx_start <= 1'b0;   // 默认拉低, 保证是单周期脉冲

            // 计时器只在"没在发"的时候走
            if (!sending) begin
                if (send_timer == SEND_DIV-1) begin
                    send_timer <= 32'd0;
                    sending    <= 1'b1;    // 启动一轮
                    tx_idx     <= 4'd0;
                end
                else begin
                    send_timer <= send_timer + 32'd1;
                end
            end

            // 发送器空着就喂下一个字节
            if (sending && !tx_busy && !tx_start) begin
                tx_start <= 1'b1;
                tx_data  <= msg[tx_idx];
                if (tx_idx == MSG_LEN-1) begin
                    sending <= 1'b0;       // 最后一个字节, 发完收工
                end
                else begin
                    tx_idx  <= tx_idx + 4'd1;
                end
            end
        end
    end

    //-------------------------------------------------------------------------
    // 4. 串口发送器例化
    //-------------------------------------------------------------------------
    uart_tx #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD     (BAUD)
    ) u_uart_tx (
        .clk      (clk),
        .rst_n    (rst_n),
        .tx_start (tx_start),
        .tx_data  (tx_data),
        .tx       (uart_tx),
        .tx_busy  (tx_busy)
    );

endmodule

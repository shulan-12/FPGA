//=============================================================================
// uart_tx.v  --  标准 8N1 异步串口发送器 (LSB first)
//-----------------------------------------------------------------------------
// 来源: 本项目自写。串口帧格式为行业通用约定 (起始位 1 bit 低 + 数据 8 bit + 停止位 1 bit 高),
//       非 Xilinx 专有 IP。任何时候都可以用别人的 USB-TTL 模块对接。
// 用途: 第 1-2 周先用它打印 "HELLO" 证明链路通; 第 3-4 周改用它把滤波前后的采样值发给上位机 B。
//-----------------------------------------------------------------------------
// 参数说明:
//   CLK_FREQ : 输入时钟频率(Hz), A7-Lite 板上是 50_000_000
//   BAUD     : 目标波特率, 默认 115200
// 分频比 DIV = CLK_FREQ / BAUD, 每个 bit 持续 DIV 个时钟。
// 例: 50MHz / 115200 = 434 (整数除法), 实际波特率 50e6/434 = 115207, 误差 0.006%, 可忽略。
//=============================================================================
`timescale 1ns / 1ps

module uart_tx #(
    parameter integer CLK_FREQ = 50_000_000,
    parameter integer BAUD     = 115200
)(
    input  wire       clk,
    input  wire       rst_n,      // 低有效复位
    input  wire       tx_start,   // 单周期脉冲 = 请求发送一个字节
    input  wire [7:0] tx_data,    // 待发送的字节, 必须与 tx_start 同拍有效
    output reg        tx,         // 串行输出线, 空闲态为高电平
    output reg        tx_busy     // 1 = 正在发送, 此时忽略 tx_start
);

    localparam integer DIV = CLK_FREQ / BAUD;   // 每个 bit 的时钟数

    reg [15:0] baud_cnt;   // 0 .. DIV-1, 数一个 bit 的时间
    reg [3:0]  bit_cnt;    // 0=起始位, 1..8=8个数据位, 9=停止位
    reg [9:0]  shifter;    // {停止位1, data[7:0], 起始位0}, 右移出去

    always @(posedge clk) begin
        if (!rst_n) begin
            baud_cnt <= 16'd0;
            bit_cnt  <= 4'd0;
            shifter  <= 10'h3FF;
            tx       <= 1'b1;      // 空闲高
            tx_busy  <= 1'b0;
        end
        else if (!tx_busy) begin
            // ---- 空闲: 等 tx_start ----
            baud_cnt <= 16'd0;
            bit_cnt  <= 4'd0;
            tx       <= 1'b1;
            if (tx_start) begin
                shifter <= {1'b1, tx_data, 1'b0};  // bit0=起始0, bit8:1=数据, bit9=停止1
                tx      <= 1'b0;                   // 起始位立刻拉低
                tx_busy <= 1'b1;
            end
        end
        else begin
            // ---- 发送中: 每 DIV 个时钟走一个 bit ----
            if (baud_cnt == DIV-1) begin
                baud_cnt <= 16'd0;
                if (bit_cnt == 4'd9) begin
                    tx      <= 1'b1;   // 停止位保持高
                    tx_busy <= 1'b0;   // 停止位走满一整位后释放
                    bit_cnt <= 4'd0;
                end
                else begin
                    shifter <= {1'b1, shifter[9:1]};  // 右移, 高位补1
                    tx      <= shifter[1];            // 送出下一个 bit
                    bit_cnt <= bit_cnt + 4'd1;
                end
            end
            else begin
                baud_cnt <= baud_cnt + 16'd1;
            end
        end
    end

endmodule

//=============================================================================
// capture_buf.v  --  双缓冲采集 (ping-pong)
//-----------------------------------------------------------------------------
// 解决什么问题:
//   AD7606 / 假数据源以 100 kHz 连续产出, 而串口慢得多。
//   如果"采一段 -> 停下来发 -> 再采一段", 发的时候数据就丢了,
//   PC 上拼出来的波形会在每个分界处跳变, 完全看不出正弦。
//
//   所以必须【采集不停】: 半缓冲 A 写满了就转去写 B, 同时把 A 发出去。
//   这就是 ping-pong (乒乓) 双缓冲。
//
// 抽点 (DECIM):
//   源 100 kHz, 每 DECIM 个样本才存 1 个。
//   ★ 抽点必须放在【滤波器之后】。因为 FIR 已经把信号带限到 3.5 kHz,
//     按 12.5 kHz 抽点不会混叠。这是标准的"先滤波后抽取"。
//     反过来先抽点再滤波, 高频噪声会折叠进带内, 滤波器就白做了。
//
// 两路数据:
//   raw = 原始带噪信号, flt = 滤波后信号。存在同一个 32bit 字里 {flt, raw},
//   保证两路严格同一时刻, PC 上能直接叠着看。
//=============================================================================
`timescale 1ns / 1ps

module capture_buf #(
    parameter integer DEPTH = 64,   // 每个半缓冲存多少个(抽点后的)样本
    parameter integer DECIM = 8     // 抽点比
)(
    input  wire               clk,
    input  wire               rst_n,

    // ---- 数据源 (同一拍有效) ----
    input  wire signed [15:0] raw_data,
    input  wire signed [15:0] flt_data,
    input  wire               data_valid,

    // ---- 读端口 (给发送端; 组合读, 无延迟) ----
    input  wire [6:0]         rd_addr,     // {half, sample_idx}
    output wire [31:0]        rd_data,     // {flt[15:0], raw[15:0]}

    // ---- 半缓冲状态 ----
    output wire               buf0_ready,  // 半 0 写满, 可发送
    output wire               buf1_ready,
    input  wire               buf0_release,// 发送完成, 释放
    input  wire               buf1_release,

    output reg                overflow     // 写满时上一半还没发出去 (正常不会发生)
);

    // 地址宽度: 2*DEPTH 个字
    // ★ 不要用 $clog2: Vivado 2017.4 在 localparam 里报
    //   "system function call clog2 is not allowed here"(仿真能过, 综合过不了)。
    //   自己写个 function 最省事, 而且 Verilog-2001 通用。
    function integer clog2;
        input integer value;
        integer i;
        begin
            clog2 = 0;
            for (i = value - 1; i > 0; i = i >> 1) clog2 = clog2 + 1;
        end
    endfunction

    localparam integer ADDR_W = clog2(2*DEPTH);
    localparam integer PTR_W  = clog2(DEPTH);

    reg [31:0] mem [0:2*DEPTH-1];

    reg [15:0]      dec_cnt;
    reg [PTR_W-1:0] wr_ptr;
    reg             wr_half;
    reg [1:0]       full;

    wire [ADDR_W-1:0] wr_addr = {wr_half, wr_ptr};
    wire [ADDR_W-1:0] rd_a    = rd_addr[ADDR_W-1:0];

    assign rd_data    = mem[rd_a];
    assign buf0_ready = full[0];
    assign buf1_ready = full[1];

    always @(posedge clk) begin
        if (!rst_n) begin
            dec_cnt  <= 16'd0;
            wr_ptr   <= {PTR_W{1'b0}};
            wr_half  <= 1'b0;
            full     <= 2'b00;
            overflow <= 1'b0;
        end
        else begin
            // 释放
            if (buf0_release) full[0] <= 1'b0;
            if (buf1_release) full[1] <= 1'b0;

            // 抽点 + 写入
            if (data_valid) begin
                if (dec_cnt == DECIM-1) begin
                    dec_cnt <= 16'd0;

                    if (full[wr_half]) begin
                        // 上一半还没发出去 -> 只能丢弃, 并置标志
                        // (以当前速率算: 写满一半 5.12ms, 发送只 2.9ms, 不会发生)
                        overflow <= 1'b1;
                    end
                    else begin
                        mem[wr_addr] <= {flt_data, raw_data};
                        if (wr_ptr == DEPTH-1) begin
                            wr_ptr  <= {PTR_W{1'b0}};
                            full[wr_half] <= 1'b1;
                            wr_half <= ~wr_half;
                        end
                        else begin
                            wr_ptr <= wr_ptr + 1'b1;
                        end
                    end
                end
                else begin
                    dec_cnt <= dec_cnt + 16'd1;
                end
            end
        end
    end

endmodule

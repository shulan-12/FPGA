//=============================================================================
// frame_tx.v  --  从采集缓冲读数据, 打包成串口帧发出去
//-----------------------------------------------------------------------------
// 帧格式 (和 handoff_to_B/README.md 完全一致):
//   偏移   长度   字段
//    0      1     0xAA
//    1      1     0x55
//    2      1     帧类型   0x01=原始信号  0x02=滤波后
//    3      1     数据长度 N  (只数数据字节, 当前 128)
//    4      2     序号 SEQ, 小端序
//    6      N     数据, 小端序, 每个采样点 16bit 有符号
//   6+N     1     累加和 (从"帧类型"到"数据"末字节, 取低8位)
//
// ★ SEQ 是【按采集轮次】递增的, 一轮的两帧(0x01 和 0x02)【共用同一个 SEQ】。
//   这样上位机可以三重校验:
//     ① 收到 0x01 后, 下一帧必须是 0x02   (配对)
//     ② 两帧的 SEQ 必须相同               (同一段采集)
//     ③ SEQ 必须连续递增 (允许被丢弃后跳号) (丢帧计数)
//   没有 SEQ 的话, 丢了一帧你从波形上根本看不出来是"真信号跳变"还是"传输丢帧"。
//   加这 2 字节的代价: 帧长 133 -> 135, 串口利用率 56.4% -> 57.3%, 可忽略。
//
//   每轮发【两帧】: 先 0x01 (原始) 再 0x02 (滤波后), 用的是同一段采集数据,
//   所以两路严格同一时刻 —— PC 上叠着画就能直接看出降噪效果。
//
// ★ 数据来源是 capture_buf 的双缓冲, 不是"边采边发"。
//   原因见 capture_buf.v 的注释: 串口比采集慢得多, 边采边发必然丢数据。
//=============================================================================
`timescale 1ns / 1ps

module frame_tx #(
    parameter integer CLK_FREQ = 50_000_000,
    parameter integer BAUD     = 921600,
    parameter integer DEPTH    = 64,        // 每帧多少个采样点
    parameter [7:0]   TYPE_RAW = 8'h01,
    parameter [7:0]   TYPE_FLT = 8'h02
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 到采集缓冲 ----
    output wire [6:0]  rd_addr,
    input  wire [31:0] rd_data,       // {flt[15:0], raw[15:0]}
    input  wire        buf0_ready,
    input  wire        buf1_ready,
    output reg         buf0_release,
    output reg         buf1_release,

    // ---- 串口 ----
    output wire        uart_tx,

    // ---- 观测 ----
    output reg         frame_done,    // 每发完一帧一个脉冲
    output reg         all_done       // 两帧(原始+滤波)都发完一个脉冲
);

    localparam integer HDR_BYTES   = 6;              // AA 55 TYPE LEN SEQ_L SEQ_H
    localparam integer DATA_BYTES  = DEPTH * 2;
    localparam integer TOTAL_BYTES = HDR_BYTES + DATA_BYTES + 1;

    localparam [2:0] S_IDLE=3'd0, S_PREP=3'd1, S_SEND=3'd2,
                     S_SENDW=3'd3, S_SENDD=3'd4, S_FSWAP=3'd5, S_REL=3'd6,
                     S_WREL=3'd7;   // 等释放真的生效 (避免同一缓冲被连发两次)

    reg [2:0]  st;
    reg        half;          // 当前读哪个半缓冲 (发送期间不变)
    reg        pass;          // 0=发原始帧, 1=发滤波后帧
    reg [15:0] byte_idx;
    reg [15:0] seq;           // 采集轮次序号, 一轮两帧共用
    reg [7:0]  csum;
    reg [7:0]  tx_byte;
    reg        tx_start;

    wire       tx_busy;

    // ---- 组合算出当前该读哪个样本 ----
    wire [15:0] idx_off = (byte_idx >= HDR_BYTES[15:0]) ? (byte_idx - HDR_BYTES[15:0]) : 16'd0;
    wire [5:0]  samp_k  = idx_off[6:1];                 // 第几个样本
    wire [6:0]  rd_a    = {half, samp_k};               // {半缓冲, 样本号}
    assign rd_addr = rd_a;

    wire signed [15:0] cur_sample = pass ? rd_data[31:16] : rd_data[15:0];

    // ---- 组合算出当前该发的字节 ----
    reg [7:0] cur_byte;
    always @* begin
        if (byte_idx == 16'd0)                       cur_byte = 8'hAA;
        else if (byte_idx == 16'd1)                  cur_byte = 8'h55;
        else if (byte_idx == 16'd2)                  cur_byte = pass ? TYPE_FLT : TYPE_RAW;
        else if (byte_idx == 16'd3)                  cur_byte = DATA_BYTES[7:0];
        else if (byte_idx == 16'd4)                  cur_byte = seq[7:0];
        else if (byte_idx == 16'd5)                  cur_byte = seq[15:8];
        else if (byte_idx < HDR_BYTES[15:0] + DATA_BYTES)
                                                     cur_byte = byte_idx[0] ? cur_sample[15:8]
                                                                            : cur_sample[7:0];
        else                                         cur_byte = csum;
    end

    // 这个字节要不要计入累加和 (帧类型 -> 数据末字节, 含 SEQ)
    wire is_summed = (byte_idx >= 16'd2) && (byte_idx < HDR_BYTES[15:0] + DATA_BYTES);

    always @(posedge clk) begin
        if (!rst_n) begin
            st           <= S_IDLE;
            half         <= 1'b0;
            pass         <= 1'b0;
            byte_idx     <= 16'd0;
            csum         <= 8'd0;
            seq          <= 16'd0;
            tx_byte      <= 8'd0;
            tx_start     <= 1'b0;
            buf0_release <= 1'b0;
            buf1_release <= 1'b0;
            frame_done   <= 1'b0;
            all_done     <= 1'b0;
        end
        else begin
            tx_start     <= 1'b0;
            buf0_release <= 1'b0;
            buf1_release <= 1'b0;
            frame_done   <= 1'b0;
            all_done     <= 1'b0;

            case (st)

            //-----------------------------------------------------------
            S_IDLE: begin
                if (buf0_ready || buf1_ready) begin
                    half     <= buf1_ready;      // 优先发半1
                    pass     <= 1'b0;
                    byte_idx <= 16'd0;
                    csum     <= 8'd0;
                    seq      <= seq + 16'd1;     // ★ 一轮采集一个号, 两帧共用
                    st       <= S_PREP;
                end
            end

            //-----------------------------------------------------------
            S_PREP: begin
                if (byte_idx >= TOTAL_BYTES) st <= S_FSWAP;
                else                         st <= S_SEND;
            end

            //-----------------------------------------------------------
            S_SEND: begin
                tx_byte <= cur_byte;
                if (is_summed) csum <= csum + cur_byte;
                tx_start <= 1'b1;
                st       <= S_SENDW;
            end

            //-----------------------------------------------------------
            S_SENDW: begin
                // uart_tx 要过一拍才把 tx_busy 拉起来, 必须等它真的忙了,
                // 否则会误判成"已发完"而立刻发下一个字节
                if (tx_busy) st <= S_SENDD;
            end

            //-----------------------------------------------------------
            S_SENDD: begin
                if (!tx_busy) begin
                    byte_idx <= byte_idx + 16'd1;
                    st       <= S_PREP;
                end
            end

            //-----------------------------------------------------------
            // 一帧发完: 先发原始(0x01), 再发滤波后(0x02), 同一段缓冲
            S_FSWAP: begin
                frame_done <= 1'b1;
                if (pass == 1'b0) begin
                    pass     <= 1'b1;
                    byte_idx <= 16'd0;
                    csum     <= 8'd0;
                    st       <= S_PREP;
                end
                else begin
                    st <= S_REL;
                end
            end

            //-----------------------------------------------------------
            S_REL: begin
                all_done <= 1'b1;
                if (half) buf1_release <= 1'b1;
                else      buf0_release <= 1'b1;
                st <= S_WREL;
            end

            //-----------------------------------------------------------
            // S_WREL: 等【刚释放的那个半缓冲】的 ready 真的掉成 0 再回 IDLE。
            //   ★ 这是必须的: buf_x_release 是寄存器输出, 要到下一拍 capture_buf
            //     才把 full[x] 清掉。若立刻回 S_IDLE, 会看到 ready 仍为 1,
            //     于是把同一个缓冲【再发一遍】—— 实测会导致约 43% 的重复帧。
            S_WREL: begin
                if (half) begin
                    if (!buf1_ready) st <= S_IDLE;
                end
                else begin
                    if (!buf0_ready) st <= S_IDLE;
                end
            end

            default: st <= S_IDLE;
            endcase
        end
    end

    //------------------------------------------------------------------
    uart_tx #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD     (BAUD)
    ) u_uart_tx (
        .clk      (clk),
        .rst_n    (rst_n),
        .tx_start (tx_start),
        .tx_data  (tx_byte),
        .tx       (uart_tx),
        .tx_busy  (tx_busy)
    );

endmodule

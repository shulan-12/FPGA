//=============================================================================
// denoise_filter.v  --  降噪滤波器 (B 交付版): 129 抽头对称线性相位 FIR
//-----------------------------------------------------------------------------
// 【接口完全按 A 定的, 一个字没改】
//
//   输入: din[15:0] 有符号(二进制补码) / din_valid 单周期脉冲 / din_ch 通道号
//   输出: dout[15:0] 有符号 / dout_valid 单周期脉冲
//   约定: 一个 din_valid 进 -> 一个 dout_valid 出, 不丢不多, 延迟固定
//   CH_SEL 之外的通道直接忽略(不产生 dout_valid)
//
//-----------------------------------------------------------------------------
// 设计参数 (来源: 电脑端 B 的实测选型, 见 pc/第1步_电脑端_含噪信号与FIR降噪.md)
//-----------------------------------------------------------------------------
//   类型    : Hamming 窗线性相位 FIR (Type-I, 抽头数为奇数)
//   抽头数  : 129  (阶数 128)
//   截止    : fc = 3500 Hz (-6dB 点), fs = 100 kHz
//   信号    : 1562.5 Hz, 落在通带内(通带边缘约 2221 Hz)
//   群延迟  : (N-1)/2 = 64 个采样点 = 0.640 ms  <- 实时显示的固有延迟
//   系数    : Q1.15 定点, 由 pc/step2_fixedpoint_and_coeffs.py 生成
//             (max|b| = 0.069986 -> 2293, 在 Q1.15 的 ±32767 范围内)
//
//-----------------------------------------------------------------------------
// 实现方案: 对称结构 + 时分复用 (1 个乘法器)
//-----------------------------------------------------------------------------
//   为什么不全并行: 全并行要 65 个 DSP48E1 (XC7A35T 一共才 90 个)。
//   而采样率只有 100 kHz, 50 MHz 时钟下每个样本有 500 拍可用,
//   做 65 次乘累加绰绰有余 -> 用时间换资源, 只占 1~2 个 DSP。
//
//   对称性: b[k] == b[TAPS-1-k], 所以一次算两个抽头:
//       acc = Σ_{k=0}^{MID-1} coef[k]*(sr[k] + sr[TAPS-1-k])  +  coef[MID]*sr[MID]
//   一共 MID+1 = 65 次乘累加。
//
//   延迟: din_valid 那一拍算起, 到 dout_valid 拉高, 共 66 拍。
//         ★ 这个延迟必须 < 500 拍(一个采样周期), 否则验证台的
//           "输入样本数 == 输出样本数" 检查会误报 FAIL。
//           本设计 66 拍, 余量 7.5 倍, 安全。
//
//   ★ 溢出保护不能省: max|H| = 1.002785 > 1 (由 step2 脚本实测),
//     满量程输入时累加结果会超出 16bit 范围, 直接截断会翻转符号,
//     在波形上表现为突发的反向尖刺。所以输出做饱和。
//     (本项目信号只有 ±3000 LSB, 饱和永远不会触发, 属于防御性设计)
//
//-----------------------------------------------------------------------------
// 三个使用约束 (写清楚, 免得以后踩)
//-----------------------------------------------------------------------------
//   1) 这个滤波器是【线性】的, 所以 A 的双实例法验证台有效。
//      如果以后换成中值滤波等【非线性】算法, 双实例法失效
//      (dout_noisy - dout_clean 不再等于"滤波后的噪声"), 测出来的增益是假的。
//   2) 改 TAPS 或 fc 时, 必须用 pc/step2_fixedpoint_and_coeffs.py 重新生成
//      下面的 coef[] 表, 不能只改参数 -- 系数和抽头数必须配套。
//   3) 时分复用一次只能服务【一个通道】(65 拍/样本)。若以后要同时滤 8 个通道,
//      500 拍不够 (8*65=520>500), 需要加第 2 个 MAC 单元或提高时钟。
//      现在只用一个光电探测器接 V1, CH_SEL=0, 不受影响。
//
//-----------------------------------------------------------------------------
// 参考来源
//-----------------------------------------------------------------------------
//   [1] scipy.signal.firwin 官方文档 (窗函数法设计线性相位 FIR)
//   [2] Oppenheim & Schafer, Discrete-Time Signal Processing, 3rd ed.,
//       5.7 节 (线性相位 FIR 群延迟 (N-1)/2), 7.4 节 (窗函数法)
//   [3] Q1.15 定点格式: 1 位符号 + 15 位小数, 可表示 [-1, 1-2^-15]
//=============================================================================
`timescale 1ns / 1ps

module denoise_filter #(
    parameter integer DATA_W = 16,      // 采样位宽 (接口定死 16)
    parameter integer TAPS   = 129,     // 抽头数, 必须和 coef[] 表配套
    parameter integer CH_SEL = 0        // 只处理这个通道
)(
    input  wire                     clk,
    input  wire                     rst_n,

    input  wire signed [DATA_W-1:0] din,
    input  wire                     din_valid,
    input  wire [2:0]               din_ch,

    output reg  signed [DATA_W-1:0] dout,
    output reg                      dout_valid
);

    localparam integer MID   = (TAPS - 1) / 2;   // 64
    localparam integer FRAC  = 15;               // Q1.15 的小数位数
    // 累加器位宽: 最坏情况 Σ|coef[k]| * 2 * 32768 ≈ 3.6e4 * 6.6e4 ≈ 2.4e9, 需要 33 位。
    // 取 40 位留足余量 (宽加法器不贵, 溢出翻转符号是灾难性的)。
    localparam integer ACC_W = 40;

    // 16bit 有符号的饱和边界
    localparam signed [DATA_W-1:0] SAT_MAX = {1'b0, {(DATA_W-1){1'b1}}};  // 32767
    localparam signed [DATA_W-1:0] SAT_MIN = {1'b1, {(DATA_W-1){1'b0}}};  // -32768

    //-------------------------------------------------------------------------
    // 滤波器系数 (Q1.15 整数)
    //   ★ 由 pc/step2_fixedpoint_and_coeffs.py 自动生成, 不要手改。
    //     源: firwin(numtaps=129, cutoff=3500, fs=100000, window='hamming')
    //     对称: coef[k] == coef[TAPS-1-k], 已逐项核对
    //-------------------------------------------------------------------------
    reg signed [15:0] coef [0:TAPS-1];

    initial begin
        coef[  0] = 16'sd13; coef[  1] = 16'sd13; coef[  2] = 16'sd12; coef[  3] = 16'sd11; coef[  4] = 16'sd9; coef[  5] = 16'sd7; coef[  6] = 16'sd3; coef[  7] = -16'sd1;
        coef[  8] = -16'sd5; coef[  9] = -16'sd11; coef[ 10] = -16'sd17; coef[ 11] = -16'sd23; coef[ 12] = -16'sd29; coef[ 13] = -16'sd34; coef[ 14] = -16'sd38; coef[ 15] = -16'sd41;
        coef[ 16] = -16'sd42; coef[ 17] = -16'sd41; coef[ 18] = -16'sd36; coef[ 19] = -16'sd28; coef[ 20] = -16'sd17; coef[ 21] = -16'sd2; coef[ 22] = 16'sd15; coef[ 23] = 16'sd35;
        coef[ 24] = 16'sd56; coef[ 25] = 16'sd77; coef[ 26] = 16'sd98; coef[ 27] = 16'sd116; coef[ 28] = 16'sd130; coef[ 29] = 16'sd139; coef[ 30] = 16'sd141; coef[ 31] = 16'sd135;
        coef[ 32] = 16'sd120; coef[ 33] = 16'sd96; coef[ 34] = 16'sd63; coef[ 35] = 16'sd21; coef[ 36] = -16'sd29; coef[ 37] = -16'sd85; coef[ 38] = -16'sd145; coef[ 39] = -16'sd205;
        coef[ 40] = -16'sd263; coef[ 41] = -16'sd314; coef[ 42] = -16'sd356; coef[ 43] = -16'sd384; coef[ 44] = -16'sd395; coef[ 45] = -16'sd385; coef[ 46] = -16'sd351; coef[ 47] = -16'sd293;
        coef[ 48] = -16'sd208; coef[ 49] = -16'sd96; coef[ 50] = 16'sd42; coef[ 51] = 16'sd204; coef[ 52] = 16'sd386; coef[ 53] = 16'sd586; coef[ 54] = 16'sd798; coef[ 55] = 16'sd1016;
        coef[ 56] = 16'sd1236; coef[ 57] = 16'sd1449; coef[ 58] = 16'sd1650; coef[ 59] = 16'sd1833; coef[ 60] = 16'sd1991; coef[ 61] = 16'sd2120; coef[ 62] = 16'sd2215; coef[ 63] = 16'sd2274;
        coef[ 64] = 16'sd2293; coef[ 65] = 16'sd2274; coef[ 66] = 16'sd2215; coef[ 67] = 16'sd2120; coef[ 68] = 16'sd1991; coef[ 69] = 16'sd1833; coef[ 70] = 16'sd1650; coef[ 71] = 16'sd1449;
        coef[ 72] = 16'sd1236; coef[ 73] = 16'sd1016; coef[ 74] = 16'sd798; coef[ 75] = 16'sd586; coef[ 76] = 16'sd386; coef[ 77] = 16'sd204; coef[ 78] = 16'sd42; coef[ 79] = -16'sd96;
        coef[ 80] = -16'sd208; coef[ 81] = -16'sd293; coef[ 82] = -16'sd351; coef[ 83] = -16'sd385; coef[ 84] = -16'sd395; coef[ 85] = -16'sd384; coef[ 86] = -16'sd356; coef[ 87] = -16'sd314;
        coef[ 88] = -16'sd263; coef[ 89] = -16'sd205; coef[ 90] = -16'sd145; coef[ 91] = -16'sd85; coef[ 92] = -16'sd29; coef[ 93] = 16'sd21; coef[ 94] = 16'sd63; coef[ 95] = 16'sd96;
        coef[ 96] = 16'sd120; coef[ 97] = 16'sd135; coef[ 98] = 16'sd141; coef[ 99] = 16'sd139; coef[100] = 16'sd130; coef[101] = 16'sd116; coef[102] = 16'sd98; coef[103] = 16'sd77;
        coef[104] = 16'sd56; coef[105] = 16'sd35; coef[106] = 16'sd15; coef[107] = -16'sd2; coef[108] = -16'sd17; coef[109] = -16'sd28; coef[110] = -16'sd36; coef[111] = -16'sd41;
        coef[112] = -16'sd42; coef[113] = -16'sd41; coef[114] = -16'sd38; coef[115] = -16'sd34; coef[116] = -16'sd29; coef[117] = -16'sd23; coef[118] = -16'sd17; coef[119] = -16'sd11;
        coef[120] = -16'sd5; coef[121] = -16'sd1; coef[122] = 16'sd3; coef[123] = 16'sd7; coef[124] = 16'sd9; coef[125] = 16'sd11; coef[126] = 16'sd12; coef[127] = 16'sd13;
        coef[128] = 16'sd13;
    end

    //-------------------------------------------------------------------------
    // 延迟线: sr[0] = 最新样本, sr[k] = k 个采样点之前的样本
    //-------------------------------------------------------------------------
    reg signed [DATA_W-1:0] sr [0:TAPS-1];

    reg                       busy;
    reg [7:0]                 mac_idx;      // 0 .. MID
    reg signed [ACC_W-1:0]    acc;
    integer                   i;

    //-------------------------------------------------------------------------
    // 组合逻辑: 当前这一拍的乘累加项
    //-------------------------------------------------------------------------
    wire signed [DATA_W:0]  pair_sum  = sr[mac_idx] + sr[TAPS-1-mac_idx];
    wire signed [ACC_W-1:0] term_pair = coef[mac_idx] * pair_sum;
    wire signed [ACC_W-1:0] term_mid  = coef[MID] * sr[MID];

    // mac_idx == MID 那一拍做中心抽头, 其它拍做对称对
    wire signed [ACC_W-1:0] acc_final = (mac_idx == MID[7:0]) ? (acc + term_mid)
                                                              : (acc + term_pair);
    // Q1.15 -> 整数 LSB: 算术右移 15 位 (对负数是向下取整, 和 Python 的 >> 一致)
    wire signed [ACC_W-1:0] y_shift   = acc_final >>> FRAC;
    // 饱和 (防御性: max|H| > 1, 满量程输入时会超范围)
    wire signed [DATA_W-1:0] y_sat    = (y_shift > SAT_MAX) ? SAT_MAX :
                                        (y_shift < SAT_MIN) ? SAT_MIN :
                                        y_shift[DATA_W-1:0];

    //-------------------------------------------------------------------------
    // 主状态机: 空闲 -> 移位+启动 -> 65 拍乘累加 -> 输出
    //-------------------------------------------------------------------------
    always @(posedge clk) begin
        if (!rst_n) begin
            busy       <= 1'b0;
            mac_idx    <= 8'd0;
            acc        <= {ACC_W{1'b0}};
            dout       <= {DATA_W{1'b0}};
            dout_valid <= 1'b0;
            for (i = 0; i < TAPS; i = i + 1) sr[i] <= {DATA_W{1'b0}};
        end
        else begin
            dout_valid <= 1'b0;                 // 默认拉低 (单周期脉冲)

            if (!busy) begin
                // 移位 + 启动。★ 这一拍不拿 sr[0] 当新样本, 所以移位后的
                // 下一拍起 sr[k] 才等于 x[n-k], 乘累加从 mac_idx=0 开始正好对上。
                if (din_valid && din_ch == CH_SEL[2:0]) begin
                    sr[0]   <= din;
                    for (i = 1; i < TAPS; i = i + 1) sr[i] <= sr[i-1];
                    acc     <= {ACC_W{1'b0}};
                    mac_idx <= 8'd0;
                    busy    <= 1'b1;
                end
            end
            else begin
                if (mac_idx == MID[7:0]) begin
                    // 中心抽头做完 -> 输出
                    busy       <= 1'b0;
                    dout       <= y_sat;
                    dout_valid <= 1'b1;
                end
                else begin
                    acc     <= acc + term_pair;
                    mac_idx <= mac_idx + 8'd1;
                end
            end
        end
    end

endmodule

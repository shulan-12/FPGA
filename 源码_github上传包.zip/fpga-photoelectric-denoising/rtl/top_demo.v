//=============================================================================
// top_demo.v  --  整机数据通路 (带降噪对比) 顶层
//-----------------------------------------------------------------------------
// 完整链路:
//
//   ┌──────────┐ 100kHz ┌────────────────┐ flt  ┌──────────────┐
//   │ fake_src │───────>│ denoise_filter │─────>│              │
//   │ 假数据源  │        │ (B 交付的 FIR)  │      │ capture_buf  │ ping-pong
//   └────┬─────┘        └────────────────┘      │  双缓冲       │
//        │ raw                ▲                 │ {flt, raw}   │
//        └──[64样本延迟对齐]───┘                 └──────┬───────┘
//                                                       │
//                                              ┌────────▼────────┐
//                                              │    frame_tx     │
//                                              │ 轮流发 0x01/0x02 │
//                                              └────────┬────────┘
//                                                       ▼  串口
//
// 【为什么要加那个 64 样本延迟】
//   滤波器有 64 个样本的群延迟。如果不把 raw 也延迟 64 个样本,
//   存进缓冲的 raw[i] 和 flt[i] 就差着 64 个样本 —— PC 上叠着画会看到
//   两条曲线错开一大截, 根本没法对比降噪效果。
//
// 【为什么必须用双缓冲】
//   源以 100 kHz 连续产出, 串口慢得多。边采边发必然丢数据,
//   PC 上拼出来的波形会在分界处跳变。ping-pong 让采集不停。
//
// 【抽点放在滤波器之后】
//   100 kHz -> 12.5 kHz 抽点(÷8)。FIR 已把信号带限到 3.5 kHz,
//   按 12.5 kHz 抽不会混叠。反过来先抽点会把高频噪声折进带内, 滤波器白做。
//
// 引脚和 top_blink_uart 一样, 复用 AX7035_led_uart.xdc。
//=============================================================================
`timescale 1ns / 1ps

module top_demo #(
    parameter integer CLK_FREQ       = 50_000_000,
    parameter integer BAUD           = 921600,
    parameter integer SAMPLE_RATE    = 100_000,   // 源采样率 (匹配 B 的滤波器设计)
    parameter integer DECIM          = 8,         // 抽点比 -> 12.5 kHz
    parameter integer DEPTH          = 64,        // 每帧采样点数
    parameter integer FLT_DELAY      = 64,        // 滤波器群延迟(样本数), 用于对齐 raw
    parameter integer BLINK_DIV      = 25_000_000,
    parameter integer AMP            = 3000,
    // ★ 噪声幅度 (LSB)。这个值直接决定"降噪效果肉眼看得到看不到"。
    //   B 在 pc/out/step4_demo_visible.png 里实测过:
    //     NOISE=40   -> SNR 39.2 dB (占信号 0.77%)  -> 原始/滤波后两条线几乎重合, 看不出效果
    //     NOISE=400  -> SNR ~19 dB   (占信号 7.7%)   -> 能看出区别       <- 现在的默认值
    //     NOISE=1200 -> SNR 9.7 dB   (占信号 23%)    -> 对比一目了然
    //   想和 B 的电脑端仿真对齐就改回 40; 想给评委看得见就用 400~1200。
    //   上板实测时, 真实噪声水平由前端(OPT101 增益/LED 距离)决定,
    //   要先用示波器/上位机确认【原始曲线上噪声肉眼可见】, 再谈滤波效果。
    parameter integer NOISE          = 400,
    parameter integer PERIOD         = 64         // 正弦周期(源采样点), 100kHz/64 = 1562.5 Hz
)(
    input  wire clk,
    input  wire rst_n,
    output wire led1,
    output wire led2,
    output wire uart_tx
);

    //-------------------------------------------------------------------------
    // 1. 采样节拍: 100 kHz
    //-------------------------------------------------------------------------
    localparam integer TICK_DIV = CLK_FREQ / SAMPLE_RATE;

    reg [15:0] tick_cnt;
    reg        tick;

    always @(posedge clk) begin
        if (!rst_n) begin
            tick_cnt <= 16'd0;
            tick     <= 1'b0;
        end
        else if (tick_cnt == TICK_DIV-1) begin
            tick_cnt <= 16'd0;
            tick     <= 1'b1;
        end
        else begin
            tick_cnt <= tick_cnt + 16'd1;
            tick     <= 1'b0;
        end
    end

    //-------------------------------------------------------------------------
    // 2. 心跳灯 (AX7035 LED 低电平点亮)
    //-------------------------------------------------------------------------
    reg [31:0] blink_cnt;
    reg        led_r;

    always @(posedge clk) begin
        if (!rst_n) begin
            blink_cnt <= 32'd0;
            led_r     <= 1'b0;
        end
        else if (blink_cnt == BLINK_DIV-1) begin
            blink_cnt <= 32'd0;
            led_r     <= ~led_r;
        end
        else blink_cnt <= blink_cnt + 32'd1;
    end

    assign led1 = ~led_r;
    assign led2 =  led_r;

    //-------------------------------------------------------------------------
    // 3. 假数据源 (每 tick 前进一个样本)
    //-------------------------------------------------------------------------
    wire signed [15:0] src_sample;

    fake_src #(
        .AMP    (AMP),
        .NOISE  (NOISE),
        .PERIOD (PERIOD)
    ) u_src (
        .clk    (clk),
        .rst_n  (rst_n),
        .next   (tick),
        .sample (src_sample)
    );

    //-------------------------------------------------------------------------
    // 4. raw 延迟线: 把原始信号延迟 FLT_DELAY 个样本, 和滤波器输出对齐
    //-------------------------------------------------------------------------
    reg [15:0] raw_dly [0:FLT_DELAY];
    integer    j;

    always @(posedge clk) begin
        if (!rst_n) begin
            for (j = 0; j <= FLT_DELAY; j = j + 1) raw_dly[j] <= 16'sd0;
        end
        else if (tick) begin
            raw_dly[0] <= src_sample;
            for (j = 1; j <= FLT_DELAY; j = j + 1) raw_dly[j] <= raw_dly[j-1];
        end
    end

    wire signed [15:0] raw_aligned = raw_dly[FLT_DELAY];

    //-------------------------------------------------------------------------
    // 5. 降噪滤波器 (B 交付)
    //-------------------------------------------------------------------------
    wire signed [15:0] flt_data;
    wire               flt_valid;

    denoise_filter #(
        .DATA_W (16),
        .TAPS   (129),
        .CH_SEL (0)
    ) u_filter (
        .clk        (clk),
        .rst_n      (rst_n),
        .din        (src_sample),
        .din_valid  (tick),
        .din_ch     (3'd0),
        .dout       (flt_data),
        .dout_valid (flt_valid)
    );

    //-------------------------------------------------------------------------
    // 6. 启动屏蔽 (warm-up)
    //    滤波器有 129 个抽头的历史, 延迟线还要 64 个样本才填满。
    //    这段时间的输出是垃圾(第一帧前 8 个样本全是 0)。
    //    所以在前面 WARMUP 个样本内不让采集, 第一帧就干净了。
    //-------------------------------------------------------------------------
    localparam integer WARMUP = 256;   // 样本数, 要 > 抽头数 + 延迟(129+64=193)

    reg [15:0] warm_cnt;
    reg        warm_done;

    always @(posedge clk) begin
        if (!rst_n) begin
            warm_cnt  <= 16'd0;
            warm_done <= 1'b0;
        end
        else if (!warm_done && tick) begin
            if (warm_cnt == WARMUP-1) warm_done <= 1'b1;
            else                      warm_cnt  <= warm_cnt + 16'd1;
        end
    end

    wire cap_valid = flt_valid & warm_done;

    //-------------------------------------------------------------------------
    // 7. 双缓冲采集 (两路同一时刻)
    //-------------------------------------------------------------------------
    wire [6:0]  rd_addr;
    wire [31:0] rd_data;
    wire        buf0_ready, buf1_ready;
    wire        buf0_release, buf1_release;
    wire        overflow;

    capture_buf #(
        .DEPTH (DEPTH),
        .DECIM (DECIM)
    ) u_cap (
        .clk          (clk),
        .rst_n        (rst_n),
        .raw_data     (raw_aligned),
        .flt_data     (flt_data),
        .data_valid   (cap_valid),
        .rd_addr      (rd_addr),
        .rd_data      (rd_data),
        .buf0_ready   (buf0_ready),
        .buf1_ready   (buf1_ready),
        .buf0_release (buf0_release),
        .buf1_release (buf1_release),
        .overflow     (overflow)
    );

    //-------------------------------------------------------------------------
    // 8. 帧发送
    //-------------------------------------------------------------------------
    wire frame_done, all_done;

    frame_tx #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD     (BAUD),
        .DEPTH    (DEPTH),
        .TYPE_RAW (8'h01),
        .TYPE_FLT (8'h02)
    ) u_frame_tx (
        .clk          (clk),
        .rst_n        (rst_n),
        .rd_addr      (rd_addr),
        .rd_data      (rd_data),
        .buf0_ready   (buf0_ready),
        .buf1_ready   (buf1_ready),
        .buf0_release (buf0_release),
        .buf1_release (buf1_release),
        .uart_tx      (uart_tx),
        .frame_done   (frame_done),
        .all_done     (all_done)
    );

endmodule

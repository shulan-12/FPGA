//=============================================================================
// top_adc_stream.v  --  真实 ADC 采集 + 串口输出  (前端联调 / 交给 C 的测试流)
//-----------------------------------------------------------------------------
// 和 top_demo 的区别就一处:
//     top_demo     : fake_src (片上假正弦+假噪声)  -- 用来验证数字通路
//     top_adc_stream: ad7606_if (真实 AD7606)      -- 用来验证【前端光电链路】
//
// 完整链路:
//
//   ┌───────────┐100kSPS┌────────┐ch0 ┌────────────────┐ flt  ┌──────────────┐
//   │ AD7606    │───────>│ 只取   │───>│ denoise_filter │─────>│              │
//   │ (J10 并行)│  8通道 │ ch0    │    │ (B 交付的 FIR)  │      │ capture_buf  │
//   └─────┬─────┘        └────────┘    └────────────────┘      │  ping-pong   │
//         │ raw                 ▲                             │  {flt, raw}  │
//         └───[64 样本延迟对齐]──┘                              └──────┬───────┘
//                                                                      │
//                                                             ┌────────▼────────┐
//                                                             │    frame_tx     │
//                                                             │ 轮流发 0x01/0x02│
//                                                             └────────┬────────┘
//                                                                      ▼  串口 921600
//
//-----------------------------------------------------------------------------
// ★ 为什么【只把通道 0】喂给滤波器 (这一条不能改)
//-----------------------------------------------------------------------------
//   ad7606_if 一轮转换吐出 8 个通道的样本, 8 通道 => 800 kSamples/s。
//   而 denoise_filter 是【时分复用】的, 每个样本要 65 拍才能算完:
//       100 kHz 时: 一个样本有 500 拍可用  -> 65 < 500  OK
//       8 通道时  : 8*65 = 520 拍 > 500 拍 -> 溢出, 滤波器会丢样本
//   B 在 denoise_filter.v 的注释里也明确写了这个限制。
//   我们的前端只有一个 OPT101 接在 V1 (通道 0), 所以只取 ch0 是【正确且必要】的。
//   抽点(÷8)之后输出 12.5 kHz, 8 点/周期 @1.5625kHz ---- 若调制频率改为 1 kHz,
//   则每周期 12.5 个点, 仍然够画正弦。
//
//-----------------------------------------------------------------------------
// ★ 三个 LED 的含义 (给现场调试用, 不接电脑也能判断)
//-----------------------------------------------------------------------------
//   LED1 : 1 Hz 慢闪          -> FPGA 在跑 (和 ADC 无关, 先看这个)
//   LED2 : 约 3 Hz 中速闪      -> 每转换完一轮翻一次, 证明 ADC 正在被正常读
//   LED3 : 常亮 = 正常          -> error_timeout 没触发
//          约 10 Hz 快闪 = 故障 -> BUSY 一直不动, 查 STBY/SER/CONVST/BUSY 接线
//
//   (AX7035 的 LED 是【低电平点亮】, 本文件里已经全部取反)
//=============================================================================
`timescale 1ns / 1ps

module top_adc_stream #(
    parameter integer CLK_FREQ    = 50_000_000,
    parameter integer BAUD        = 921600,
    parameter integer CONV_RATE   = 100_000,      // AD7606 转换速率
    parameter integer DECIM       = 8,            // 抽点比 -> 12.5 kHz
    parameter integer DEPTH       = 64,           // 每帧采样点数
    parameter integer FLT_DELAY   = 64,           // 滤波器群延迟(样本), 用于对齐 raw
    parameter integer BLINK_DIV   = 25_000_000,   // 1 Hz 心跳
    parameter integer TAPS        = 129,          // 必须和 denoise_filter 的系数表配套
    parameter integer OS_SET      = 0,            // 过采样档位: 0=不启用
    // 模块配置脚电平 (见《AD7606 数据采集模块使用说明》3.1(2) 与 表8)
    parameter integer STBY_LEVEL  = 1,            // STBY 必须为 1, 否则芯片待机
    parameter integer SER_LEVEL   = 0,            // SER(PAR/SER/BYTESEL) = 0 -> 并行接口
    // ---- 1 kHz 正弦调制光源输出 (mod_out) ----
    parameter integer MOD_FREQ    = 1_000,        // 调制频率 Hz
    parameter integer PWM_FREQ    = 100_000,      // PWM 载波频率 Hz (外部 RC 滤成正弦)
    parameter integer MOD_AMP_PCT = 60            // 调制深度 %, 0=恒亮, 95=接近满幅
)(
    input  wire        clk,
    input  wire        rst_n,

    output wire        led1,
    output wire        led2,
    output wire        led3,
    output wire        uart_tx,

    // ---- 1 kHz 正弦调制输出 -> 外部 RC(1k/10nF) -> LED 驱动 ----
    output wire        mod_out,

    // ---- AD7606 (经 J10 扩展口) ----
    output wire        ad_convst,     // -> 模块丝印 CO-A
    output wire        ad_convst_b,   // -> 模块丝印 CO-B
    output wire        ad_cs_n,       // -> 模块丝印 CS_N
    output wire        ad_rd_n,       // -> 模块丝印 RD/SC
    output wire        ad_reset,      // -> 模块丝印 RESET
    output wire [2:0]  ad_os,         // -> 模块丝印 OS0/OS1/OS2
    output wire        ad_stby,       // -> 模块丝印 STBY   (恒 1)
    output wire        ad_ser,        // -> 模块丝印 SER    (恒 0)
    input  wire [15:0] ad_db,         // <- 模块丝印 DB0~DB15
    input  wire        ad_busy,       // <- 模块丝印 BUSY
    input  wire        ad_frstdata    // <- 模块丝印 FR-D
);

    //-------------------------------------------------------------------------
    // 1. 心跳灯 1 Hz
    //-------------------------------------------------------------------------
    reg [31:0] blink_cnt;
    reg        led_r;

    always @(posedge clk) begin
        if (!rst_n) begin
            blink_cnt <= 32'd0;
            led_r     <= 1'b0;
        end
        else if (blink_cnt == BLINK_DIV-1) begin
            blink_cnt <= 32'd0;
            led_r     <= ~led_r;
        end
        else begin
            blink_cnt <= blink_cnt + 32'd1;
        end
    end

    //-------------------------------------------------------------------------
    // 2. AD7606 采集控制器  (上电自带 RESET 脉冲, 见 ad7606_if 注释)
    //-------------------------------------------------------------------------
    wire signed [15:0] sample_data;
    wire [2:0]         sample_ch;
    wire               sample_valid;
    wire               ad_frame_done;
    wire               error_timeout;

    ad7606_if #(
        .CLK_FREQ    (CLK_FREQ),
        .CONV_RATE   (CONV_RATE),
        .OS_SET      (OS_SET),
        .STBY_LEVEL  (STBY_LEVEL),
        .SER_LEVEL   (SER_LEVEL)
    ) u_adc (
        .clk           (clk),
        .rst_n         (rst_n),
        .convst        (ad_convst),
        .convst_b      (ad_convst_b),
        .cs_n          (ad_cs_n),
        .rd_n          (ad_rd_n),
        .ad_reset      (ad_reset),
        .os            (ad_os),
        .stby          (ad_stby),
        .ser           (ad_ser),
        .db            (ad_db),
        .busy          (ad_busy),
        .frstdata      (ad_frstdata),
        .sample_data   (sample_data),
        .sample_ch     (sample_ch),
        .sample_valid  (sample_valid),
        .frame_done    (ad_frame_done),
        .error_timeout (error_timeout)
    );

    //-------------------------------------------------------------------------
    // 3. 只保留通道 0  (理由见文件头注释, 不能去掉)
    //-------------------------------------------------------------------------
    wire ch0_valid = sample_valid & (sample_ch == 3'd0);

    //-------------------------------------------------------------------------
    // 4. raw 延迟线: 把原始信号延迟 FLT_DELAY 个样本, 与滤波器输出对齐
    //    滤波器群延迟 64 个样本, 不延迟的话 PC 上叠图画出来会错开一大截。
    //-------------------------------------------------------------------------
    reg [15:0] raw_dly [0:FLT_DELAY];
    integer    j;

    always @(posedge clk) begin
        if (!rst_n) begin
            for (j = 0; j <= FLT_DELAY; j = j + 1) raw_dly[j] <= 16'sd0;
        end
        else if (ch0_valid) begin
            raw_dly[0] <= sample_data;
            for (j = 1; j <= FLT_DELAY; j = j + 1) raw_dly[j] <= raw_dly[j-1];
        end
    end

    wire signed [15:0] raw_aligned = raw_dly[FLT_DELAY];

    //-------------------------------------------------------------------------
    // 5. 降噪滤波器 (B 交付, 129 抽头 Hamming 低通, fc = 3.5 kHz)
    //-------------------------------------------------------------------------
    wire signed [15:0] flt_data;
    wire               flt_valid;

    denoise_filter #(
        .DATA_W (16),
        .TAPS   (TAPS),
        .CH_SEL (0)
    ) u_filter (
        .clk        (clk),
        .rst_n      (rst_n),
        .din        (sample_data),
        .din_valid  (ch0_valid),
        .din_ch     (3'd0),
        .dout       (flt_data),
        .dout_valid (flt_valid)
    );

    //-------------------------------------------------------------------------
    // 6. 启动屏蔽 (warm-up)
    //    滤波器有 TAPS 个抽头的历史, 延迟线还要 FLT_DELAY 个样本才填满,
    //    这段时间输出是垃圾。前面 WARMUP 个样本内不让采集, 第一帧就干净。
    //-------------------------------------------------------------------------
    localparam integer WARMUP = 256;   // 要 > TAPS + FLT_DELAY (129+64=193)

    reg [15:0] warm_cnt;
    reg        warm_done;

    always @(posedge clk) begin
        if (!rst_n) begin
            warm_cnt  <= 16'd0;
            warm_done <= 1'b0;
        end
        else if (!warm_done && ch0_valid) begin
            if (warm_cnt == WARMUP-1) warm_done <= 1'b1;
            else                      warm_cnt  <= warm_cnt + 16'd1;
        end
    end

    wire cap_valid = flt_valid & warm_done;

    //-------------------------------------------------------------------------
    // 7. 双缓冲采集 (raw 与 flt 同一时刻写入)
    //-------------------------------------------------------------------------
    wire [6:0]  rd_addr;
    wire [31:0] rd_data;
    wire        buf0_ready, buf1_ready;
    wire        buf0_release, buf1_release;
    wire        overflow;

    capture_buf #(
        .DEPTH (DEPTH),
        .DECIM (DECIM)
    ) u_cap (
        .clk          (clk),
        .rst_n        (rst_n),
        .raw_data     (raw_aligned),
        .flt_data     (flt_data),
        .data_valid   (cap_valid),
        .rd_addr      (rd_addr),
        .rd_data      (rd_data),
        .buf0_ready   (buf0_ready),
        .buf1_ready   (buf1_ready),
        .buf0_release (buf0_release),
        .buf1_release (buf1_release),
        .overflow     (overflow)
    );

    //-------------------------------------------------------------------------
    // 8. 帧发送 (135 字节/帧, 921600 8N1)
    //-------------------------------------------------------------------------
    wire frame_done, all_done;

    frame_tx #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD     (BAUD),
        .DEPTH    (DEPTH),
        .TYPE_RAW (8'h01),
        .TYPE_FLT (8'h02)
    ) u_frame_tx (
        .clk          (clk),
        .rst_n        (rst_n),
        .rd_addr      (rd_addr),
        .rd_data      (rd_data),
        .buf0_ready   (buf0_ready),
        .buf1_ready   (buf1_ready),
        .buf0_release (buf0_release),
        .buf1_release (buf1_release),
        .uart_tx      (uart_tx),
        .frame_done   (frame_done),
        .all_done     (all_done)
    );

    //-------------------------------------------------------------------------
    // 9. 1 kHz 正弦调制光源输出 (给 LED 驱动用)
    //    输出的是 100 kHz PWM, 占空比按 1 kHz 正弦变化;
    //    外部一级 RC (1k + 10nF, fc≈16kHz) 滤成模拟正弦电流 -> 驱动 LED。
    //    这样整个系统不需要外部信号发生器, 演示时自带调制源。
    //-------------------------------------------------------------------------
    mod_gen #(
        .CLK_FREQ (CLK_FREQ),
        .MOD_FREQ (MOD_FREQ),
        .PWM_FREQ (PWM_FREQ),
        .AMP_PCT  (MOD_AMP_PCT)
    ) u_mod (
        .clk     (clk),
        .rst_n   (rst_n),
        .mod_out (mod_out)
    );

    //-------------------------------------------------------------------------
    // 10. 三个指示灯 (低电平点亮)
    //-------------------------------------------------------------------------
    // LED2: 真正的"数据活动"指示
    //   - 60 ms 内有帧       -> 约 3 Hz 中速闪
    //   - 60 ms 内一帧都没有 -> 灭
    //   ★ 加这个看门狗是因为: 原来直接用 conv_cnt[14], 计数器一旦停在某个值上
    //     LED 就会"常亮", 看起来像在正常工作, 其实早就停了 —— 会误判。
    reg [31:0] conv_cnt;
    reg [23:0] wd_cnt;          // 帧看门狗

    always @(posedge clk) begin
        if (!rst_n)             conv_cnt <= 32'd0;
        else if (ad_frame_done) conv_cnt <= conv_cnt + 32'd1;
    end

    always @(posedge clk) begin
        if (!rst_n)                    wd_cnt <= 24'd0;
        else if (ad_frame_done)        wd_cnt <= 24'd0;
        else if (wd_cnt != 24'hFFFFFF) wd_cnt <= wd_cnt + 24'd1;
    end

    wire data_active = (wd_cnt < 24'd3_000_000);   // 3e6 x 20ns = 60 ms

    // LED3: 正常工作常亮; 当前有超时错误则约 10 Hz 快闪
    //   ★ error_timeout 现在"成功一次就自动清零", 所以 LED3 反映的是【现在】的状态。
    reg [31:0] err_cnt;
    reg        err_tog;

    always @(posedge clk) begin
        if (!rst_n) begin
            err_cnt <= 32'd0;
            err_tog <= 1'b0;
        end
        else if (err_cnt == (CLK_FREQ/20)-1) begin   // 每 50 ms 翻一次 -> 10 Hz
            err_cnt <= 32'd0;
            err_tog <= ~err_tog;
        end
        else begin
            err_cnt <= err_cnt + 32'd1;
        end
    end

    assign led1 = ~led_r;                                  // 1 Hz 慢闪
    assign led2 = data_active ? ~conv_cnt[14] : 1'b1;      // 有帧才闪, 没帧就灭
    assign led3 = error_timeout ? ~err_tog : 1'b0;         // 常亮 = 正常 / 快闪 = 故障

endmodule

//=============================================================================
// ad7606_if.v  --  AD7606 并行模式采集接口控制器
//-----------------------------------------------------------------------------
// 干什么:
//   0) 上电后先给 AD7606 一个 RESET 脉冲 (手册要求 RESET 高电平 >= 50ns)
//   1) 按设定速率给 AD7606 一个 CONVST 脉冲, 启动一次转换
//   2) 等 BUSY 拉高(转换开始) 再等 BUSY 拉低(转换结束, 数据就绪)
//   3) 拉低 CS, 然后连续给 8 个 RD 脉冲, 把 V1~V8 八个通道的 16bit 数据读回来
//   4) 每读到一个通道就吐一个 sample_valid 脉冲; 八个读完吐一个 frame_done
//
// 接口时序依据:
//   AD7606 数据手册 (Analog Devices, Rev.0) 并行读时序图
//   - CONVST 上升沿 -> BUSY 拉高 -> 转换 tCONV -> BUSY 拉低 -> 数据可读
//   - CS 低 + RD 低 -> DB[15:0] 输出当前通道; 每个 RD 下降沿切换到下一个通道
//   - FRSTDATA 高表示总线上是第一个通道
//   ★ 本模块【不需要知道 tCONV 具体是多少】, 它只等 BUSY 下降沿, 所以对不同型号
//     (AD7606 / AD7606-4 / AD7606-6) 和不同过采样设置都自动适配。
//
// 错误处理 (不能省):
//   BUSY 因硬件故障一直不动时, 没有超时的话状态机会死等, 整个采集链停摆。
//   这里超时 -> 拉 error_timeout 并回 IDLE 重试。
//=============================================================================
`timescale 1ns / 1ps

module ad7606_if #(
    parameter integer CLK_FREQ     = 50_000_000,  // 输入时钟 Hz
    parameter integer CONV_RATE    = 100_000,     // 目标采样率 Hz (AD7606 上限 200k)
    parameter integer CONV_PULSE   = 2,           // CONVST 高电平持续时钟数 (需 >=25ns)
    parameter integer RD_LOW_CYC   = 3,           // RD 低电平持续时钟数 (数据有效窗口)
    parameter integer RD_HIGH_CYC  = 2,           // RD 高电平持续时钟数
    parameter integer AD_RESET_CYC = 6400,        // 复位脉冲宽度 (6400*20ns=128us, 手册下限50ns, 加长更保险)
    parameter integer BUSY_TO_CYC  = 2000,        // BUSY 等待超时 (默认 40us @50MHz)
    // ★ 过采样倍率档位 (AD7606 手册 OS[2:0] 编码):
    //     0=不启用, 1=2x, 2=4x, 3=8x, 4=16x, 5=32x, 6=64x
    //   档位越大信噪比越好, 但【转换时间 tCONV 会变长】。
    //   本模块只等 BUSY 下降沿, 所以倍率变了它自动适配 —— 但 BUSY_TO_CYC 要够长,
    //   否则会误报超时。启用高倍率后请实测 BUSY 宽度再定这个参数。
    parameter integer OS_SET       = 0,
    // ★ 模块级配置脚 (依据《AD7606 数据采集模块使用说明》3.1(2)(3) 与 表8)
    //   STBY : 必须为【高电平】, 否则芯片进入待机/关断模式 -> BUSY 永不动作, 采不到数。
    //   SER  : 即芯片的 PAR/SER/BYTESEL。表8: SER=0 且 DB15=0 -> 并行接口模式。
    //   这两个脚在这块模块上是引出到排针的, 由 FPGA 主动驱动,
    //   不去赌模块上的上下拉电阻究竟接在哪一边。
    parameter integer STBY_LEVEL   = 1,   // 1 = 正常工作(必须)
    parameter integer SER_LEVEL    = 0,   // 0 = 并行接口(必须)
    // ★ 自愈: 连续这么多次超时, 就自动给 AD7606 补发一次复位脉冲
    parameter integer TO_RETRY     = 4
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 到 AD7606 的物理连线 ----
    output reg         convst,      // 转换启动 -> AD7606 的 CONVSTA
    // ★ AD7606 有【两个】转换启动脚: CONVSTA 管 V1~V4, CONVSTB 管 V5~V8。
    //   两根必须同时拉高, 8 个通道才是【同一瞬间】采样。
    //   两种接法:
    //     ① 模块侧把 A/B 短接, FPGA 只出一根 —— 需要在模块上焊线
    //     ② FPGA 出两根, 各接各的针       —— 本模块用这种, 不用动烙铁
    //   两根由同一个寄存器驱动, 同一拍翻转, 引脚间偏差 < 2ns,
    //   远小于 AD7606 对 CONVSTA/B 的同步要求。
    output wire        convst_b,    // 第二根转换启动 -> AD7606 的 CONVSTB (与 convst 同相)
    output reg         cs_n,        // 片选 (低有效)
    output reg         rd_n,        // 读选通 (低有效)
    output reg         ad_reset,    // AD7606 复位 (高有效)
    output wire [2:0]  os,          // 过采样倍率选择 (OS2/OS1/OS0)
    output wire        stby,        // 待机控制 -> 模块丝印 STBY   (常量, 必须 1)
    output wire        ser,         // 接口模式 -> 模块丝印 SER    (常量, 必须 0 = 并行)
    input  wire [15:0] db,          // 16bit 并行数据总线
    input  wire        busy,        // 转换中标志 (高 = 忙)
    input  wire        frstdata,    // 首通道标志 (本模块仅用于调试观察)

    // ---- 给后级(滤波器/串口)的数据流 ----
    output reg signed [15:0] sample_data,   // 当前通道的采样值 (二进制补码)
    output reg [2:0]         sample_ch,     // 当前通道号 0..7
    output reg               sample_valid,  // 单周期脉冲: 本拍 sample_data/ch 有效
    output reg               frame_done,    // 单周期脉冲: 八个通道全部读完
    output reg               error_timeout  // 超时锁存标志 (只置位, 由 rst_n 清)
);

    // 过采样档位是静态配置, 常量化即可
    assign os = OS_SET[2:0];

    // 待机 / 接口模式: 静态常量输出。
    // 用 != 0 而不是直接取 bit, 避免 integer 位选引起的综合告警。
    assign stby = (STBY_LEVEL != 0);   // 恒为 1: 芯片正常工作
    assign ser  = (SER_LEVEL  != 0);   // 恒为 0: 并行接口模式

    // CONVSTB 与 CONVSTA 同相 (同一寄存器, 同一拍翻转)
    assign convst_b = convst;


    localparam integer CONV_DIV = CLK_FREQ / CONV_RATE;   // 两次转换之间的时钟数

    localparam [2:0] S_IDLE    = 3'd0;   // 等采样节拍
    localparam [2:0] S_CONV    = 3'd1;   // 发 CONVST 脉冲
    localparam [2:0] S_WAIT_BH = 3'd2;   // 等 BUSY 拉高
    localparam [2:0] S_WAIT_BL = 3'd3;   // 等 BUSY 拉低(转换完成)
    localparam [2:0] S_RD_LOW  = 3'd4;   // RD 低, 数据有效
    localparam [2:0] S_RD_HIGH = 3'd5;   // RD 高, 切下一通道
    localparam [2:0] S_DONE    = 3'd6;   // 一帧结束
    localparam [2:0] S_RESET   = 3'd7;   // 连续超时后自动补发 AD7606 复位 (自愈)

    reg [2:0]  state;
    reg [31:0] rate_cnt;
    reg [15:0] pulse_cnt;
    reg [15:0] dcnt;
    reg [31:0] tout;
    reg [2:0]  ch;
    reg [15:0] init_cnt;
    reg        init_done;
    reg [15:0] rst_cnt;          // S_RESET 里的复位脉宽计数
    reg [3:0]  to_cnt;           // 连续超时次数 (成功一次就清零)
    reg        busy_s0, busy_s1; // BUSY 两级同步器 (异步输入规范处理)

    // BUSY 是异步输入, 必须打两拍再用, 否则可能采到亚稳态。
    wire busy_s = busy_s1;

    always @(posedge clk) begin
        if (!rst_n) begin
            busy_s0 <= 1'b0;
            busy_s1 <= 1'b0;
        end
        else begin
            busy_s0 <= busy;
            busy_s1 <= busy_s0;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            state         <= S_IDLE;
            rate_cnt      <= 32'd0;
            pulse_cnt     <= 16'd0;
            dcnt          <= 16'd0;
            tout          <= 32'd0;
            ch            <= 3'd0;
            init_cnt      <= 16'd0;
            rst_cnt       <= 16'd0;
            to_cnt        <= 4'd0;
            init_done     <= 1'b0;
            convst        <= 1'b0;
            cs_n          <= 1'b1;
            rd_n          <= 1'b1;
            ad_reset      <= 1'b1;      // ★ 上电即拉高, 开始复位脉冲
            sample_data   <= 16'sd0;
            sample_ch     <= 3'd0;
            sample_valid  <= 1'b0;
            frame_done    <= 1'b0;
            error_timeout <= 1'b0;
        end
        else if (!init_done) begin
            //-------------------------------------------------------------
            // 上电初始化: 给 AD7606 一个 RESET 高脉冲, 期间不发任何采样
            //-------------------------------------------------------------
            sample_valid <= 1'b0;
            frame_done   <= 1'b0;
            state        <= S_IDLE;
            convst       <= 1'b0;
            cs_n         <= 1'b1;
            rd_n         <= 1'b1;
            ad_reset     <= 1'b1;
            if (init_cnt == AD_RESET_CYC-1) begin
                init_done <= 1'b1;
                ad_reset  <= 1'b0;      // 复位脉冲结束, 放开 AD7606
            end
            else begin
                init_cnt <= init_cnt + 16'd1;
            end
        end
        else begin
            // 默认拉低脉冲型输出
            sample_valid <= 1'b0;
            frame_done   <= 1'b0;
            ad_reset     <= 1'b0;

            //-------------------------------------------------------------
            // 转换间隔计数器: 自由自增, 不受状态机影响, 只在发起转换那一拍清零。
            // ★ 第一版把它放在 S_IDLE 里数, 结果"转换+读取"的时间被额外加到周期上,
            //   实测采样率变成 67kHz 而不是 100kHz。计数器必须覆盖整个周期。
            //-------------------------------------------------------------
            if (state == S_IDLE && rate_cnt == CONV_DIV-1) begin
                rate_cnt <= 32'd0;
            end
            else begin
                rate_cnt <= rate_cnt + 32'd1;
            end

            case (state)

            //-------------------------------------------------------------
            S_IDLE: begin
                cs_n   <= 1'b1;
                rd_n   <= 1'b1;
                convst <= 1'b0;
                if (rate_cnt == CONV_DIV-1) begin
                    convst    <= 1'b1;          // 启动一次转换
                    pulse_cnt <= CONV_PULSE-1;
                    state     <= S_CONV;
                end
            end

            //-------------------------------------------------------------
            S_CONV: begin
                if (pulse_cnt == 16'd0) begin
                    convst <= 1'b0;
                    tout   <= 32'd0;
                    state  <= S_WAIT_BH;
                end
                else begin
                    pulse_cnt <= pulse_cnt - 16'd1;
                end
            end

            //-------------------------------------------------------------
            S_WAIT_BH: begin
                if (busy_s) begin
                    tout  <= 32'd0;
                    state <= S_WAIT_BL;
                end
                else if (tout == BUSY_TO_CYC-1) begin
                    // BUSY 一直不拉高 -> 硬件有问题。累计超时次数,
                    // 到 TO_RETRY 次就补发一次 AD7606 复位 (自愈)。
                    error_timeout <= 1'b1;
                    tout          <= 32'd0;
                    to_cnt        <= to_cnt + 4'd1;
                    if (to_cnt >= TO_RETRY-1) begin
                        rst_cnt <= 16'd0;
                        state   <= S_RESET;
                    end
                    else begin
                        state <= S_IDLE;
                    end
                end
                else begin
                    tout <= tout + 32'd1;
                end
            end

            //-------------------------------------------------------------
            S_WAIT_BL: begin
                if (!busy_s) begin
                    cs_n  <= 1'b0;              // 开始读
                    rd_n  <= 1'b0;
                    ch    <= 3'd0;
                    dcnt  <= RD_LOW_CYC-1;
                    state <= S_RD_LOW;
                end
                else if (tout == BUSY_TO_CYC-1) begin
                    error_timeout <= 1'b1;
                    tout          <= 32'd0;
                    to_cnt        <= to_cnt + 4'd1;
                    if (to_cnt >= TO_RETRY-1) begin
                        rst_cnt <= 16'd0;
                        state   <= S_RESET;
                    end
                    else begin
                        state <= S_IDLE;
                    end
                end
                else begin
                    tout <= tout + 32'd1;
                end
            end

            //-------------------------------------------------------------
            // S_RESET: 连续超时后自动给 AD7606 补一次复位脉冲 (自愈)
            //   现场没人一直盯着按复位按钮, 所以芯片万一锁死要能自己恢复。
            S_RESET: begin
                ad_reset <= 1'b1;
                convst   <= 1'b0;
                cs_n     <= 1'b1;
                rd_n     <= 1'b1;
                if (rst_cnt == AD_RESET_CYC-1) begin
                    ad_reset <= 1'b0;
                    rst_cnt  <= 16'd0;
                    to_cnt   <= 4'd0;
                    state    <= S_IDLE;
                end
                else begin
                    rst_cnt <= rst_cnt + 16'd1;
                end
            end

            //-------------------------------------------------------------
            // RD 保持低 -> 数据有效。在 RD 上升沿之前把数据采下来。
            S_RD_LOW: begin
                if (dcnt == 16'd0) begin
                    sample_data  <= db;         // ★ 采样点: RD 上升沿前一刻
                    sample_ch    <= ch;
                    sample_valid <= 1'b1;
                    rd_n         <= 1'b1;
                    dcnt         <= RD_HIGH_CYC-1;
                    state        <= S_RD_HIGH;
                end
                else begin
                    dcnt <= dcnt - 16'd1;
                end
            end

            //-------------------------------------------------------------
            S_RD_HIGH: begin
                if (dcnt == 16'd0) begin
                    if (ch == 3'd7) begin
                        cs_n  <= 1'b1;          // 八个通道读完, 释放片选
                        state <= S_DONE;
                    end
                    else begin
                        ch    <= ch + 3'd1;
                        rd_n  <= 1'b0;          // 下一个通道
                        dcnt  <= RD_LOW_CYC-1;
                        state <= S_RD_LOW;
                    end
                end
                else begin
                    dcnt <= dcnt - 16'd1;
                end
            end

            //-------------------------------------------------------------
            S_DONE: begin
                frame_done    <= 1'b1;
                // ★ 成功读完一轮 = 当前一切正常, 把故障标志和超时计数清零。
                //   这样 error_timeout 表示的是【现在有没有故障】, 而不是"曾经错过一次"。
                error_timeout <= 1'b0;
                to_cnt        <= 4'd0;
                state         <= S_IDLE;
            end

            default: state <= S_IDLE;
            endcase
        end
    end

endmodule

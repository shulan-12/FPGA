//=============================================================================
// mod_gen.v  --  1 kHz 正弦调制发生器 (DDS + 高频 PWM, 给 LED 驱动用)
//-----------------------------------------------------------------------------
// 干什么:
//   产生一个 1 kHz 的正弦"亮度指令", 但输出的是【PWM 波形】,
//   外部用一级 RC 低通滤成模拟正弦电流去驱动 LED。
//
// 为什么不用 1 kHz 方波直接驱动 LED:
//   方波含 3k/5k/7k 谐波。FIR 截止 3.5 kHz, 3 kHz 那条【滤不掉】, 5k/7k 被滤掉
//   -> 滤波后的波形是"1k + 残存 3k", 形状歪, 看起来像"滤波器把信号弄坏了"。
//   用 PWM 载波 + RC 滤波得到的是【真正弦】, 1 kHz 单频, 完整通过 FIR。
//
// 为什么载波选 100 kHz:
//   50 MHz / 100 kHz = 500 级 PWM 分辨率, 够细;
//   载波 100 kHz 远离 1 kHz 调制频率, RC 一级就能压掉 (fc 取 10~20 kHz)。
//   1 kHz 调制的周期里有 100 个 PWM 周期, 正弦包络足够平滑。
//
// 外部接法 (C 负责):
//   mod_out ──[R1 1kΩ]──┬── 三极管基极 (或直接串 LED + 限流电阻)
//                       │
//                    [C1 10nF]
//                       │
//                      GND
//   R1*C1 决定 RC 截止: 1k*10nF -> fc ≈ 15.9 kHz  (通 1 kHz, 压 100 kHz)
//
// 调制深度: AMP_PCT=0 输出恒定 50% 占空比(无调制, 恒亮);
//           AMP_PCT=100 满幅正弦(占空比 0~100%)
//=============================================================================
`timescale 1ns / 1ps

module mod_gen #(
    parameter integer CLK_FREQ = 50_000_000,   // 输入时钟
    parameter integer MOD_FREQ = 1_000,        // 调制频率 Hz
    parameter integer PWM_FREQ = 100_000,      // PWM 载波频率 Hz
    parameter integer AMP_PCT  = 60            // 调制深度 %, 0~95
)(
    input  wire clk,
    input  wire rst_n,
    output reg  mod_out
);

    //-------------------------------------------------------------------------
    // 1. DDS 相位累加器: 每拍加 PHASE_INC, 溢出一次 = 一个调制周期
    //    PHASE_INC = MOD_FREQ * 2^32 / CLK_FREQ
    //-------------------------------------------------------------------------
    localparam [31:0] PHASE_INC = (MOD_FREQ * 64'd4_294_967_296) / CLK_FREQ;

    reg [31:0] phase_acc;

    always @(posedge clk) begin
        if (!rst_n) phase_acc <= 32'd0;
        else        phase_acc <= phase_acc + PHASE_INC;
    end

    //-------------------------------------------------------------------------
    // 2. 正弦查找表: 64 点一圈, 8bit 有符号 (-127 ~ +127)
    //    sin(k*2*pi/64) * 127 四舍五入
    //-------------------------------------------------------------------------
    wire [5:0] lut_idx = phase_acc[31:26];      // 取高 6 位 = 64 点
    reg signed [7:0] sine;

    always @* begin
        case (lut_idx)
            6'd0:  sine = 8'sd0;    6'd1:  sine = 8'sd12;   6'd2:  sine = 8'sd25;   6'd3:  sine = 8'sd37;
            6'd4:  sine = 8'sd49;   6'd5:  sine = 8'sd60;   6'd6:  sine = 8'sd71;   6'd7:  sine = 8'sd81;
            6'd8:  sine = 8'sd90;   6'd9:  sine = 8'sd98;   6'd10: sine = 8'sd106;  6'd11: sine = 8'sd112;
            6'd12: sine = 8'sd117;  6'd13: sine = 8'sd121;  6'd14: sine = 8'sd124;  6'd15: sine = 8'sd126;
            6'd16: sine = 8'sd127;
            6'd17: sine = 8'sd126;  6'd18: sine = 8'sd124;  6'd19: sine = 8'sd121;
            6'd20: sine = 8'sd117;  6'd21: sine = 8'sd112;  6'd22: sine = 8'sd106;  6'd23: sine = 8'sd98;
            6'd24: sine = 8'sd90;   6'd25: sine = 8'sd81;   6'd26: sine = 8'sd71;   6'd27: sine = 8'sd60;
            6'd28: sine = 8'sd49;   6'd29: sine = 8'sd37;   6'd30: sine = 8'sd25;   6'd31: sine = 8'sd12;
            6'd32: sine = 8'sd0;    6'd33: sine = -8'sd12;  6'd34: sine = -8'sd25;  6'd35: sine = -8'sd37;
            6'd36: sine = -8'sd49;  6'd37: sine = -8'sd60;  6'd38: sine = -8'sd71;  6'd39: sine = -8'sd81;
            6'd40: sine = -8'sd90;  6'd41: sine = -8'sd98;  6'd42: sine = -8'sd106; 6'd43: sine = -8'sd112;
            6'd44: sine = -8'sd117; 6'd45: sine = -8'sd121; 6'd46: sine = -8'sd124; 6'd47: sine = -8'sd126;
            6'd48: sine = -8'sd127;
            6'd49: sine = -8'sd126; 6'd50: sine = -8'sd124; 6'd51: sine = -8'sd121;
            6'd52: sine = -8'sd117; 6'd53: sine = -8'sd112; 6'd54: sine = -8'sd106; 6'd55: sine = -8'sd98;
            6'd56: sine = -8'sd90;  6'd57: sine = -8'sd81;  6'd58: sine = -8'sd71;  6'd59: sine = -8'sd60;
            6'd60: sine = -8'sd49;  6'd61: sine = -8'sd37;  6'd62: sine = -8'sd25;  6'd63: sine = -8'sd12;
            default: sine = 8'sd0;
        endcase
    end

    //-------------------------------------------------------------------------
    // 3. PWM: 载波周期 = CLK_FREQ/PWM_FREQ = 500 拍, 占空比 = THR/500
    //    阈值 = 中点 + 正弦偏移, 偏移幅度由 AMP_PCT 决定
    //-------------------------------------------------------------------------
    localparam integer PWM_DIV   = CLK_FREQ / PWM_FREQ;        // 500
    localparam integer PWM_MID   = PWM_DIV / 2;                // 250
    localparam integer PWM_MAX   = PWM_DIV - 1;                // 499
    localparam integer AMP_DELTA = (PWM_MID * AMP_PCT) / 100;   // 满幅偏移量

    // 正弦偏移: (sine * AMP_DELTA) / 127  -> 用 >>>7 近似, 误差 <1%
    wire signed [15:0] offset  = (sine * AMP_DELTA) >>> 7;
    wire signed [15:0] mid_s   = PWM_MID;
    wire signed [15:0] max_s   = PWM_MAX;
    wire signed [15:0] thr_s   = mid_s + offset;
    wire        [15:0] thr     = (thr_s < 0)     ? 16'd0     :
                                 (thr_s > max_s) ? PWM_MAX  :
                                 thr_s[15:0];

    reg [15:0] pwm_cnt;

    always @(posedge clk) begin
        if (!rst_n)              pwm_cnt <= 16'd0;
        else if (pwm_cnt == PWM_MAX) pwm_cnt <= 16'd0;
        else                     pwm_cnt <= pwm_cnt + 16'd1;
    end

    always @(posedge clk) begin
        if (!rst_n) mod_out <= 1'b0;
        else        mod_out <= (pwm_cnt < thr);
    end

endmodule

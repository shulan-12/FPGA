//=============================================================================
// fake_src.v  --  板载假数据源 (可综合, 上板用)
//-----------------------------------------------------------------------------
// 作用: 在没有 AD7606 模块的情况下, 在 FPGA 内部产生"看起来像光电探测器输出"
//       的带噪信号, 用来把【串口帧格式 + 上位机】这条链路先跑通。
//
// 和 sim/pd_src.v 的关系:
//   算法完全一样(64点正弦表 + LFSR 白噪声), 但接口不同:
//     pd_src   : 仿真用, 有 step 节拍输入, 输出是【寄存器】
//     fake_src : 上板用, 有 next 请求输入, 输出是【组合逻辑】(少一拍延迟, 方便
//                和帧发送状态机配合)
//   ponytail: 正弦表在这两个文件里各存了一份。之所以不共用, 是为了让 rtl/ 目录
//   不依赖 sim/ 目录(综合时不会误把仿真文件带进去)。将来若表变长, 应该抽成一个
//   单独的 sin_lut.v 由两边共同例化。
//
// 上板后怎么替换成真 ADC:
//   把帧发送模块的 src_sample/src_next 从 fake_src 改接到 ad7606_if 的输出即可,
//   frame_tx.v 一行都不用改。
//=============================================================================
`timescale 1ns / 1ps

module fake_src #(
    parameter integer AMP    = 3000,           // 信号幅度 (LSB)
    parameter integer NOISE  = 40,             // 白噪声幅度 (LSB)
    parameter integer PERIOD = 64,             // 正弦周期 (采样点数)
    parameter [31:0]  SEED   = 32'hDEAD_BEEF   // 噪声种子
)(
    input  wire               clk,
    input  wire               rst_n,
    input  wire               next,     // 单周期脉冲: 推进到下一个样本
    output wire signed [15:0] sample    // 当前样本 (组合输出)
);

    //------------------------------------------------------------------
    // 64 点正弦表, 幅度 ±1024
    //------------------------------------------------------------------
    reg signed [15:0] sine_lut [0:63];
    initial begin
        sine_lut[ 0]=  16'sd0;    sine_lut[ 1]= 16'sd100;  sine_lut[ 2]= 16'sd200;  sine_lut[ 3]= 16'sd297;
        sine_lut[ 4]= 16'sd392;   sine_lut[ 5]= 16'sd483;  sine_lut[ 6]= 16'sd569;  sine_lut[ 7]= 16'sd650;
        sine_lut[ 8]= 16'sd724;   sine_lut[ 9]= 16'sd792;  sine_lut[10]= 16'sd851;  sine_lut[11]= 16'sd903;
        sine_lut[12]= 16'sd946;   sine_lut[13]= 16'sd980;  sine_lut[14]=16'sd1004;  sine_lut[15]=16'sd1019;
        sine_lut[16]=16'sd1024;   sine_lut[17]=16'sd1019;  sine_lut[18]=16'sd1004;  sine_lut[19]= 16'sd980;
        sine_lut[20]= 16'sd946;   sine_lut[21]= 16'sd903;  sine_lut[22]= 16'sd851;  sine_lut[23]= 16'sd792;
        sine_lut[24]= 16'sd724;   sine_lut[25]= 16'sd650;  sine_lut[26]= 16'sd569;  sine_lut[27]= 16'sd483;
        sine_lut[28]= 16'sd392;   sine_lut[29]= 16'sd297;  sine_lut[30]= 16'sd200;  sine_lut[31]= 16'sd100;
        sine_lut[32]=  16'sd0;    sine_lut[33]=-16'sd100;  sine_lut[34]=-16'sd200;  sine_lut[35]=-16'sd297;
        sine_lut[36]=-16'sd392;   sine_lut[37]=-16'sd483;  sine_lut[38]=-16'sd569;  sine_lut[39]=-16'sd650;
        sine_lut[40]=-16'sd724;   sine_lut[41]=-16'sd792;  sine_lut[42]=-16'sd851;  sine_lut[43]=-16'sd903;
        sine_lut[44]=-16'sd946;   sine_lut[45]=-16'sd980;  sine_lut[46]=-16'sd1004; sine_lut[47]=-16'sd1019;
        sine_lut[48]=-16'sd1024;  sine_lut[49]=-16'sd1019; sine_lut[50]=-16'sd1004; sine_lut[51]=-16'sd980;
        sine_lut[52]=-16'sd946;   sine_lut[53]=-16'sd903;  sine_lut[54]=-16'sd851;  sine_lut[55]=-16'sd792;
        sine_lut[56]=-16'sd724;   sine_lut[57]=-16'sd650;  sine_lut[58]=-16'sd569;  sine_lut[59]=-16'sd483;
        sine_lut[60]=-16'sd392;   sine_lut[61]=-16'sd297;  sine_lut[62]=-16'sd200;  sine_lut[63]=-16'sd100;
    end

    //------------------------------------------------------------------
    // 相位累加器 + 噪声 LFSR (只在 next 时推进)
    //------------------------------------------------------------------
    localparam integer PHASE_INC = (64 * 65536) / PERIOD;

    reg [31:0] phase;
    reg [31:0] lfsr;

    wire [31:0] lfsr_nxt = {lfsr[30:0], lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};

    always @(posedge clk) begin
        if (!rst_n) begin
            phase <= 32'd0;
            lfsr  <= SEED;
        end
        else if (next) begin
            phase <= phase + PHASE_INC[31:0];
            lfsr  <= lfsr_nxt;
        end
    end

    //------------------------------------------------------------------
    // 组合输出当前样本
    //------------------------------------------------------------------
    wire [5:0]         idx     = phase[21:16];
    wire signed [31:0] clean_s = (sine_lut[idx] * AMP) >>> 10;
    wire signed [15:0] noise_u = $signed({1'b0, lfsr[7:0]}) - 16'sd128;  // -128..127
    wire signed [31:0] noise_s = (noise_u * NOISE) >>> 7;

    assign sample = clean_s[15:0] + noise_s[15:0];

endmodule

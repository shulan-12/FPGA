//=============================================================================
// top_adc_bringup.v  --  AD7606 接线联调专用顶层 (最小系统)
//-----------------------------------------------------------------------------
// 【用途】模块到货后, 先用这个比特流验证接线对不对, 再上整机。
//
//   为什么不直接上整机:
//     整机(假数据源+滤波器+双缓冲+串口帧)链路太长, 接线一错你根本分不清是
//     接线问题还是逻辑问题。这个最小系统只有"读 ADC + 点灯", 三个 LED 就能判断:
//
//       led1 : 1 Hz 心跳        -> FPGA 在跑
//       led2 : 跟着 frame 闪     -> ADC 正在被正常读取 (8 通道轮询中)
//       led3 : 跟着数据翻转      -> 数据总线真的在变 (db 有信号)
//
//       ★ error_timeout 触发时: led2 改成快闪(约 12 Hz)
//         -> 一眼看出"BUSY 没按预期翻转", 是接线/供电问题
//
// 【引脚】全部走 J10 扩展口, 具体接法见 `联调接线表_AD7606接J10.md`
//=============================================================================
`timescale 1ns / 1ps

module top_adc_bringup #(
    parameter integer CLK_FREQ  = 50_000_000,
    parameter integer BLINK_DIV = 25_000_000,   // 1 Hz 心跳
    parameter integer CONV_RATE = 100_000,      // 100 kSPS
    parameter integer OS_SET    = 0             // 过采样档位: 0=不启用, 6=64x
)(
    input  wire        clk,
    input  wire        rst_n,

    output wire        led1,
    output wire        led2,
    output wire        led3,

    // ---- AD7606 (经 J10 扩展口) ----
    output wire        ad_convst,     // -> CONVSTA
    output wire        ad_convst_b,   // -> CONVSTB (与 CONVSTA 同相, 见 ad7606_if 注释)
    output wire        ad_cs_n,
    output wire        ad_rd_n,
    output wire        ad_reset,
    output wire [2:0]  ad_os,
    output wire        ad_stby,       // -> 模块丝印 STBY   (恒 1)
    output wire        ad_ser,        // -> 模块丝印 SER    (恒 0, 并行接口)
    input  wire [15:0] ad_db,
    input  wire        ad_busy,
    input  wire        ad_frstdata
);

    //-------------------------------------------------------------------------
    // 1. 心跳灯
    //-------------------------------------------------------------------------
    reg [31:0] blink_cnt;
    reg        led_r;

    always @(posedge clk) begin
        if (!rst_n) begin
            blink_cnt <= 32'd0;
            led_r     <= 1'b0;
        end
        else if (blink_cnt == BLINK_DIV-1) begin
            blink_cnt <= 32'd0;
            led_r     <= ~led_r;
        end
        else blink_cnt <= blink_cnt + 32'd1;
    end

    //-------------------------------------------------------------------------
    // 2. 采集控制器
    //-------------------------------------------------------------------------
    wire signed [15:0] sample_data;
    wire [2:0]         sample_ch;
    wire               sample_valid, frame_done, error_timeout;

    ad7606_if #(
        .CLK_FREQ   (CLK_FREQ),
        .CONV_RATE  (CONV_RATE),
        .OS_SET     (OS_SET)
    ) u_adc (
        .clk           (clk),
        .rst_n         (rst_n),
        .convst        (ad_convst),
        .convst_b      (ad_convst_b),
        .cs_n          (ad_cs_n),
        .rd_n          (ad_rd_n),
        .ad_reset      (ad_reset),
        .os            (ad_os),
        .stby          (ad_stby),
        .ser           (ad_ser),
        .db            (ad_db),
        .busy          (ad_busy),
        .frstdata      (ad_frstdata),
        .sample_data   (sample_data),
        .sample_ch     (sample_ch),
        .sample_valid  (sample_valid),
        .frame_done    (frame_done),
        .error_timeout (error_timeout)
    );

    //-------------------------------------------------------------------------
    // 3. 三个指示灯
    //-------------------------------------------------------------------------
    // 帧计数器: 每读完一轮(8通道) +1, 取中间位做可视闪烁
    reg [31:0] frame_cnt;
    always @(posedge clk) begin
        if (!rst_n)              frame_cnt <= 32'd0;
        else if (frame_done)     frame_cnt <= frame_cnt + 32'd1;
    end

    // 数据活动检测: 把采样值和 FRSTDATA 异或累加。
    // ★ 这一步不是装饰, 有两个真实的坑:
    //   ① 没有它, 综合会把 db 输入整条路径优化掉, 引脚从网表里消失;
    //   ② 更隐蔽的: 如果只用 db_acc 的某一位(比如 [8])去点灯,
    //      其余 15 位的寄存器输出没人读, 会被逐位裁掉 ——
    //      结果是"16 根数据线里只有 1 根真的连进逻辑"。
    //      所以下面必须用【全位归约异或】^db_acc, 保证 16 位都有读者。
    //      (这条是综合期发现的: IBUF 只有 4 个 = clk+rst_n+busy+db[8])
    reg [15:0] db_acc;
    always @(posedge clk) begin
        if (!rst_n)           db_acc <= 16'd0;
        else if (sample_valid) db_acc <= db_acc ^ sample_data ^ {15'b0, ad_frstdata};
    end

    // 超时快闪用的慢时钟
    reg [23:0] err_cnt;
    always @(posedge clk) begin
        if (!rst_n) err_cnt <= 24'd0;
        else        err_cnt <= err_cnt + 24'd1;
    end

    // AX7035 的 LED 是低电平点亮, 所以全部取反
    assign led1 = ~led_r;
    // 正常: 跟着 frame 走 (ADC 在被读就闪); 超时: 快闪报警
    assign led2 = error_timeout ? ~err_cnt[21] : ~frame_cnt[5];
    // 数据总线在变就闪 (^db_acc 是 16 位归约异或, 保证每一位都被读到)
    assign led3 = ~(^db_acc);

endmodule

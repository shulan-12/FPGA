#=============================================================================
# AX7035B + AD7606_ADC_V3  ---  前端联调测试流 (top_adc_stream)
#-----------------------------------------------------------------------------
# 这份约束 = 板载资源(LED/时钟/复位/串口) + AD7606 的 J10 并行接口
#
# 仅供【测试流】使用。引脚依据与详细说明见:
#   constrs/AX7035_led_uart.xdc        (板载资源)
#   constrs/AX7035_ad7606_J10.xdc      (AD7606 的 28 个 J10 引脚, 含模块丝印对照)
#=============================================================================

# ---- 系统时钟 50MHz (GCLK, BANK14) ----
set_property -dict {PACKAGE_PIN Y18 IOSTANDARD LVCMOS33} [get_ports clk]
create_clock -period 20.000 -name sys_clk [get_ports clk]

# ---- 复位按键 RESET (F20, 按下为低) ----
set_property -dict {PACKAGE_PIN F20 IOSTANDARD LVCMOS33} [get_ports rst_n]

# ---- 用户 LED (BANK16, 低电平点亮) ----
set_property -dict {PACKAGE_PIN F19 IOSTANDARD LVCMOS33} [get_ports led1]
set_property -dict {PACKAGE_PIN E21 IOSTANDARD LVCMOS33} [get_ports led2]
set_property -dict {PACKAGE_PIN D20 IOSTANDARD LVCMOS33} [get_ports led3]

# ---- USB-UART (CP2102GM, BANK15)。FPGA 发送脚 = G16 ----
set_property -dict {PACKAGE_PIN G16 IOSTANDARD LVCMOS33} [get_ports uart_tx]

#=============================================================================
# AD7606 数据总线 DB[15:0]   ---  J10 pin 3~10 与 13~20
#=============================================================================
set_property -dict {PACKAGE_PIN P17 IOSTANDARD LVCMOS33} [get_ports {ad_db[0]}]
set_property -dict {PACKAGE_PIN N17 IOSTANDARD LVCMOS33} [get_ports {ad_db[1]}]
set_property -dict {PACKAGE_PIN R19 IOSTANDARD LVCMOS33} [get_ports {ad_db[2]}]
set_property -dict {PACKAGE_PIN P19 IOSTANDARD LVCMOS33} [get_ports {ad_db[3]}]
set_property -dict {PACKAGE_PIN T18 IOSTANDARD LVCMOS33} [get_ports {ad_db[4]}]
set_property -dict {PACKAGE_PIN R18 IOSTANDARD LVCMOS33} [get_ports {ad_db[5]}]
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {ad_db[6]}]
set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {ad_db[7]}]
set_property -dict {PACKAGE_PIN V20 IOSTANDARD LVCMOS33} [get_ports {ad_db[8]}]
set_property -dict {PACKAGE_PIN U20 IOSTANDARD LVCMOS33} [get_ports {ad_db[9]}]
set_property -dict {PACKAGE_PIN W22 IOSTANDARD LVCMOS33} [get_ports {ad_db[10]}]
set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports {ad_db[11]}]
set_property -dict {PACKAGE_PIN Y22 IOSTANDARD LVCMOS33} [get_ports {ad_db[12]}]
set_property -dict {PACKAGE_PIN Y21 IOSTANDARD LVCMOS33} [get_ports {ad_db[13]}]
set_property -dict {PACKAGE_PIN AA21 IOSTANDARD LVCMOS33} [get_ports {ad_db[14]}]
set_property -dict {PACKAGE_PIN AA20 IOSTANDARD LVCMOS33} [get_ports {ad_db[15]}]

#=============================================================================
# AD7606 控制信号   ---  J10 pin 21~32  (括号里是模块排针丝印)
#=============================================================================
set_property -dict {PACKAGE_PIN AB22 IOSTANDARD LVCMOS33} [get_ports ad_busy]      ;# J10-21 BUSY
set_property -dict {PACKAGE_PIN AB21 IOSTANDARD LVCMOS33} [get_ports ad_convst]    ;# J10-22 CO-A
set_property -dict {PACKAGE_PIN AB20 IOSTANDARD LVCMOS33} [get_ports ad_cs_n]      ;# J10-23 CS_N
set_property -dict {PACKAGE_PIN AA19 IOSTANDARD LVCMOS33} [get_ports ad_rd_n]      ;# J10-24 RD/SC
set_property -dict {PACKAGE_PIN W20  IOSTANDARD LVCMOS33} [get_ports ad_reset]     ;# J10-25 RESET
set_property -dict {PACKAGE_PIN W19  IOSTANDARD LVCMOS33} [get_ports {ad_os[0]}]   ;# J10-26 OS0
set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {ad_os[1]}]   ;# J10-27 OS1
set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports {ad_os[2]}]   ;# J10-28 OS2
set_property -dict {PACKAGE_PIN V19  IOSTANDARD LVCMOS33} [get_ports ad_frstdata]  ;# J10-29 FR-D
set_property -dict {PACKAGE_PIN V18  IOSTANDARD LVCMOS33} [get_ports ad_convst_b]  ;# J10-30 CO-B
set_property -dict {PACKAGE_PIN W17  IOSTANDARD LVCMOS33} [get_ports ad_stby]      ;# J10-31 STBY (恒 1)
set_property -dict {PACKAGE_PIN V17  IOSTANDARD LVCMOS33} [get_ports ad_ser]       ;# J10-32 SER  (恒 0)

# ---- 1 kHz 正弦调制输出 -> J10-33 (U18)。外部 RC(1k/10nF) 后驱动 LED ----
set_property -dict {PACKAGE_PIN U18 IOSTANDARD LVCMOS33} [get_ports mod_out]   ;# J10-33

# ---- 配置电压 ----
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]

#=============================================================================
# QSPI Flash 启动配置 (板载 N25Q128, 128Mbit = 16MB, 3.3V, 四线)
#-----------------------------------------------------------------------------
# 依据: ALINX《AX7035 User Manual》Part 7
#   "equipped with one 128MBit QSPI FLASH, and the model is N25Q128,
#    which uses the 3.3V CMOS voltage standard"
# 这四个属性【只影响配置头, 不影响任何逻辑和时序】:
#   SPI_BUSWIDTH=4  -> 四线方式读 Flash, 启动比单线快约 4 倍
#   SPI_FALL_EDGE   -> 下降沿采样, N25Q 系列的标准时序
#   CONFIG_MODE=SPIx4 -> 上电后 FPGA 主动从 QSPI 加载
# 不设这些的话, write_bitstream 产物只能单线启动, 且 write_cfgmem 会报
#   "SPI_BUSWIDTH property is set to 1 ... has to be set to 4" 而生成失败
#=============================================================================
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH   4 [current_design]
set_property BITSTREAM.CONFIG.SPI_FALL_EDGE  YES [current_design]
set_property CONFIG_MODE                    SPIx4 [current_design]


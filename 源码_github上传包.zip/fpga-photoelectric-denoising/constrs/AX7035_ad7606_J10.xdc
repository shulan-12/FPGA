#=============================================================================
# AX7035B + AD7606_ADC_V3 模块接线约束  (走 J10 扩展口)
#-----------------------------------------------------------------------------
# 【引脚来源 · 权威】
#   J10 扩展口定义: ALINX 官方《AX7035 User Manual》Rev1.0 Part17
#       https://www.alinx.com/public/upload/file/AX7035_User_Manual.pdf
#       本地留档: docs/AX7035_User_Manual.pdf  (第 781~806 行)
#   J10 各脚所属 BANK: 用 Vivado 自带 AMD 官方器件数据库逐个查证
#       (脚本 sim/j10_query.tcl, 日志 sim/j10_query.log)
#
# 【电平】J10 的 34 个 IO 全部在 BANK14。手册 Part4 原文:
#   "BANK34 needs to be connected to DDR3, the voltage connection of BANK is 1.5V,
#    and the voltage of other BANK is 3.3V."
#   => BANK14 固定 3.3V, 用 LVCMOS33 正确。
#
# 【★ 上板前必须确认的一件事】
#   AD7606_ADC_V3 模块的接口电平要拨到 **3.3V** (模块手册第(5)条:
#   "电平可选5V或3.3V, 通过短路帽或 IO 编程控制")。
#   如果模块是 5V 电平, FPGA 的 3.3V 引脚会被灌 5V —— 可能烧 BANK 或烧芯片。
#
# 【避开的一个引脚】
#   J10 pin 11 (V22) 和 pin 12 (U22) 在本设计中【留空不用】。
#   原因: V22 = EMCCLK, U22 = PUDC_B, 都是配置相关脚。
#   虽然按 UG470 的说明它们在 JTAG/SPI 配置模式下可以当普通 IO 用,
#   但本设计有 9 个空闲脚, 没必要冒这个险 —— 空着最省心。
#
# 【待核实】以下两条模块到货后要确认, 已按最可能的方式写:
#   1. 模块排针的丝印信号名 (DB0~DB15 / BUSY / CONVST / CS / RD / RESET / OS0~2)
#      是否与 AD7606 芯片手册一致 —— 接线前对着模块丝印核一遍。
#   2. 模块是否需要外部提供 3.3V。若模块自带 LDO, 就【不要】接 J10 的 39/40 脚,
#      否则两个电源对驱。
#=============================================================================
#
# ★★★ 2026-10-18 更新: 模块手册《AD7606 数据采集模块使用说明》已通读, 以下已【核实】 ★★★
#   模块排针丝印用的是【缩写】, 这是之前"找不到 PAR/SER/BYTESEL"的真正原因:
#       手册名称            -> 模块排针丝印
#       PAR/SER/BYTESEL     -> SER
#       CONVST A            -> CO-A
#       CONVST B            -> CO-B
#       CS                  -> CS_N
#       RD / SCLK           -> RD/SC
#       FRSTDATA            -> FR-D
#       STBY                -> STBY
#   手册 2.1.3「接口引脚定义」表 (16 行 x 2 列 = 32 针):
#       +5V | +5V
#       GND | GND
#       OS1 | OS0
#       SER | OS2
#       CO-A | STBY
#       RESET | CO-B
#       CS_N | RD/SC
#       FR-D | BUSY
#       DB1 | DB0   DB3 | DB2   DB5 | DB4   DB7 | DB6
#       DB9 | DB8   DB11| DB10  DB13| DB12  DB15| DB14
#   ★ 注意: 手册 2.1.3【没有】RANGE (RANGE 由模块 J2 短路帽设置),
#     也【没有】给排针编号/pin1 位置。所以接线一律【按丝印名对号】, 不要数针。
#
#   手册 3.1(2): "需要 AD7606 正常工作, 必须将 STBY 置为高电平"
#   手册 表8 接口模式: SER=0 且 DB15=0 -> 并行接口模式
#   => STBY 必须驱动为 1, SER 必须驱动为 0。这两个脚都引到排针上了,
#      本设计用 J10-31 / J10-32 主动驱动, 不去赌模块上的上下拉电阻接在哪边。
#=============================================================================

# ---- 系统时钟 50MHz (BANK14) ----
set_property -dict {PACKAGE_PIN Y18 IOSTANDARD LVCMOS33} [get_ports clk]
create_clock -period 20.000 -name sys_clk [get_ports clk]

# ---- 复位按键 RESET (F20, 低有效) ----
set_property -dict {PACKAGE_PIN F20 IOSTANDARD LVCMOS33} [get_ports rst_n]

# ---- 三个指示灯 (低电平点亮) ----
set_property -dict {PACKAGE_PIN F19 IOSTANDARD LVCMOS33} [get_ports led1]
set_property -dict {PACKAGE_PIN E21 IOSTANDARD LVCMOS33} [get_ports led2]
set_property -dict {PACKAGE_PIN D20 IOSTANDARD LVCMOS33} [get_ports led3]

#=============================================================================
# AD7606 数据总线 DB[15:0]   ---  J10 pin 3~10 与 13~20
#   低字节 DB0~DB7  走 J10 3,4,5,6,7,8,9,10
#   高字节 DB8~DB15 走 J10 13,14,15,16,17,18,19,20
#   (中间 11、12 两脚留空)
#=============================================================================
set_property -dict {PACKAGE_PIN P17 IOSTANDARD LVCMOS33} [get_ports {ad_db[0]}]
set_property -dict {PACKAGE_PIN N17 IOSTANDARD LVCMOS33} [get_ports {ad_db[1]}]
set_property -dict {PACKAGE_PIN R19 IOSTANDARD LVCMOS33} [get_ports {ad_db[2]}]
set_property -dict {PACKAGE_PIN P19 IOSTANDARD LVCMOS33} [get_ports {ad_db[3]}]
set_property -dict {PACKAGE_PIN T18 IOSTANDARD LVCMOS33} [get_ports {ad_db[4]}]
set_property -dict {PACKAGE_PIN R18 IOSTANDARD LVCMOS33} [get_ports {ad_db[5]}]
set_property -dict {PACKAGE_PIN U21 IOSTANDARD LVCMOS33} [get_ports {ad_db[6]}]
set_property -dict {PACKAGE_PIN T21 IOSTANDARD LVCMOS33} [get_ports {ad_db[7]}]
set_property -dict {PACKAGE_PIN V20 IOSTANDARD LVCMOS33} [get_ports {ad_db[8]}]
set_property -dict {PACKAGE_PIN U20 IOSTANDARD LVCMOS33} [get_ports {ad_db[9]}]
set_property -dict {PACKAGE_PIN W22 IOSTANDARD LVCMOS33} [get_ports {ad_db[10]}]
set_property -dict {PACKAGE_PIN W21 IOSTANDARD LVCMOS33} [get_ports {ad_db[11]}]
set_property -dict {PACKAGE_PIN Y22 IOSTANDARD LVCMOS33} [get_ports {ad_db[12]}]
set_property -dict {PACKAGE_PIN Y21 IOSTANDARD LVCMOS33} [get_ports {ad_db[13]}]
set_property -dict {PACKAGE_PIN AA21 IOSTANDARD LVCMOS33} [get_ports {ad_db[14]}]
set_property -dict {PACKAGE_PIN AA20 IOSTANDARD LVCMOS33} [get_ports {ad_db[15]}]

#=============================================================================
# AD7606 控制信号   ---  J10 pin 21~30
#=============================================================================
set_property -dict {PACKAGE_PIN AB22 IOSTANDARD LVCMOS33} [get_ports ad_busy]      ;# J10-21
set_property -dict {PACKAGE_PIN AB21 IOSTANDARD LVCMOS33} [get_ports ad_convst]    ;# J10-22 -> CONVSTA
set_property -dict {PACKAGE_PIN AB20 IOSTANDARD LVCMOS33} [get_ports ad_cs_n]      ;# J10-23
set_property -dict {PACKAGE_PIN AA19 IOSTANDARD LVCMOS33} [get_ports ad_rd_n]      ;# J10-24
set_property -dict {PACKAGE_PIN W20  IOSTANDARD LVCMOS33} [get_ports ad_reset]     ;# J10-25
set_property -dict {PACKAGE_PIN W19  IOSTANDARD LVCMOS33} [get_ports {ad_os[0]}]   ;# J10-26
set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports {ad_os[1]}]   ;# J10-27
set_property -dict {PACKAGE_PIN AA18 IOSTANDARD LVCMOS33} [get_ports {ad_os[2]}]   ;# J10-28
set_property -dict {PACKAGE_PIN V19  IOSTANDARD LVCMOS33} [get_ports ad_frstdata]  ;# J10-29
# ---- CONVSTB 单独一根：AD7606 有两个转换启动脚，必须同时拉高才是 8 通道同时采样 ----
#      这样就不用再模块上焊线短接了（两根母头插不进同一根针）
set_property -dict {PACKAGE_PIN V18  IOSTANDARD LVCMOS33} [get_ports ad_convst_b]  ;# J10-30 -> CONVSTB

#=============================================================================
# 模块工作模式配置脚   ---  J10 pin 31~32
#   手册 3.1(2): STBY 必须为高电平, 否则芯片待机/关断, BUSY 不动 -> 采不到数
#   手册 表8   : SER(PAR/SER/BYTESEL)=0 且 DB15=0 -> 并行接口模式
#   两个都是【常量输出】, 不需要时序约束。
#=============================================================================
set_property -dict {PACKAGE_PIN W17  IOSTANDARD LVCMOS33} [get_ports ad_stby]      ;# J10-31 -> STBY (恒 1)
set_property -dict {PACKAGE_PIN V17  IOSTANDARD LVCMOS33} [get_ports ad_ser]       ;# J10-32 -> SER  (恒 0)

# ---- 剩余空闲脚: J10-33 U18 / J10-34 U17 / J10-35 R14 / J10-36 P14 (暂不使用) ----

# ---- 配置电压 ----
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]

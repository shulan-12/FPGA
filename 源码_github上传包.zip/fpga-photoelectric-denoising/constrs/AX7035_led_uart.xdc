#=============================================================================
# ALINX AX7035 / AX7035B (XC7A35T-2FGG484I) 约束文件 -- 第 1-2 周 点灯+串口
#-----------------------------------------------------------------------------
# 【引脚来源 · 权威】ALINX 官方《ARTIX-7 FPGA Development Board AX7035 User Manual》
#   Rev 1.0 / 2019-04-26, 本地留档 docs/AX7035_User_Manual.pdf
#   （原站 https://www.alinx.com/public/upload/file/AX7035_User_Manual.pdf 有反爬，
#     本文件用的是公开镜像 https://raw.githubusercontent.com/fpgauk/pdf/main/alinx/ax7035/AX7035_User_Manual.pdf）
#
#   系统时钟  : Part5  "connected to the FPGA's global clock (GCLK Pin Y18)"   -> Y18
#   用户 LED  : Part21 "Pin assignment of user LED lights"  LED1=F19 LED2=E21
#               Part21 "When the IO voltage connected to the user LED is
#                        configured low level, the user LED lights up"
#               => 【低电平点亮!】top 里已经取反
#   复位按键  : Part20  RESET = F20, "The key is active low"
#   串口      : Part13  UART_RXD = G15, UART_TXD = G16
#   扩展口    : Part17  J9 -> BANK16 (电平可用 LDO 调), J10 -> BANK14 (固定 3.3V)
#
# 【BANK / 电平】以下 bank 号来自 Vivado 自带 AMD 官方器件数据库, 不是猜的:
#   Y18 -> BANK14   ;  F19/E21/D20/C20/F20 -> BANK16
#   G15/G16 -> BANK15
#   手册 Part4 原文: "BANK34 needs to be connected to DDR3, the voltage connection
#   of BANK is 1.5V, and the voltage of other BANK is 3.3V.
#   The VCCO of BANK16 is powered by the LDO, and can be changed by replacing the LDO chip."
#   => BANK14/15 固定 3.3V, 用 LVCMOS33 没问题。
#   => BANK16 默认也是 3.3V (U27 这颗 LDO 出厂是 3.3V 版本), 但如果有人换过 LDO,
#      LED 那几脚的电平就不是 3.3V 了 —— 【待核实: 对着实物确认 U27 型号】。
#=============================================================================

# ---- 系统时钟 50MHz (GCLK, BANK14) ----
set_property -dict {PACKAGE_PIN Y18 IOSTANDARD LVCMOS33} [get_ports clk]
create_clock -period 20.000 -name sys_clk [get_ports clk]

# ---- 复位按键 RESET (F20, 按下为低) ----
set_property -dict {PACKAGE_PIN F20 IOSTANDARD LVCMOS33} [get_ports rst_n]

# ---- 用户 LED (BANK16, 低电平点亮) ----
set_property -dict {PACKAGE_PIN F19 IOSTANDARD LVCMOS33} [get_ports led1]
set_property -dict {PACKAGE_PIN E21 IOSTANDARD LVCMOS33} [get_ports led2]

# ---- USB-UART (CP2102GM, BANK15) ----
# 手册 Part13 把 G15 命名为 UART_RXD, G16 命名为 UART_TXD, 命名是【站在 FPGA 角度】的:
#   UART_RXD = FPGA 收 -> 输入脚 G15
#   UART_TXD = FPGA 发 -> 输出脚 G16
# 所以本工程只用到 uart_tx, 接到 G16。
#
# 【已交叉验证, 不再是推断】两个独立的第三方 AX7035 工程里, FPGA 的 UART 发送脚都约束到 G16:
#   https://raw.githubusercontent.com/anserion/AX7035_UART_TX/HEAD/AX7035_UART_TX.xdc
#     set_property PACKAGE_PIN G16 [get_ports UART_TX]     <-- 发送脚 = G16, 与本文件一致
#   本地留档: docs/ref_AX7035_UART_TX.xdc
# 万一上板后灯闪但串口仍然没字, 可以临时把下面改成 G15 排除接线问题, 但正常情况就是 G16。
set_property -dict {PACKAGE_PIN G16 IOSTANDARD LVCMOS33} [get_ports uart_tx]

# ---- 配置电压 ----
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
